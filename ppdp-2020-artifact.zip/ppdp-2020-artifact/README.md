### Artifact for Hailstorm submitted at PPDP 2020

We present two directories:

- hailstorm - this directory contains the hailstorm compiler
- examples  - this directory contains various examples

The compiler is around 4600 lines of Haskell and the runtime portions in erlang and C comprise about 1500 lines of code.

#### Build Instructions for REPL

Build instructions are provided in the `hailstorm` directory. We assume the installation of the following:

- stack
- erlc
- erl

Change to the `hailstorm` directory and type the following - `stack install`. This installs the `hailstorm-exe` binary in the location - `~/.local/bin/hailstorm-exe`

For running the examples switch to the `examples` directory and type the following:

```
~/.local/bin/hailstorm-exe <example_name>.hst
```

which produces a `test.beam` file. Type `erl` in the console and then the program is accesible by typing `test:main()`.

We provide unsafe composition operators - `:>>>:`, `:&&&:`, `:***:` for programming with a single resource i.e the REPL calling the resource `IO`.

Make sure examples are ran in the `examples` directory which has the `ioutils.beam` file for performing I/O.

#### Build Instructions for GRiSP boards


For running the examples on the GRiSP boards few code changes are necessary. Go to `hailstorm\src\Main.hs` and in line no 50 do the following change

```haskell
l2  = EI.l1Tol2 l1' EI.GRiSP
```
The change is from `EI.General` to `EI.GRiSP`. The GRiSP backend requires a few additional functions which are generated on supplying this parameter.

And also comment out line no 73 and 75

```haskell
  let finalFilePath = cd <> "/test.core" -- comment this
  writeFile finalFilePath (pack erlangCore)
  callCommand $ "erlc " <> finalFilePath -- comment this

```

Followed by this change type `stack install`. This should install the appropriate binary at `~/.local/bin/hailstorm-exe`.

Please install `rebar3` to deploy on Grisp.

For deploying on the Grisp boards we provide a sample template here - https://github.com/Abhiroop/grisp_template

Clone this repo, it points to a modified GRiSP runtime that we have created.

Now change to this directory - `grisp_template/src` and keep your `<example program>.hst` file there. Run the following:

```
~/.local/bin/hailstorm-exe <example_program>.hst
```

in the src directory.

We additionally provide a bash script called `mac_deploy_grisp.sh` which when ran from the root of the `grisp_template` directory deploys the program onto the SD card supplied with a GRiSP board.

As a demonstrator the repo already contains a program written in Hailstorm for synchronously blinking the 2 LEDs with the red color at a 5 second interval - https://github.com/Abhiroop/grisp_template/blob/master/src/grisp_blinky_2_sync.hst

Executing `mac_deploy_grisp.sh` from the root directory will deploy the application on the GRiSP.

The other applications require the prescence of various connectors and their drivers for running on GRiSP.
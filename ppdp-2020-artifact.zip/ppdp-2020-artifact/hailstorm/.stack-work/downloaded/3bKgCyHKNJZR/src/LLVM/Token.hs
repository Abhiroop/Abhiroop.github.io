module LLVM.Token where

import Data.Text


int text_search(char* haystack, char** needles, int exact, int* results);
int text_search_bound(char* xs);

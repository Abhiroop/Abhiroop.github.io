## ARRAYS

There are 2 problems that we have to deal with: 

1. Implement purely functional arrays with **in place updates**.
2. Implement some kind of memory management strategy for arrays.

Note: we shall deal with static fixed size arrays.

### Purely functional arrays

Three known ways of implementing this 
#### Build version arrays 

Blelloch - https://www.cs.cmu.edu/~rwh/papers/farray/popl17.pdf

O'Neil  - https://pdfs.semanticscholar.org/343a/a47359b287d3e26bf2b7a34220cce690074b.pdf

Aasa - https://link.springer.com/article/10.1007/BF01941130 - the most imp approach

This kind of arrays provide a functional API. In place updates happen whenever possible. Write this whole implementation in C and link to the compiler as primops.

##### Pros

- Zero change in the compiler, doesn't mingle with the other optimization passes

##### Cons

- Super hard to get correct
- Have to write in C :(
- Maybe slightly less efficient than option 2

#### Static Analysis on arrays

Second strategy is to keep a plain mutable array in LLVM. And then use something like this:

Bloss and Hudak : http://haskell.cs.yale.edu/wp-content/uploads/2011/03/AggUpdate-POPL85.pdf

Basically `get` API is always safe. The `update` is the tricky one. This kind of approach creates a new copy very rarely when it can detect through static analysis that a new copy is inevitable. Otherwise it does in place updates, again after running some kind of static analysis pass.

##### Pros

- More efficient than option 1. All the work is done during compile time
- No writing and maintenance of C and its multitudes of pitfalls

##### Cons

- Add complexity to the compiler, no idea how it plays with the other passes 
- Increased compile time
- NP complete problems in the compiler, hard to test need to write multiple fallbacks
- Hudak's paper doesn't support higher order functions

##### Papers on the topic

- [Sisal - In place update](https://eecs.ceas.uc.edu/~paw/classes/ece975/sp2011/papers/feo-90.pdf)
- [Single Assignment C approach](https://www.semanticscholar.org/paper/Implicit-Memory-Management-for-SAC.-Grelck-Trojahner/75f9c1824e0d0530307fbdcf93ef7d146ea34332)
- [Update-in-Place Analysis for True Multidimensional Arrays](downloads.hindawi.com/journals/sp/1996/493673.pdf
)

#### Linear Types

##### Pros

- Elegant

##### Cons

- Cumbersome
- Infects the surface language - something which the above 2 approaches don't


---------------------------------------------------------------------------------------

### Memory management for arrays

DPS style but we will think about this later. Maybe we can deallocate fixed size arrays using some cleverly placed `alloca` instructions.

Reference counting in Single Assignment C : http://www.sac-home.org/lib/exe/fetch.php?media=publications:pdf:greltrojifl04.pdf

Have a look at `rts/array_test.hst`

Lets try framing a reference counting model of that program

**It is dangerous to inline expressions which return arrays**

Take the example in `rts/array_test.hst` Inlining the whole program will inline the array to all the call sites. So in that case you have to additionally add a *common subexpression elimination* pass which effectively returns the program to the original state. What I am saying is this:

```haskell
commonSubExpressionElimination . inline = id
```
^ if we can statically check this then this rule can be encoded.

For now lets not inline things of the array type.

Now to the program

```

line 8 x -> arr rc = 1
line 9 x'-> copy of x rc =1 use `alloca` while creating the copy which frees it automatically when the func returns
line 9 y -> some new arr rc =1
line 10 y' -> copy of y rc = 1 use `alloca` when passing it to map
line 10 z -> some new arr rc = 1
line 11 copy of x y z with alloca
line 11 zip3 returns a newly malloc'd array
return this array and free all bindings which has reference count of 1

Assumption here

When calling f arr

we create a copy of arr using alloca and assume when f returns that copy is deleted. Now assume f simply modifies the array that was passed to it and doesn't separately malloc something new. Can I trust alloca that it will not free the returned arrays as well??


```

Semantics of `alloca` -> https://llvm.org/docs/LangRef.html#alloca-instruction

^^ This is more of a ownership kind of model. 

Lets do actual reference counting

Read [A method for overlapping and erasure of lists](https://dl.acm.org/citation.cfm?id=367501)

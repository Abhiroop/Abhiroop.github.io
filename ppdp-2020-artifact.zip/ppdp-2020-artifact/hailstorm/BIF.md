## Built in functions

As the number of built-in-functions (BIFs) in Hailstorm grows, this document lists all the growing list of
built in functions. Most of them can be found strewn around in the `AST.hs` file.

```haskell
mapSignal# : (a -> b) -> SF Empty a b
>>>   : SF r1 a b -> SF r2 b c -> SF (r1 U r2) a c
:>>>: : SF r a b  -> SF r b c  -> SF r a c -- unsafe compose
fst# : (a, b) -> a
snd# : (a, b) -> b
readIntStream# : SF IO () Int
writeIntStream# : SF IO Int ()

-- only in Erlang backend
readColor#  : Int -> SF r () Int
writeColor# : Int -> SF r Int ()
&&&   : SF r1 a b -> SF r2 a c -> SF (r1 U r2) a (b, c)
:&&&: : SF r a b  -> SF r a c  -> SF r a (b, c) -- unsafe
***   : SF r1 a c  -> SF r2 b d  -> SF (r1 U r2) (a, b) (c, d)
:***: : SF r a c  -> SF r b d  -> SF r (a, b) (c, d) -- unsafe
loop# : c -> SF Empty (a,c) (b,c) -> SF Empty a b
switch# : SF r1 a b -> (b -> SF r2 b c) -> SF (r1 U r2) a c
rate# : Float -> SF r a b -> SF r a b

-- only in LLVM backend
newSeqInt# : Capacity -> Init -> [Int]
getSeqInt# : [Int] -> Index -> Int
setSeqInt# : [Int] -> Index -> Int -> [Int]
newSeqBool# : Capacity -> Init -> [Bool]
getSeqBool# : [Bool] -> Index -> Bool
setSeqBool# : [Bool] -> Index -> Bool -> [Bool]
type Capacity = Int
type Index    = Int
type Init     = Int
```

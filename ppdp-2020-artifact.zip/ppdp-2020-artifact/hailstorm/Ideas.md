### IDEAS

Can every expression be parallel?

Using the `with` construct

```haskell
wordCount :: [String] -> Int
wordCount xs =
  reduce (\x y => x + y) 0 (map (\_ => 1) xs with 4) with 4
```

```
      combine at the top 
      using the last applied
      operator
 reduce reduce reduce reduce
 map    map    map    map
 xs     xs     xs     xs
```

The moment you use the `with` clause the type checker checks if the
top level operation is associative if not typechecker error and
in this way we can throw an error for non associative functions.
Also errors should be on functions which takes 2 or more arguments.

#### Tuples for concurrency

`< >` -> Tuple spaces for concurrency and distribution

```haskell
wordCount :: [String] -> Int
wordCount xs =
  let xs' = map (\_ => 1) xs with 4
   in let < a, b, c, d > = reduce (\x y => x + y) 0 xs'
       in a + b + c + d with 4
```

What happens above

1. Sequence is split into 4 parts and map is applied and joined.
2. Sequential reduce and split into four parts
3. As all four parts are computed sequential addition

< a = getAllValue, wordCount a > -> dependency between elements of tuples

Type = ParTuple (Effect [String]) Int

Tuple spaces are not compositional, almost like carrying around a global state

Can we shift the entire tuple space to the runtime. Like an invisible blackboard being threaded through the entire program.

-----------------------------------------------

Concurrent counter
-----------------------

A very inefficient implementation of a concurrent counter in C.

```C
#define NTHREADS 10

void *thread_function(void *);

pthread_mutex_t mutex1 = PTHREAD_MUTEX_INITIALIZER;

int  counter = 0;

main()
{
   pthread_t thread_id[NTHREADS];
   int i, j;

   for(i=0; i < NTHREADS; i++)
   {
      pthread_create( &thread_id[i], NULL, thread_function, NULL );
   }

   for(j=0; j < NTHREADS; j++)
   {
      pthread_join( thread_id[j], NULL); 
   }
   printf("Final counter value: %d\n", counter);
}

void *thread_function(void *dummyPtr)
{
   pthread_mutex_lock( &mutex1 );
   counter++;
   pthread_mutex_unlock( &mutex1 );
}
```

The same concurrent counter using MVars in Haskell

```haskell

init :: IO (MVar Int)
init = newMVar 0

increment :: MVar Int -> IO ()
increment = do
  count <- takeMVar counter
  putMVar counter $! count + 1 -- not the eager application an unnecessary indirection of laziness

decrement :: MVar Int -> IO ()
decrement = do
  count <- takeMVar counter
  putMVar counter $! count - 1

get :: MVar Int -> IO Int
get = takeMVar

main :: IO ()
main = do
  counter <-init
  let foo = do
       increment counter
       increment counter
       decrement counter
  tids <- replicateM 5 (forkIO foo)
  x <- takeMVar counter
  print x
  
```

Already the Haskell example is much simpler! But do not be deceived!!

The Haskell model is a weaker model because the individual `gets` and `sets` can be reordered

Almost a similar API for STM except performance characterstics  might be slightly different.




#### Exploring the sequential transaction - tuple spaces idea

How would the same concurrent counter look like in Hailstorm?

The parallel tuple `< >` follows value semantics, you cannot mutate them.

Operations:

- `get` removes a tuple from the tuple space
- `put` puts a tuple from the tuple space
- `query` doesn't remove the tuple simply replies back
- NO MUTATION. NEED TO GET AND PUT FOR MUTATION.
- pattern matching are waiting operations
- `seq { .. } : Effect ()` a sequential computation in which there is no reordering

Let us introduce the notion of atoms or keywords in Clojure or Prolog.

Atoms are implicit and need not occur in the type. They are always the first element of the tuple.
They are a means of identifying the tuple

```haskell
init : Effect <Int>
init = put <:sum, 0>

increment : Effect <Int>
increment = seq {
  <:sum, ?x> = get;
  put <:sum, x + 1>;
  }

decrement : Effect <Int>
decrement = seq {
  <:sum, ?x> = get;
  put <:sum, x - 1>;
  }

interp : Effect ()
interp = seq {
  init;
  seq { increment; increment; decrement; } with 5;
  <:sum, ?x> = get;
  print x;
  }

main = runHandler interp
```

The `seq { .. }` construct prevents the reordering by the threads in the runtime.

How do we thread through effects? CPS?

In Hailstorm

```Haskell
foo =
  let x = e1
   in e2
```

The type of the expression is the same as `e2` but how do we force a sequencing between e1 and e2?

The `seq { }` construct introduces ordering.

`seq { .. }` seq has transactional semantics


eg : 

```
seq {
 let x = doAPICall
  in print x
  }
```

We can remove the `seq` keyword. `{ .. }` would imply sequential execution and no reordering.

Should we introduce lambda lifting inside `seq { .. }`? Might wreak havoc. Else we need a garbage collector.

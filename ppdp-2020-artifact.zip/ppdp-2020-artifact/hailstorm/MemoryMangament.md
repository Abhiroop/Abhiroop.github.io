### Memory Management ideas

Step 1. Check if downward closure or upward

Step 2. If downward no change in function signature else change

Step 3. Start proceeding with the first `let` make it a function if it is a lambda ~~or partially applied~~

Step 4. Look within its scope and replace its call site with what you made of the function


How do we check if function doesn't need to be lambda lifted anymore??

Search all the let expressions in the function and check if any of them are ~~partially applied~~ closures. But is that sufficient??

Basically ensure there are no free variables in the each expression. <- This!!!





----------------------------------------------------------------------------------
We currently heap allocate only closure. So lets see what are the possible types

Downward closures never allow a closure to escape

Upward closures allows allow a closure to escape

Attempt 1:

Escape analysis followed by lambda lifting

```haskell
type UpwardClosure = Closure
type DownwardClosure = Closure

escapeAnalysis :: [Closure] -> ([UpwardClosure], [DownwardClosure])

lambdaLift :: [DownwardClosure] -> [Functions]

trackAndFree :: [UpwardClosure] -> [UpwardClosure with free]
```

```

def sum : (Int -> Int -> Int)
  = \x y -> x + y

def foo (x: Int) (y: Int) : Int
  = sum x y

def bar (x:Int) : (Int -> Int)
  = sum x
  
def baz (y: Int) : Int
  = bar y

```




#### Downward closures

1. Downward closure with no explicit recursion and no closure argument

```
def foo : Int
  = let clos = (\x => x + 1)
     in sum [1..10]
```

The closure doesn't escape, currently we can assess from the return type. 

Lets lambda lift this

```
def foo_clos_0 (x:Int) : Int
  = x + 1

def foo : Int
  = sum [1..10] -- replace all occurences of clos in expression
```

2. Downward closure with recursion but no closure argument


```
-- A highly contrived example
def foo (n:Int) : Int
  = if n == 0 then
      n
      else
         let clo = \y => y + 1
          in foo (n - 1)
```

3. Downward closure with recursion and closure arguments

```
def map (f : (Int -> Int)) (xs : [Int]) : [Int]
  = if length xs == 0 then
      []
      else
       let first_elem = first xs
        in let rest_elems = rest xs
            in cons (f first_elem) (map f rest_elems)      

```

4. Closures with bound variables

```
def addFive (nr : Int) : Int
  = let x    = 5
        addX = \y -> x + y
     in addX nr

```

Lambda Lift the above to
```
def addX_clo_0 (y:Int) (x:Int) : Int
  = x + y

def addFive (nr:Int) : Int
  = let x = 5
     in addX_clo_0 nr x

```

Example from the higher order escape analysis paper

```
def foo : Int
  = let f = \a b => a + b 
     in let g = \h a b => h b a
         in g f l 2

Let Name Closure1 
   (Let Name Closure2 
       (Call Closure2 [Closure1,Lit,Lit]))
```
^ This is allowed in the AST

```
def f_clos_0 (x:Int) (y:Int) : Int
  = x + y

def foo : a
  = let g = \h a b => h b a
     in g f_clos_0 l 2
```

^ This won't be allowed in the L1 as it is write now

```
def f_clos_0 (x:Int) (y:Int) : Int
  = x + y

def g_clos_0 (f: Int -> Int -> Int) (x:Int) (y:Int) : Int
  = f x y

def foo : a
  = g_clos_0 f_clos_0 l 2
  
```

Neither will this be allowed in the current system

#### Upward closures


# :snowflake: hailstorm :snowflake:

<img src="https://github.com/Abhiroop/hailstorm/blob/master/hailstorm.png" alt="drawing" width="100"/>

> Everything should be built top-down, except the first time. - Alan J. Perlis

A *new* functional language targeting memory constrained devices.


### Current features

- Stack allocated closures
- Int, Boolean, Float and single dimensional arrays
- Product types
- Pattern matching on pairs and simple case expressions
- I/O with resource types

### Structure of compiler

<img src="https://github.com/Abhiroop/hailstorm/blob/master/compiler.jpg" alt="drawing" />

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## Installation Instructions


### Mac installation
To run hailstorm programs you need the following on your system

- LLVM (tested for version 8)
- pkg-config
- libffi

Run the following: `export PKG_CONFIG_PATH='/usr/local/opt/libffi/lib/pkgconfig'`

Install the latest version of `stack`

From the root of the project : `stack build`

The `src/Main.hs` is quite trivial to understand you can play around with it after loading it to the repl or call the `compiler` function from the `main` function.

`brew install erlang` for installing erlang

### Ubuntu installation (verified on 16.04)

```
sudo apt install pkg-config

bash -c "$(wget -O - https://apt.llvm.org/llvm.sh)"
wget https://apt.llvm.org/llvm.sh
chmod +x llvm.sh
sudo ./llvm.sh 8 
```

The second script install LLVM 8. Thats all that is needed. Simply install `stack` and do `stack build`

For the Erlang backend
```
sudo apt install erlang
```

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

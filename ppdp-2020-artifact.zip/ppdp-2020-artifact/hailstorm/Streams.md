
## STREAMS :construction:

### NEW DESIGN

First let's talk about what did we deprecate:

Deprecate the following:
```haskell
unwrapIO : IOStream a -> Stream a
wrapIO   : Stream a   -> IOStream a
```

The first function allows us to leave the scope of an effectful function. This has no interpretation in the pure world. Also the lack of a `()` maims our expressive power.

How about an eager version of combinators for dealing with streams?

```haskell
mapS : (a -> b) -> IOStream UDPNetwork a -> IOStream UDPNetwork b
```

This denotes a function whose each input is applied with a function `a  -> b` . First of all the corresponding C code will have the type

```C
void mapS (func f, input config, output config){
  set up
  while (1){
    accept input
    apply f
    send message to other port
  }
}
```

This hailstorm type and the type of the C code generated are absolutely different and they don't seem to capture the truth. The hailstorm type of the C code generated should be:

```haskell
                                      sink    sink value type
                                       |         |
                                       v         v
f : (a -> b) -> IOStream UDPNetwork UDPNetwork a b -> ()
                             ^                 ^
                           source              |
                                         source value type
```

Basically we need a nice way to track all the effects and express all that is happening at that C loop in our surface type system. To do that here is the **new Streams API** :

### New Streams API

```haskell
liftStream : (IO c, IO d) => (Stream a -> Stream b) -> IOStream c d
zipStream  : (IO a, IO b, IO c) => (IOStream a c , IOStream b c) -> IOStream (a, b) c
foldStream : (Container t, IO a, IO b) => (e -> e -> e) -> e -> t (IOStream a b) -> IOStream a b
-- the type parameter `a` can be different across the elements of the container
```
void listen(){
    give me
    give me z

}



Why do we **forgo** the `()` type. At one point of time we need to add the `()` type to our type system but here we almost always deals with event loops with `void` return types. So the presence of a void type doesn't add any new information

Operations on a single stream:

```haskell
mapS : (a -> b) -> Stream a -> Stream b

foldp : (a -> b -> b) -> b -> Stream a -> Stream b

filterS : (a -> Bool) -> Stream a -> Stream a

partitionS : (a -> Bool) -> Stream a -> (Stream a, Stream a)

idS : Stream a -> Stream a

```

Operations on multiple stream

```haskell
interleave : (Container t) => (a -> a -> a) -> t (Stream a) -> Stream a 
-- uses the select POSIX operation
```

The main types:

#### IOStream and Stream

```haskell
      stream sink
           |
           v
IOStream a b
         ^
         |
    stream source
```

An `IOStream` is simply an abstraction which captures information about the source and sinks like if it is network I/O or command line or some other source. Our job is to keep the source and sink types extensible. It doesn't capture any information about the type of the data that flows in. Why? Because we simply read bytes, whatever `Stream` combinator we apply we try to cast the byte buffer to that type. If it fails then it throws a runtime error, otherwise it casts and applies the respective function. Which asks for what exactly is a Stream type?

`Stream a` is what brings laziness into the picture. In pure languages like Haskell the laziness helps differentiate between `evaluation` and `computation`. And in Hailstorm a `Stream` is simply a recipe for laziness. You can think of it as a data structure which stores all the computations that need to be applied to a given stream. And also it stores the `order` in which the operation must happen. So in short a stream is a strucutre which stores 2 thing:

1. The computations that should be applied to an IOStream
2. The order in which these computations need to be applied

So for example something like this :

```haskell
foldp (+) 0 . filter even . map (+3) . map (+ 1) xs -- where xs is some Stream a
```

This operation stores what can be imagined as a heterogenous list (the actual data strucuture is a property of the runtime and is not visible to the user) of computations rather than applying them. This solves the problem of fusion as well. No intermediate structures need to be created, these computations being pure can be fused using good old Bird style algebra of programming laws.

To begin with we experiment with a simple program 

```haskell
def main : IOStream UDPNetwork Terminal =
 liftStream (mapS (+1))

```

generates the following:

We know IOStream type always returns `void` and we get the information about what socket functions to call using `UDPNetwork` and similarly what output function to call(like `printf`) using `Terminal`. Another info we get from the `(map (+ 1))` is that this function accepts an `Int` type.

```
void event_loop(Stream struct, input config from commandline){

f = extract function to apply from Stream
  configure UDP address etc
  while (1){
    read bytes from socket
    type cast to Int
    apply f to the value
    print it to terminal
    keep listening.
  }
}
```

#### (Not so) Open questions

How do we represent `IOStream`s which do multiple effects? Something like a function which reads datagram packets but print to terminal as well as sends them to some other port asynchronously. What does the type of such a function look like?

```haskell
IOStream UDPNetwork (Terminal, UDPNetwork) 
```

This will generate the sink code for both `Terminal` and `UDPNetwork`. And now depending on some run time condition either one of them will be chosen. `partitionS` is built exactly for this kind of situations. For eg: if stream value is greater than threshhold then ring alarm else write to terminal "no earthquake"


```haskell
liftStream $ partitionS (val > threshold)
```

generates

```
while (1){
  if (val > threshold){
    send datagram packet asynchrnously
  }else {
    print "no earthquake" to terminal
  }

}

```

Open question #2 : Do we need fudget style combinators? plain function composition fuses and represents serial composition. Parallel compostion can be done using `interleave`, so how important is `loop`- which can be done using `IOStream a a`

Open question #3 : Should the source and sink types capture some more information about the interfaces? Like port no, ip for networks etc.

#### Future API for interfaces (i.e sources and sinks):

Currently interfaces are simply keywords like `UDPNetwork`, `TCPNetwork`, `Terminal` etc. In future they should be user defined data types which are parametrized by the following typeclass.

```haskell
class IO a where
  getSignal ...
  putSignal ...

instance IO TCPNetwork where ...
instance IO UDPNetwork where ...
instance IO Terminal   where ...

-- user defined interface function
data Foo


instance IO Foo where
```



### OLD DESIGN (Don't READ)
Streams constitute one of the most important parts of Hailstorm. All interactions with the outside world is carried out using streams and its associated combinators. This document serves to jot down the design of Streams currently in my imagination:


Lets take a simple example

Predefined interfaces
```
- TCPNetwork
- UDPNetwork
- Terminal
```

```haskell
defprocess foo (xs : IOStream UDPNetwork Int) : IOStream Terminal Int = xs
```

approx pseudo C code equivalent:
```
struct inputStream {
  details about input stream config like port,ip etc
}

struct outputStream {
  similar details
}
void event_loop(inputStream, outputStream){
  initialize inputStream
  configure outputstrem
  while(1){
    read from inputstream and send to outputstream
  }
}

```

#### IOStream
```
  the element type flowing through the interface
           |
           v
IOStream a b
         ^
    the interface type
```

APIs

```
unwrapIO : IOStream a b -> Stream b
wrapIO   : Stream b     -> IOStream a b
```

So what are Streams?

#### Stream
A stream theoretically represents an infinite stream of elements. Streams are useless without IOStream. It is not possible to construct a stream without an IOStream. However once you have a stream in your system you support a number of useful combinators like :

```
mapS : (a -> b) -> Stream a -> Stream b
foldp : (a -> b -> b) -> b -> Stream a -> Stream b
interleave : [Stream a] -> Stream a
```

What is a Stream at a low level?


A stream is simply a buffer for holding functions to be applied.

Stream -> IOStream is the awkward translation

if we have `Stream -> Config -> IOStream` still makes sense

In pseudo C like code

```C
typedef struct {
 int sockfd
 .....
}IOStream;

typedef struct {
 char buffer[INET6_ADDRSTRLEN]; // max size of 1 message 
 IOStream* rest; // pointer to rest of stream
 ListNode* funcToApply;
}Stream;
```
`funcToApply` doesn't directly apply all the functions to a stream. It buffers the function calls and when finally wrapIO is called it fuses the function and calls them preventing the creation of an additional structure. Let's look at an example.

```haskell
defprocess foo (xs : IOStream UDPNetwork Int) : Stream Int =
  mapS (+ 1) (unwrapIO xs)

defprocess bar (xs : Stream Int) : IOStream UDPNetwork Int =
  wrapIO (mapS (+3) xs)
  
defprocess baz (xs : IOStream UDPNetwork Int) : IOStream UDPNetwork Int =
  bar (foo xs)
```

Let's see what will be the code generated for this piece of code

Unless the return type of the function is IOStream don't run the infinite loop
```
Stream* foo(config){
   return Stream with pointer to the sockfd passed in config i.e foo
   but no while loop
}
```





A simple example:

```haskell
defprocess main (xs : IOStream UDPNetwork Int) : IOStream UDPNetwork Int =
  let x = unwrapIO xs in
  let y = map (+1) x in
  wrapIO y
```




Some awkward cases:

```haskell
defprocess foo : IOStream UDPNetwork Int = ?

defprocess bar (xs : IOStream UDPNetwork Int) : Int = 1

```

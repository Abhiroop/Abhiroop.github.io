## Todos and To Read

### Practical components of a language

- [X] heap allocation
- [X] runtime to manage the heap (unless it is linear/affine typed)
- [ ] FFI (for networking and I/O) . Look at [libffi](https://sourceware.org/libffi/) and [dragon FFI (for LLVM)](https://github.com/aguinet/dragonffi)
- [ ] I/O manager. Look at [llvm memory buffer](https://modocache.io/llvm-memory-buffer)
- [ ] [glibc](https://www.gnu.org/software/libc/)
- [ ] Polymorphism. Efficient ways of implementing polymorphism: see section below.
- [ ] Strings (or bytestrings to be precise :) )
- [X]  Case expressions (desugar to if-then-else)


### Array Languages

- [Sisal](https://eecs.ceas.uc.edu/~paw/classes/ece975/sp2011/papers/feo-90.pdf) - perf comparable to Fortran
- [Single Assignment C](https://link.springer.com/content/pdf/10.1007/s10766-006-0018-x.pdf)
- [Futhark](https://futhark-lang.org/publications/pldi17.pdf)

### Memory management

- [LLVM GC](http://releases.llvm.org/7.0.1/docs/GarbageCollection.html)
- [Destination Passing Style](https://www.microsoft.com/en-us/research/wp-content/uploads/2016/11/dps-fhpc17.pdf)
- [Implicit memory management in Single Assignment C](http://www.sac-home.org/lib/exe/fetch.php?media=publications:pdf:greltrojifl04.pdf)

### Type inference/parametric polymorphism reference

- [Hindley Milner for STLC](http://dev.stephendiehl.com/fun/006_hindley_milner.html)
- [General type checker and type inference discussion on reddit](https://www.reddit.com/r/haskell/comments/89pu1m/resources_for_writing_a_type_checker/)
- [Typing Haskell in Haskell](https://web.cecs.pdx.edu/~mpj/thih/thih.pdf)
- [Polymorphic variants in OCaml](https://caml.inria.fr/pub/papers/garrigue-polymorphic_variants-ml98.pdf)
- [Fake polymorphic variants in Haskell](http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.96.7036&rep=rep1&type=pdf)
- [Basic Polymorphic Typechecking](http://lucacardelli.name/Papers/BasicTypechecking.pdf)

### Polymorphism

- [Intensional polymorphism](https://www.cs.cmu.edu/~rwh/papers/intensional/popl95.pdf) - The most recent take.
- [Tagged and parametric polymorphism](http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.98.2165&rep=rep1&type=pdf) - Leads to code explosion
- [Typeclass based approach](https://pdfs.semanticscholar.org/965c/12beac6d8abc72328d0f69fdbe5818a8da43.pdf)
- [Parametric Polymorphism in .NET](http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.28.9807&rep=rep1&type=pdf)
- [Unboxed multi word representation in Ocaml](https://xavierleroy.org/publi/unboxed-polymorphism.pdf)
- [TIL : intensional polymorphism, tag-free garbage collection, conventional functional language optimization,
and loop optimization.](https://apps.dtic.mil/dtic/tr/fulltext/u2/a306265.pdf)
- [An ad hoc approach to the implementation of polymorphims](https://al.host.cs.st-andrews.ac.uk/pubs/MDC+91.pdf)
- [Swift generics](https://www.reddit.com/r/rust/comments/7gkiie/implementing_swift_generics_video/)

### I/O

- [Clean's uniqueness types](http://citeseerx.ist.psu.edu/viewdoc/download;jsessionid=E725ADC5F4F4B360A1209DB64B3B2237?doi=10.1.1.17.935&rep=rep1&type=pdf)
- [Andrew Gordon's thesis on functional programming I/O](https://www.microsoft.com/en-us/research/uploads/prod/2016/11/fpio.pdf)
- [Algebraic Effect system in Koka](https://www.microsoft.com/en-us/research/wp-content/uploads/2016/08/algeff-tr-2016-v3.pdf)
- [Koka lang type inference of effects](https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/paper-20.pdf)
- [My explanation of Elm I/O](https://www.reddit.com/r/elm/comments/cpidhx/easy_questions_beginners_thread_week_of_20190812/ewrfp6u/)

### Concurrency Models

- [Concurrent Revisions](http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.384.571&rep=rep1&type=pdf)
- [Concurrent Revisions in Haskell](https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/PrettierConcurrency-Haskell2011.pdf)
- [Actor Model - Carl Hewitt](https://arxiv.org/pdf/1008.1459.pdf&amp)
- [Tuple spaces](https://s3.amazonaws.com/academia.edu.documents/1244183/sac-o.pdf?AWSAccessKeyId=AKIAIWOWYYGZ2Y53UL3A&Expires=1557504797&Signature=w9pkYR8DABCosXFLW9rl%2BbJj4TE%3D&response-content-disposition=inline%3B%20filename%3DOn_the_Semantics_of_Tuple-Based_Coordina.pdf)

### Memory Model

- Revisions above
- [CompCert C memory model](https://xavierleroy.org/publi/memory-model-journal.pdf)
- [CompCert C memory model improvement](https://hal.inria.fr/hal-00703441/document)

### Effects

- [Algebraic effects and handlers tutorial](https://www.eff-lang.org/handlers-tutorial.pdf)

### Compiling Functional Languages
- [Compiling Functional Languages by Xavier Leroy](https://xavierleroy.org/talks/compilation-agay.pdf)
- [Compiling ML by Luca Cardelli](http://lucacardelli.name/Papers/CompilingML.A4.pdf)
- [OCaml - Didier Rémy](http://gallium.inria.fr/~remy/cours/appsem/ocaml.pdf)

### Desirable Aspects

- Hindley Milner type inference!
- DeriveGeneric for JSON. A better design according to me is `edn` notation in Clojure
- ML Modules vs Clojure Protocols
- Compare [Tuple Space](https://en.wikipedia.org/wiki/Tuple_space) vs Actors
- Native support for - arrays, streams, maps and sets thats all.
  - [Transfinite arrays](https://arxiv.org/pdf/1710.03832.pdf) - Unifying arrays and streams
- User defined types
  - statically size known types like structs in C (tuple/record analogue in Haskell)
  - or value types in C#. Read [Eric Lippert's article on value types](https://blogs.msdn.microsoft.com/ericlippert/2010/09/30/the-truth-about-value-types/)
  - C# conservatively heap allocates value types but certain compile time analysis can calculate and place the struct on the stack or even registers
  - Rust stores structs in the stack (in fact almost everything unless its a `Box`). Read about [Rust's memory model](https://doc.rust-lang.org/1.30.0/book/first-edition/the-stack-and-the-heap.html)
- Enum(or sum) types (implemented like C which are simply wrappers over integers?)

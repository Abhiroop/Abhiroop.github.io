## ADTs and tuples

This document tracks the changes that we need to make to support full algebraic data types. ADTs(we refer algebraic data types as ADTs please do not confuse with abstract data types) almost always require the prescence of garbage collectors. To start with we need to support `tuples`

I believe algebraic data types can be compiled to tuples.

```haskell
data Tree a = Leaf
            | Node a (Tree a) (Tree a)

Node 5 (Node (Node 4 Leaf Leaf) (Node 3 Leaf Leaf)) (Node (Node 1 Leaf Leaf) (Node 2 Leaf Leaf))
```

Provided we support tuples the above can be compiled to tuples.

However user defined recursive types are almost always allocated on the heap. How do we bypass that?

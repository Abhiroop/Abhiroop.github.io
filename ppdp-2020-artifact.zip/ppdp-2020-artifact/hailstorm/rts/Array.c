#include<stdlib.h>
#include<stdio.h>
#include<stddef.h>
#include<string.h>

#include "Array.h"


typedef elem_t (*tabulate_func)(const int);

static elem_t* tabulate(const size_t size,
                        const capacity_t count,
                        const tabulate_func f) {
  elem_t* arr = malloc(offsetof(elem_t, data) + size * count);
  if (arr) {
    arr -> size = size;
  }
  for (int i = 0; i < count; i++) {
    arr[i] = f(i);
  }

  return arr;
}

static log newLog (const size_t size){
  elem_t nothing = {0,0};
  entry nullEntry = {-1,nothing};
  // sizeof(int) for version + the size of the actual type
  entry* entry_Nothing = malloc(1*(sizeof(int) + size));
  entry_Nothing[0]= nullEntry;
  log log = {1,0,entry_Nothing};
  return log;
}

static elem_t initNothing (const int dummy){
  elem_t nothing = {0,0};
  entry nullEntry = {-1,nothing};
  elem_t e = {sizeof(nullEntry), (void*)&nullEntry};
  return e;
}

static log push (const size_t size, const log l, const entry e){
  int c = l.capacity;
  int s = l.size;
  entry* d = l.entry_arr;
  log l_new;
  if (c == s){
    int c_1 = 2 * c;
    tabulate_func funcPtr1 = &initNothing;
    entry* d_1 = (entry*)tabulate(size, c_1, funcPtr1);
    memcpy(d_1, d, (size*s)); // c==s so same as (size*c)
    d_1[s] = e;
    l_new.capacity = c_1;
    l_new.size = s + 1;
    l_new.entry_arr = d_1;
  } else {
    d[s] = e;
    l_new.capacity = c;
    l_new.size = s + 1;
    l_new.entry_arr = d;
  }
  return l_new;
}

static entry binSearchEntry (const entry* entryArr,
                             const version_t v,
                             int lower,
                             int upper){
  int mid = (lower + upper)/2;
  entry found = entryArr[mid];
  if (lower == upper){
    return found;
  }else{
    if(found.version < v){
      return binSearchEntry(entryArr, v, (mid+1), upper);
    }else{
      return binSearchEntry(entryArr, v, lower, mid);
    }
  }
}

static elem_t getVersion(const log l,
                         const version_t v) {
  int c = l.capacity;
  int s = l.size;
  entry* d = l.entry_arr;
  elem_t nothing = {0,0};
  if (s == 0) {
    return nothing;
  } else {
    entry ent = d[s-1];
    if(ent.version == -1){
      return nothing;
    } else {
      version_t v_ent = ent.version;
      if (v_ent < v){
        return nothing;
      } else {
        //binsearch
        entry e_seek = binSearchEntry(d, v, 0, (s - 1));
        if(e_seek.version == -1){
          return nothing;
        } else {
          return e_seek.data;
        }
      }
    }
  }
  return nothing;
}

sequence new(const size_t size,
             const capacity_t count,
             const elem_t a){
  elem_t* arr = malloc(count*size);
  for (int i = 0; i < count; i ++){
    arr[i] = a;
  }
  logs_t log_arr = malloc(count * sizeof(log));
  for (int i =0; i< count; i++){
    log_arr[i] = newLog(size);
  }
  array_data data = {1, count, arr, log_arr};
  sequence seq = {1, data};
  return seq;
}

elem_t get(const sequence* s,
           const int idx){
  elem_t guess = s->array_data.arr[idx];
  log l = s->array_data.logs[idx];
  version_t v = s->version;
  version_t vr = s->array_data.version;
  if (v == vr){
    return guess;
  } else {
    elem_t e = getVersion(l, v);
    if(e.size == 0){
      return guess;
    } else {
      return e;
    }
  }
}

sequence set(const size_t size,
             sequence* s,
             const int idx,
             const elem_t e){
  version_t* vr;
  elem_t* arr = s->array_data.arr;
  int n = s->array_data.capacity;
  vr = &s->array_data.version;
  version_t v  = s->version;
  logs_t l = s->array_data.logs;
  bool b = __sync_bool_compare_and_swap(vr, v, v+1);
  if(!b || *vr == n){
    elem_t* arr_2 = malloc(size * n);
    //memcpy(arr_2, arr, (size * n));
    //plain memcpy doesn't fetch the correct version
    for(int i =0; i < n ; i++){
      arr_2[i] = get(s,i);
    }
    logs_t l_2 = malloc(n *
                        (sizeof(capacity_t) +
                         sizeof(size) +
                         1 * sizeof(entry))); // initialize log with just an array of capacity 1
    for(int i = 0; i < n ; i++){
      l_2[i] = newLog(size);
    }
    arr_2[idx] = e;
    sequence s_new = {1, {1, n, arr_2, l_2}};
    return s_new;
  } else {
    entry ent = {s->array_data.version,s->array_data.arr[idx]};
    log p = push(size,l[idx],ent);
    s->array_data.arr[idx] = e;
    s->array_data.logs[idx] = p;
    sequence s_new = {(v+1),s->array_data};
    return s_new;
  }
}

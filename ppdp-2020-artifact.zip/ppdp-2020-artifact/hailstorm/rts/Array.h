#include <stdbool.h>
#include <stddef.h>

typedef int capacity_t;
typedef int arr_size_t;
typedef int version_t;

/*
  Denotes the polymorphic type `T`
  where size is the size of the
  data type, the data could be Int,
  Bool, sum type, product type etc
  IMP: {0,0} represents the abscence
  of `T` or Nothing
*/
typedef struct {
  size_t size;
  void* data;
} elem_t;


typedef struct {
  version_t version;
  elem_t data;
} entry;


typedef struct {
  capacity_t capacity;
  arr_size_t size;
  entry* entry_arr;
}log;

typedef log* logs_t;

typedef struct {
  version_t version;
  capacity_t capacity;
  elem_t* arr;
  logs_t logs;
}array_data;

typedef struct{
  version_t version;
  array_data array_data;
}sequence;


/* Create an array of length `n` where */
/* the size of each element is `size` */
/* and initializes all elements to `v` */
/* Usage : new(size, n , v) */
sequence new(size_t, capacity_t, elem_t);

/* Returns the ith element of `A` */
/* Usage : get(A, i) */
elem_t get(const sequence*, int);

/* Returns a new array where the ith */
/* element of size `size` is replaced by v */
/* Usage : set(size, A, i, v) */
sequence set (size_t, sequence*, int, elem_t);

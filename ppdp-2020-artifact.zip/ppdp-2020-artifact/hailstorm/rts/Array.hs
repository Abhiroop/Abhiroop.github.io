module Array where

import Protolude hiding (modify, (++), length, get)
import Data.Atomics
import Data.IORef
import Data.Vector hiding (update)
import Data.Vector.Mutable (write)

type Capacity = Int
type Size = Int
type Version = Int

data Entry a = Entry Version a

type Log a = IORef (Capacity, Size, (Vector (Maybe (Entry a))))

new_Log :: IO (Log a)
new_Log = newIORef $ (1, 0, tabulate 1 (\_ -> Nothing))

push :: Log a -> Entry a -> IO (Log a)
push log v = do
  (c,s,d) <- readIORef log
  if c == s
  then let c' = 2 * c
           d' = tabulate c (\_ -> Nothing)
           d'' = update d' s (Just v)
        in do
         writeIORef log (c', s+1, d++d'') --very suboptimal way can do better in SML
         return log
  else let d' = update d s (Just v)
        in do
         writeIORef log (c, s+1, d')
         return log

getVersion :: Log a -> Version -> IO (Maybe a)
getVersion log v = do
  (c,s,d) <- readIORef log
  if s == 0
  then return $ Nothing
  else let Just (Entry v' _) = d ! (s-1)
        in if v' < v
           then return Nothing
           else return $ Just (binSearch d v s)
  where
   binSearch log version size = binRecur log version 0 (size - 1)
   binRecur log version lower upper =
     let mid = (lower + upper) `div` 2
         Just (Entry v value) = log ! mid
       in if lower == upper then value
          else if v < version then binRecur log version (mid+1) upper
          else binRecur log version lower mid

tabulate :: Capacity -> (Int -> a) -> Vector a
tabulate = generate

sub :: Vector a -> Int -> Maybe a
sub = (!?)

update :: Vector a -> Int -> a -> Vector a
update v i a = modify (\e -> write e i a) v


type Logs a = Vector (Log a)

data ArrayData a = ArrayData (IORef Version)
                             (Vector a)
                             (Logs a)

data Sequence a = Sequence Version (ArrayData a)

new :: Capacity -> a -> IO (Sequence a)
new capacity init = do
  ref <- newIORef 1
  let arr = tabulate capacity (\_ -> init)
  logs <- sequenceA $ tabulate capacity (\_ -> new_Log)
  return $ Sequence 1 (ArrayData ref arr logs)

get :: Sequence a -> Int -> IO a
get (Sequence v (ArrayData vr arr log)) i =
  let guess = arr ! i
      l = log ! i
   in do
    ref <- readIORef vr
    if v == ref
    then return guess
    else do
      val <- getVersion l v
      case val of
         Nothing -> return guess
         Just a  -> return a

set :: Sequence a -> Int -> a -> IO (Sequence a)
set s@(Sequence v (ArrayData vr arr logs)) i val = do
  version <- readIORef vr
  versionCAS <- readForCAS vr
  (bool, _) <- casIORef vr versionCAS (version + 1)
  if (not bool) || (version == length arr)
  then do
    let n = length arr
    arr' <- sequenceA $ tabulate n (\i -> get s i)
    l' <- sequenceA $ tabulate n (\_ -> new_Log)
    let new_arr = update arr i val
    new_ver <- newIORef 1
    return $ Sequence 1 (ArrayData new_ver new_arr l')
  else do
    log' <- push (logs ! i) (Entry v (arr ! i))
    let logs' = update logs i log'
    let arr_upd = update arr i val
    return $ Sequence (v+1) (ArrayData vr arr_upd logs')

test :: IO ()
test = do
  x <- new 5 1
  let y = x
  a <- get y 1
  s' <- set y 1 (a + 2)
  a' <- get s' 1
  print a'
  foo <- get x 1
  print foo


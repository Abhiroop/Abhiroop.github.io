#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

int validate ( char *a )
{
  unsigned x;
  for ( x = 0; x < strlen ( a ); x++ )
    if ( !isdigit ( a[x] ) ) return 1;
  return 0;
}

int readIntStream()
{
  int i;
  char buffer[BUFSIZ];
  if ( fgets ( buffer, sizeof buffer, stdin ) != NULL ) {
    buffer[strlen ( buffer ) - 1] = '\0';
    if ( validate ( buffer ) == 0 ) {
      i = atoi ( buffer );
      return i;
    }
    else
      printf ( "Error: Input validation\n" );
  }
  else
    printf ( "Error reading input\n" );
  return 0;
}


void writeIntStream(int a){
  printf("%d",a);
}

int add5 (int a){
  return a + 5;
}

int foo(){
  int a = readIntStream();
  return a;
}

/* int main(){ */
/*     int a = readIntStream(); */
/*     printf("%d\n",a); */
/*   /\* int (*fun_ptr)() = &readIntStream; *\/ */
/*   /\* //int c = (*fun_ptr)(); *\/ */
/*   /\* int (*fun_ptr2)(int) = &add5; *\/ */
/*   /\* //int temp = (*fun_ptr2)((*fun_ptr)()); *\/ */
/*   /\* void (*fun_ptr3)(int) = &writeIntStream; *\/ */
/*   /\* (*fun_ptr3)((*fun_ptr2)((*fun_ptr)())); *\/ */
/*   return 0; */
/* } */

/*

read from S1

multiply by 5 and write from S1

read from S2

multiply by 10

write from S2



foo : SF S1 () Int
foo = readIntStream

bar : SF S1 Int ()
bar = writeIntStream

baz : SF S1 () ()
baz = foo >>> mapSignal (\x -> x * 5) >>>bar

// compiled to

baz = \temp -> WRITEINTSTREAM ((\x -> x * 5) (READINTSTREM temp))




quux : SF S2 () Int
quux = readIntStream

grault : SF S2 Int ()
grault = writeIntStream

corge : SF S2 () ()
corge = quux >>> mapSignal (\x -> x * 10)  >>> grault

// compiled to

corge = \temp -> WRITEINTSTREAM ((\x -> x * 10) (READINTSTREM temp))

main : SF (S1 U S2) () ()
main = baz >>> corge

// compiled to

main = \t -> corge (baz t)


Can we interpret call simply as a semicolon???


void baz(temp){
(*fun_ptr3)((*fun_ptr2)((*fun_ptr)()));
}

void corge(temp){
(*fun_ptr3)((*fun_ptr2)((*fun_ptr)()));
}


void main(temp){
   baz;
   corge(baz(temp))
}



lets compile readIntStream to start with it is simply a function call.

so something like `READINTSTREAM` will be compiled into a function call like
(*fun_ptr)(). Define READINTSTREAM in the runtime or check the generated LLVM
to find if we can compile it simply with no linking


WRITEINTSTREAM compiles to (CALL WRITEINTSTREAM [foo]) if foo not present throw error


All signal functions in the main will compile to a while loop. Other signal
functions stay the same.

what about:

main = let x = baz >>> corge in
       let y = 5 in
       y

how about if type of a term in main is `signal function from void to void` use while(true) else keep it same


SF () () this is the key to identifying an event loop.


How about compiling `SF () a` or `SF a ()` passing null is risky in such case

Compile such `SF a ()` functions normally.

Pass the token technique only for `SF () a` the () on the left means its a call to read
which doesn't require an argument.



1. Things of type SF () () should be compiled to a `while (true)` in main
2. Things of type SF () _ should be passed a runtime token(possibly null) in main to activate them








*/

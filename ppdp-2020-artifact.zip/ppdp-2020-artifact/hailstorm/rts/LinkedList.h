/* A generic LinkedList<T> capable of holding any structure */
/* Non thread safe */

typedef void* elem_t;

struct Node
{
	elem_t data;
	struct Node* next;
};

struct Node* newLinkedList();

void cons(struct Node** head_ref, elem_t new_data);

void freeLinkedList(struct Node** head_ref);

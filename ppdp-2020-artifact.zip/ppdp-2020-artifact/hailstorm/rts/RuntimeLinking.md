## Runtime Linking

How to link the runtime with the compiler.

See here: https://stackoverflow.com/questions/1419139/llvm-linking-problem

One option compile the runtime using `llvm-gcc` and then link the 2 generated files using `llvm-ld` and then do use `llc` and `gcc` to create the binary


My answer : https://stackoverflow.com/a/56715922/1942289

In the `L2` codegen generate all the `declare` statements for all the functions in `Array.h` and call those declared functions.

Use this : `clang -emit-llvm -femit-all-decls -S Array.c` to generate all the llvm equivalent functions


## Selective Linking

When installing the compiler on a system it should first `stack build` the entire project and then compile the whole rts to its llvm representation and keep the llvm files on disk somewhere. Now the compiler when compiling a hailstorm source file should analyse the whole program and selectively link parts of the rts. For eg: in the below program :

```
def foo : Int = 5 + 3
```

no aggregate structures are used so no need to link Array.ll

We should not checkin the llvm files (like Array.ll) because it will be different for each machine and each version.

How do we distribute a static binary?

Compile the llvm files for each respective architecture and when calling "brew install" place the llvm files in some required location and do selective linking.

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <inttypes.h>


#include <ctype.h>
#include <errno.h>
#include <limits.h>



#include "Stream.h"

typedef char byte;

typedef enum {
  STR2INT_SUCCESS,
  STR2INT_OVERFLOW,
  STR2INT_UNDERFLOW,
  STR2INT_INCONVERTIBLE
} str2int_errno;

str2int_errno str2int(int *out, char *s, int base) {
  char *end;
  if (s[0] == '\0' || isspace(s[0]))
    return STR2INT_INCONVERTIBLE;
  errno = 0;
  long l = strtol(s, &end, base);
  /* Both checks are needed because INT_MAX == LONG_MAX is possible. */
  if (l > INT_MAX || (errno == ERANGE && l == LONG_MAX))
    return STR2INT_OVERFLOW;
  if (l < INT_MIN || (errno == ERANGE && l == LONG_MIN))
    return STR2INT_UNDERFLOW;
  /* Currently disabled test */
  /* if (*end != '\0') */
  /*   return STR2INT_INCONVERTIBLE; */
  *out = l;
  return STR2INT_SUCCESS;
}

// get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa)
{
	if (sa->sa_family == AF_INET) {
		return &(((struct sockaddr_in*)sa)->sin_addr);
	}

	return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

// currently supported atomic types in Hailstorm
typedef enum {
   INT,
   BOOL
} TYPE;

// using a local variable for this leads to a non deterministic error.
TYPE t_global;

void event_loop(int max_buf_len_cmd, char* port_cmd, Stream* myStream)
{

  // initializing this locally leads to a non deterministic error.
  // try placing this declaration after the memset call below and
  // the struct becomes null
  struct Node** content = myStream->stream_combs;
  struct Node* hd = *content;

  //                  UDP CONFIGURATION BEGINS                //

  struct addrinfo hints, *res, *p;

  memset(&hints, 0, sizeof hints);
  hints.ai_family = AF_UNSPEC; // set to AF_INET to force IPv4
	hints.ai_socktype = SOCK_DGRAM;
	hints.ai_flags = AI_PASSIVE; // use my IP


  int rv = getaddrinfo(NULL, port_cmd, &hints, &res);
	if (rv != 0) {
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
	}


  int sockfd;
	// loop through all the results and bind to the first we can
	for(p = res; p != NULL; p = p->ai_next) {
    sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
		if (sockfd == -1) {
			perror("listener: socket");
			continue;
		}

		if (bind(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
			close(sockfd);
			perror("listener: bind");
			continue;
		}

		break;
	}

	if (p == NULL) {
		fprintf(stderr, "listener: failed to bind socket\n");
		exit(2);
	}

	freeaddrinfo(res);

  //        UDP CONFIGURATION ENDS HERE     //


  //        EVENT LOOP BEGINS      //
  struct sockaddr_storage their_addr;
  while (1) {
    byte recv_buf[max_buf_len_cmd]; // receive message in this byte buffer
    socklen_t addr_len = sizeof their_addr;
    int numbytes = recvfrom(sockfd, recv_buf, max_buf_len_cmd-1 , 0, (struct sockaddr *)&their_addr, &addr_len);
    if (numbytes == -1) {
      perror("recvfrom");
      exit(1);
    }
    recv_buf[numbytes] = '\0';


    // cast byte buffer and apply stream functions here //
    switch(t_global){
    case INT :{
      int num;
      assert(str2int(&num,recv_buf, 10) == STR2INT_SUCCESS);
      printf("listener: packet originally contained : %d\n", num);
      int result = num;
      if (myStream != NULL){
        struct Node* tmp = hd;
        while(hd != NULL){
           // opportunity to do fusion here by the compiler
           StreamComb* dangerous = (StreamComb*)hd->data;
           switch(dangerous->comb){
           case MAP:{
             map_func f= dangerous->map_f;
             result = (int)f((elem_a)result);
             printf("packet transformed to : %d\n", result);
             break;
           }
           case FOLD:
             break;
           }
           hd = hd->next;
           }
        hd = tmp;
      }
      break;
    }
    case BOOL:
      break;
    }


    //  cast and apply ends here //

  }

  //         EVENT LOOP ENDS        //
	close(sockfd);
}

Stream* initS() { return NULL; }

Stream* mapS(const map_func f, Stream* s){
  StreamComb* scomb = malloc(sizeof(StreamComb));
  scomb->comb = MAP;
  scomb->map_f = f;
  if(s == NULL){
    struct Node* init = newLinkedList();
    s = malloc(sizeof(Stream));
    s->stream_combs = &init;
    cons(&init, scomb);
    return s;
  }else{
    struct Node** scombs = s->stream_combs;
    cons(scombs, scomb);
    return s;
  }
}

Stream* foldp(const fold_func f, const elem_b e_b, Stream* s){
  FoldParams* fparams = malloc(sizeof(FoldParams));
  fparams->fold_f = f;
  fparams->b = e_b;
  StreamComb* scomb = malloc(sizeof(StreamComb));
  scomb->comb = FOLD;
  scomb->fold_params = fparams;
  if(s == NULL){
    struct Node* init = newLinkedList();
    s = malloc(sizeof(Stream));
    s->stream_combs = &init;
    cons(&init, scomb);
    return s;
  }else{
    struct Node** scombs = s->stream_combs;
    cons(scombs, scomb);
    return s;
  }
}


int test(int x){
  return x + 5;
}

int test2(int x){
  return  x * 5;
}


int main(){
  int max_buffer_size = 100;
  char port[] = "4950";
  Stream* s = initS();
  Stream* foo = mapS((map_func)test, s);
  Stream* bar = mapS((map_func)test2, foo);
  t_global = INT;
  event_loop(max_buffer_size, port, bar);

  return -1;
}



/* int main(){ */
/*   Stream* foo = initS(); */
/*   Stream* bar = mapS((map_func)test, foo); */
/*    -- eval begins below
/*   struct Node** baz = bar->stream_combs; */
/*   struct Node* hd = *baz; */
/*   elem_t quux = hd->data; */
/*   StreamComb* dangerous = (StreamComb*)quux; */
/*   switch(dangerous->comb){ */
/*   case MAP : */
/*     printf("In MAP"); */
/*     map_func grault = dangerous->map_f; */
/*     int z = (int)grault((elem_a)5); // should give 10; */
/*     printf("Test my casting beast %d:",z); */
/*     break; */
/*   case FOLD: */
/*     printf("In FOLD"); */
/*     break; */
/*   } */
/*   return -1; */
/* } */





/*


  Reference BSD socket structs
  ----------------------------
  struct addrinfo {
  int              ai_flags;     // AI_PASSIVE, AI_CANONNAME, etc.
  int              ai_family;    // AF_INET, AF_INET6, AF_UNSPEC
  int              ai_socktype;  // SOCK_STREAM, SOCK_DGRAM
  int              ai_protocol;  // use 0 for "any"
  size_t           ai_addrlen;   // size of ai_addr in bytes
  struct sockaddr *ai_addr;      // struct sockaddr_in or _in6
  char            *ai_canonname; // full canonical hostname

  struct addrinfo *ai_next;      // linked list, next node
  };


  struct sockaddr {
  unsigned short    sa_family;    // address family, AF_xxx
  char              sa_data[14];  // 14 bytes of protocol address
  };

  struct sockaddr_in {
  short            sin_family;   // e.g. AF_INET, AF_INET6
  unsigned short   sin_port;     // e.g. htons(3490)
  struct in_addr   sin_addr;     // see struct in_addr, below
  char             sin_zero[8];  // zero this if you want to
  };

  struct sockaddr_in6 {
  u_int16_t       sin6_family;   // address family, AF_INET6
  u_int16_t       sin6_port;     // port number, Network Byte Order
  u_int32_t       sin6_flowinfo; // IPv6 flow information
  struct in6_addr sin6_addr;     // IPv6 address
  u_int32_t       sin6_scope_id; // Scope ID
  };

  struct sockaddr_storage {
  sa_family_t  ss_family;     // address family
  // sa_family_t is an unsigned integer.
  // Windows doesn't conform to this. Damn them!

  // all this is padding, implementation specific, ignore it:
  char      __ss_pad1[_SS_PAD1SIZE];
  int64_t   __ss_align;
  char      __ss_pad2[_SS_PAD2SIZE];
  };

 */

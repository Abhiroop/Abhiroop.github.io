#include "LinkedList.c"
// polymorphic types A, B, T
typedef void* elem_a;

typedef void* elem_b;

typedef void* elem_t;

typedef enum { MAP, FOLD } Combinators;

typedef elem_b (*map_func)(const elem_a);

typedef elem_b (*fold_func)(const elem_a, const elem_b);

typedef struct {
  fold_func fold_f;
  elem_b b;
}FoldParams;

typedef struct {
  Combinators comb;
  union {
    map_func map_f;
    FoldParams* fold_params;
  };
} StreamComb;

/*
Usage of StreamComb given some StreamComb element scomb
switch(scomb. comb){
 case MAP:
   .....
   break;
 case FOLD:
   ....
   break;
 }
*/

typedef struct {
  struct Node** stream_combs;
} Stream;

Stream* initS();

Stream* mapS(const map_func, Stream*);

Stream* foldp(const fold_func, const elem_b, Stream*);

module Streams where

import Protolude

data StreamComb a b = Map (a -> b)
                    | Fold (a -> b -> b) b
                    | Filter (a -> Bool)
                    | Partition (a -> Bool)
                    | Id

type Stream a b = [StreamComb a b]

mapS :: (a -> b) -> Stream a b -> Stream a b
mapS f xs = Map f : xs

foldp :: (a -> b -> b) -> b -> Stream a b -> Stream a b
foldp f init xs = Fold f init : xs

filterS :: (a -> Bool) -> Stream a b -> Stream a b
filterS p xs = Filter p : xs


             -- val extracted from stream
             --          |
             --          v
interp :: Stream a b -> [a] -> [b]
interp s vals = undefined
{-
fusion s = side effecting
for (i =0 ; i < length vals; i++){
  apply (fusion s)

}


-}

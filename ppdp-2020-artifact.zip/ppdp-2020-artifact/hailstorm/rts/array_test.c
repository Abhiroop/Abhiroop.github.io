#include<stdlib.h>
#include<stdio.h>
#include<stddef.h>
#include<string.h>
#include<assert.h>

#include "Array.c"

static elem_t identity(int i){
  elem_t e = {sizeof(int),(void*)(i*2)};
  return e;
}

void tabulateFunc(){
  // test higher order function + tabulate function
  tabulate_func funcPtr = &identity;
  elem_t* arr = tabulate(sizeof(int), 10, funcPtr);
  int test_arr[10];
  int result_arr[] = {0,2,4,6,8,10,12,14,16,18};
  for(int i=0; i < 10; i++){
    test_arr[i] = (int)arr[i].data;
  }
  assert (memcmp(test_arr, result_arr, sizeof(test_arr)) == 0);
  printf("Tabulate function works!\n");
}

void pushFuncThen(){
  // the case when capacity == size
  elem_t a_1 ={4,(void*)5};
  elem_t a_2 ={4,(void*)6};
  entry e_1 = {1, a_1};
  entry e_2 = {1, a_2};
  elem_t a_null ={4,(void*)5};
  entry e_null = {-1, a_null};

  entry arr[] = {e_1,e_2};
  log l = {2,2,arr};
  elem_t a_3 ={4,(void*)7};
  entry e_3 = {1, a_3};
  log l_1 = push(sizeof(entry),l,e_3);
  entry* foo = l_1.entry_arr;
  int test_arr[3];
  int result_arr[] = {5,6,7};
  for(int i=0; i < 3; i++){
    test_arr[i] = (int)foo[i].data.data;
  }
  assert (memcmp(test_arr, result_arr, sizeof(test_arr)) == 0);
  printf("Push function then case works!\n");
}

void pushFuncElse(){
  // the case when capacity is ! = size
  elem_t a_1 ={4,(void*)5};
  elem_t a_2 ={4,(void*)6};
  entry e_1 = {1, a_1};
  entry e_2 = {1, a_2};
  elem_t a_null ={0,(void*)0};
  entry e_null = {-1, a_null};
  entry arr[] = {e_1, e_2, e_null};
  log l = {3,2,arr};
  elem_t a_3 ={4,(void*)10};
  entry e_3 = {1, a_3};
  log l_1 = push(sizeof(entry),l,e_3);
  entry* foo = l_1.entry_arr;
  int test_arr[3];
  int result_arr[] = {5,6,10};
  for(int i=0; i < 3; i++){
    test_arr[i] = (int)foo[i].data.data;
  }
  assert (memcmp(test_arr, result_arr, sizeof(test_arr)) == 0);
  printf("Push function else case works!\n");
}

void getVersionFunc1(){
  elem_t a_null ={0,(void*)0};
  entry e_null = {-1, a_null};
  entry arr[] = {e_null};
  log l = {1,0,arr};
  elem_t foo = getVersion(l,1);
  assert(foo.size == 0); // an element T of size 0 represents Nothing
  printf("getVersion Size 0 case works!\n");
}

void getVersionFunc2(){
  elem_t a_1 ={4,(void*)10};
  elem_t a_2 ={4,(void*)11};
  elem_t a_3 ={4,(void*)12};
  elem_t a_4 ={4,(void*)13};
  entry e_1 = {1, a_1};
  entry e_2 = {3, a_2};
  entry e_3 = {5, a_3};
  entry e_4 = {7, a_4};
  entry arr[] = {e_1, e_2, e_3, e_4};
  log l = {4,4,arr};
  elem_t foo = getVersion(l,4);
  assert((int)foo.data == 12);
  printf("getVersion binary search case works!\n");
}

void initSequence(){
  elem_t a_1 = {sizeof(int),(void*)3};
  sequence seq = new (sizeof(int), 5, a_1); // See NOTE 1
  for(int i =0; i < 5; i++){
    assert((int)seq.array_data.arr->data == 3);
  }
  printf("Sequence initialization works\n");
}

// This function tests the persistent
// quality of the sequence
void persistenceTest(){
  elem_t a_1 = {sizeof(int),(void*)0};
  sequence a = new (sizeof(elem_t), 5, a_1);
  elem_t a_2 = {sizeof(int),(void*)5};
  sequence b = set (sizeof(elem_t), &a, 2, a_2);
  elem_t a_3 = {sizeof(int),(void*)9};
  sequence d = set (sizeof(elem_t), &a, 0, a_3);

  for(int i = 0 ; i < 5; i ++){
    elem_t e = get(&a,i);
    assert((int)e.data == 0);
  }

  for(int i = 0 ; i < 5; i ++){
    elem_t e = get(&b,i);
    if(i == 2)
      assert((int)e.data == 5);
    else
      assert((int)e.data == 0);

  }

  for(int i = 0 ; i < 5; i ++){
    elem_t e = get(&d,i);
    if(i == 0)
      assert((int)e.data == 9);
    else
      assert((int)e.data == 0);
  }
  printf("Persistence works\n");
}

int main (){
  persistenceTest();
  initSequence();
  pushFuncThen();
  pushFuncElse();
  tabulateFunc();
  //XXX: Reversing the order of the above function calls leak memory!
  // Need to investigate why
  getVersionFunc1();
  getVersionFunc2();
}


//NOTE 1
/* It is surprising behavior that just giving a (sizeof (int)) is */
/* sufficient when the element is actually storing the size + the int element */
/* which should be (2 * sizeof (int)) but that leaks memory however */
/* (sizeof (elem_t)) works but that is inefficient */

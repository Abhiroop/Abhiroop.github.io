{-# LANGUAGE DeriveGeneric #-}

module AST where

import qualified Data.Map as Map
import qualified Data.Set as Set
import Protolude hiding (Type)

type Name = Text

newtype RName = RName Name
  deriving (Show, Eq, Ord)

data ResourceTy = Empty
                | Singleton RName
                | Union ResourceTy ResourceTy
                deriving (Show, Ord)

-- | See at the bottom alongside NOTE 2
-- why we separately defined resource equality
instance Eq ResourceTy where
  (==) = rEql

-- | A resource is purely a type level entity
newtype Resource =
  R ResourceTy
  deriving (Show, Eq, Ord)

data Type
  = TVoid -- void type -- see NOTE 1
  | TInt  -- Integer type
  | TFloat -- Float type
  | TBool -- Boolean type
  | TArr Type Type -- function type
  | TSeq Type -- sequence type
  | TPair Type Type -- pairs
  | TSF ResourceTy Type Type
  deriving (Show, Eq, Ord, Generic)

--literals
data Lit
  = LInt Int
  | LBool Bool
  | LFloat Float
  deriving (Show, Eq, Ord, Generic)

-- basic primops
data BinaryOp
  = Add
  | Sub
  | Mul
  | Eql
  | AddF
  | SubF
  | MulF
  | DivF
  deriving (Show, Eq, Ord, Generic)

data RelOp
  = HGT
  | HLT
  | HGE
  | HLE
  deriving (Show, Eq, Ord, Generic)

-- | Primitive Operations
-- PrimOp defines the natively supported
-- operations in the Hailstorm runtime
-- TODO: Upon adding polymorphism the Int
-- and Bool prefix will be removed which
-- shall reduce the number of primops! Yay!
data PrimOp
  = NewSeqInt
  | GetSeqInt
  | SetSeqInt
  | NewSeqBool
  | GetSeqBool
  | SetSeqBool
  -- effects
  | ReadIntStream
  | WriteIntStream
  | ReadBoolStream
  | WriteBoolStream
  deriving (Show, Eq, Ord, Generic)


type Arg   = (Name, Type)
type AnnTy = (Expr, Type)

data Expr
  = Lit Lit -- literals
  | Var Name -- variables
  | Let Name Expr Expr
  | If Expr Expr Expr
  | BinaryOp BinaryOp Expr Expr

    -- 3 * (5 + 4)
    -- = BinaryOp Mul (Lit (LInt 3)) foo
  | RelOp RelOp Expr Expr
  | App Expr Expr
  | Lam [Arg] Expr
    -- ^ lambda abstraction
    -- \\ (x : Int) (y : Int)
    -- -> (x + y)

  | PrimOp PrimOp
    -- ^ primitive operations supported in the runtime
    -- eg:
    -- foo = newSeq# 5 0
    -- bar = setSeq# foo 2 3
    -- baz = getSeq# bar 2

  | Pair Expr Expr
  | Fst  Expr
  | Snd  Expr
    -- ^ Product and its first and second projection

    -- | Arrow combinators follow:
  | MapSignal Expr
  | Loop Expr Expr
  | Compose Expr Expr
  | UnsafeCompose Expr Expr
  | Fanout Expr Expr
  | UnsafeFanout Expr Expr
  | Combine Expr Expr
  | UnsafeCombine Expr Expr
  | Switch Expr Expr
  | Rate   Expr Expr

    -- | GRiSP board specifc
  | ReadColor  AnnTy
  | WriteColor AnnTy
  deriving (Show, Eq, Ord, Generic)

-- | global definition
data Global
  = Def Name [Arg] Type Expr
  -- ^ function definition
  -- foo (a : Int) (b : Int) : Int = a + b
  deriving (Show, Eq, Ord, Generic)

data Stmt = Global Global
          | Resource Resource
          deriving (Show, Eq, Ord)

data Program
  = Program [Stmt]
  deriving (Show, Eq, Ord, Generic)

----------------------------------------------------------------------
-- Accessors

argNames :: [Arg] -> [Name]
argNames = map fst


argTypes :: [Arg] -> [Type]
argTypes = map snd

-- | all unbound variables in an expression
-- (does not take global bindings into account)
freeVars :: Expr -> Set Name
freeVars = \case
  Lit _ -> Set.empty
  Var name -> Set.singleton name
  Let name ebound ein ->
    freeVars ebound `Set.union` Set.delete name (freeVars ein)
  If cond then_ else_ ->
    freeVars cond `Set.union` freeVars then_ `Set.union` freeVars else_
  BinaryOp _ a b -> freeVars a `Set.union` freeVars b
  RelOp _ a b -> freeVars a `Set.union` freeVars b
  App fun arg ->
    freeVars fun `Set.union` freeVars arg
  Lam args body ->
    freeVars body Set.\\ Set.fromList (map fst args)
  PrimOp op -> Set.empty
  Pair expr1 expr2 -> freeVars expr1 `Set.union` freeVars expr2
  Fst expr -> freeVars expr
  Snd expr -> freeVars expr

  (MapSignal expr) -> freeVars expr
  (Loop expr1 expr2) ->
    freeVars expr1 `Set.union` freeVars expr2
  (Compose expr1 expr2) ->
     freeVars expr1 `Set.union` freeVars expr2
  (UnsafeCompose expr1 expr2) ->
     freeVars expr1 `Set.union` freeVars expr2
  (Fanout expr1 expr2) ->
     freeVars expr1 `Set.union` freeVars expr2
  (UnsafeFanout expr1 expr2) ->
     freeVars expr1 `Set.union` freeVars expr2
  (Combine expr1 expr2) ->
     freeVars expr1 `Set.union` freeVars expr2
  (UnsafeCombine expr1 expr2) ->
     freeVars expr1 `Set.union` freeVars expr2
  (Switch expr1 expr2) ->
    freeVars expr1 `Set.union` freeVars expr2
  (Rate expr1 expr2) ->
    freeVars expr1 `Set.union` freeVars expr2
  (ReadColor  (expr, _)) -> freeVars expr
  (WriteColor (expr, _)) -> freeVars expr

-- | name of a global binding
globalName :: Global -> Name
globalName (Def name _ _ _) = name

-- | name of a resource
resourceName :: Resource -> Name
resourceName (R rty) =
  case rty of
    Empty -> "empty"
    Singleton (RName rname) -> rname
    Union rty1 rty2 ->
      resourceName (R rty1) <>
      resourceName (R rty2)

-- | type of a global binding
globalType :: Global -> Type
globalType (Def _ args retty _) = foldTArr (map snd args) retty

----------------------------------------------------------------------
-- Helpers

-- | extract argument list and return types from function type
--
-- @
-- unfoldTArr ((Int -> Bool) -> Int -> Bool)  =  ([Int -> Bool, Int], Bool)
-- @
unfoldTArr :: Type -> ([Type], Type)
unfoldTArr (TArr a b) = (a:args, ret)
  where (args, ret) = unfoldTArr b
unfoldTArr ty = ([], ty)

flatTArr :: Type -> [Type]
flatTArr (TArr a b) = a : flatTArr b
flatTArr ty = [ty]

-- | inverse of 'unfoldTArr'
foldTArr :: [Type] -> Type -> Type
foldTArr = flip (foldr TArr)

appPrecedence :: Int
appPrecedence = 5

opPrecedence :: BinaryOp -> Int
opPrecedence = \case
  DivF -> 4
  MulF -> 4
  Mul  -> 4
  AddF -> 2
  Add  -> 2
  SubF -> 2
  Sub  -> 2
  Eql -> 1

relopPrecedence :: RelOp -> Int
relopPrecedence = \case
  HGT -> 1
  HLT -> 1
  HGE -> 1
  HLE -> 1

primOpPrecedence :: PrimOp -> Int
primOpPrecedence = \case
  NewSeqInt -> 4
  GetSeqInt -> 2
  SetSeqInt -> 2
  NewSeqBool -> 4
  GetSeqBool -> 2
  SetSeqBool -> 2
  ReadIntStream  -> 4
  WriteIntStream -> 4
  ReadBoolStream  -> 4
  WriteBoolStream -> 4

-- | flatten a nested application
--
-- @
-- unfoldApp (((f a) b) c)  =  (f, [a, b, c])
-- @
unfoldApp :: Expr -> (Expr, [Expr])
unfoldApp = go []
  where
    go args (App fun arg) = go (arg:args) fun
    go args fun = (fun, args)

splitProgram :: Program -> ([Global], [Resource])
splitProgram (Program stmts) = go stmts [] []
  where
    go [] xs ys = (reverse xs, reverse ys)
    go (s1 : ss) xs ys = case s1 of
      (Global g) -> go ss (g:xs) ys
      (Resource r) -> go ss xs (r:ys)

-- NOTE 1
-- It is not possible to manually construct a void type
-- except for using the runtime provided functions like
-- getInt# or putInt#


-- NOTE 2
{-
When comparing resource types like the following two :

(Union (Union (Singleton (RName "LED1")) (Singleton (RName "LED2")))
       (Singleton (RName "IO")))

(Union (Singleton (RName "LED1"))
       (Union (Singleton (RName "LED2")) (Singleton (RName "IO"))))

simply deriving Eq will throw an error. So we flatten first and then
get out the names of the resources and then sort on them and then
compare. Because we map `getRName` *after flattening* we are guarnateed
that we will never encounter the `Union` constructor. Therefore we
throw a panic on `getRName` for `Union`.
-}
rEql :: ResourceTy -> ResourceTy -> Bool
rEql r1 r2 =
  (sort . map getRName . flattenRTy) r1 ==
  (sort . map getRName . flattenRTy) r2

flattenRTy :: ResourceTy -> [ResourceTy]
flattenRTy Empty = [Empty]
flattenRTy (Singleton r) = [Singleton r]
flattenRTy (Union rty1 rty2) = flattenRTy rty1 ++ flattenRTy rty2

getRName :: ResourceTy -> RName
-- no checks around this but we cannot allow a resource named "hailstorm _empty"
getRName Empty = RName "hailstorm_empty"
getRName (Singleton rname) = rname
getRName (Union _ _) = panic $! "Attempt to getRName for union"

{-# LANGUAGE DeriveGeneric #-}

module Desugar where

import qualified Data.Map as Map
import qualified Data.Set as Set
import Protolude hiding (Type)
import Prelude (tail)

import qualified AST as A

data DesugarState =
  DesugarState
    { count :: Int }


newtype Desugar a =
  Desugar
    { runDesugar :: State DesugarState a
    }
  deriving (Functor, Applicative, Monad, MonadState DesugarState)

initState :: DesugarState
initState =
  DesugarState { count = 0 }

desugar :: Program -> A.Program
desugar (Program stmts) =
  A.Program (map desugarStmt stmts)

desugarStmt :: Stmt -> A.Stmt
desugarStmt (Global g) =
  let g' = evalState (runDesugar $ desugarGlobal g) initState
   in A.Global g'
desugarStmt (Resource (R rty)) = A.Resource (A.R (transfRty rty))

-- See NOTE 2
transformPairArgs :: [Arg1] -> Expr -> Desugar ([A.Arg],A.Expr)
transformPairArgs args expr = do
  desugaredArgs <- mapM desugarArg1 args
  expr' <- desugarExpr expr
  if none isRight desugaredArgs
  then let as = map getLeft desugaredArgs
        in pure $! (as, expr')
  else let f x = case x of
                  Left m -> m
                  Right (n, _) -> n
           as = map f desugaredArgs
           etoes = map (snd . getRight) $ filter isRight desugaredArgs
           finalE = if null etoes
                    then expr'
                    else let h = getHead etoes
                             etoe' = foldr (\a b -> b . a) h (tail etoes) -- atleast 1 element so tail won't fail
                          in etoe' expr'
        in pure $! (as, finalE)
  where
    none f = not . any f


desugarGlobal :: Global -> Desugar A.Global
desugarGlobal (Def name args ty expr) = do
  (args', expr') <- transformPairArgs args expr
  pure $! A.Def name args' (transfType ty) expr'


desugarExpr :: Expr -> Desugar A.Expr
desugarExpr (Lit l) = pure $! A.Lit (desugarLit l)
desugarExpr (Var name) = pure $! A.Var name
desugarExpr (Let name ebound ein) = do
  ebound' <- (desugarExpr ebound)
  ein'    <- (desugarExpr ein)
  pure $! A.Let name ebound' ein'
desugarExpr (If cond th els) = do
  cond' <- (desugarExpr cond)
  th'   <- (desugarExpr th)
  els'  <- (desugarExpr els)
  pure $! A.If cond' th' els'
-- See NOTE 1 to see what is happening for desugaring case
desugarExpr (Case _ [] _) = panic "Desugaring error in case"
desugarExpr (Case switcher (c:conds) els) = do
  switcher' <- desugarExpr switcher
  let (econd, eAction) = c
  econd' <- desugarExpr econd
  eAction' <- desugarExpr eAction
  let  partial = A.If (A.BinaryOp A.Eql switcher' econd') eAction'
  els' <- desugarExpr els
  if null conds
  then pure $! partial els'
  else caseTransform conds partial switcher' els'
desugarExpr (BinaryOp bop expr1 expr2) = do
  expr1' <- desugarExpr expr1
  expr2' <- desugarExpr expr2
  pure $! A.BinaryOp (desugarBOP bop) expr1' expr2'
desugarExpr (RelOp rop expr1 expr2) = do
  expr1' <- desugarExpr expr1
  expr2' <- desugarExpr expr2
  pure $! A.RelOp (desugarROP rop) expr1' expr2'
desugarExpr (App expr1 expr2) = do
  expr1' <- (desugarExpr expr1)
  expr2' <- (desugarExpr expr2)
  pure $! A.App expr1' expr2'
desugarExpr (Lam args expr) = do
  (args', expr') <- transformPairArgs args expr
  pure $! A.Lam args' expr'
desugarExpr (PrimOp pop) =
  pure $! A.PrimOp (desugarPrimOp pop)
desugarExpr (Pair expr1 expr2) = do
  expr1' <- desugarExpr expr1
  expr2' <- desugarExpr expr2
  pure $! A.Pair expr1' expr2'
desugarExpr (Fst expr) = A.Fst <$> (desugarExpr expr)
desugarExpr (Snd expr) = A.Snd <$> (desugarExpr expr)
desugarExpr (MapSignal expr) =
  A.MapSignal <$> (desugarExpr expr)
desugarExpr (Loop init expr) = do
  init' <- (desugarExpr init)
  expr' <- (desugarExpr expr)
  pure $! A.Loop init' expr'
desugarExpr (Compose expr1 expr2) = do
  expr1' <- desugarExpr expr1
  expr2' <- desugarExpr expr2
  pure $! A.Compose expr1' expr2'
desugarExpr (Fanout expr1 expr2) = do
  expr1' <- desugarExpr expr1
  expr2' <- desugarExpr expr2
  pure $! A.Fanout expr1' expr2'
desugarExpr (Combine expr1 expr2) = do
  expr1' <- desugarExpr expr1
  expr2' <- desugarExpr expr2
  pure $! A.Combine expr1' expr2'
desugarExpr (UnsafeCompose expr1 expr2) = do
  expr1' <- desugarExpr expr1
  expr2' <- desugarExpr expr2
  pure $! A.UnsafeCompose expr1' expr2'
desugarExpr (UnsafeFanout expr1 expr2) = do
  expr1' <- desugarExpr expr1
  expr2' <- desugarExpr expr2
  pure $! A.UnsafeFanout expr1' expr2'
desugarExpr (UnsafeCombine expr1 expr2) = do
  expr1' <- desugarExpr expr1
  expr2' <- desugarExpr expr2
  pure $! A.UnsafeCombine expr1' expr2'
desugarExpr (Switch expr1 expr2) = do
  expr1' <- desugarExpr expr1
  expr2' <- desugarExpr expr2
  pure $! A.Switch expr1' expr2'
desugarExpr (Rate expr1 expr2) = do
  expr1' <- desugarExpr expr1
  expr2' <- desugarExpr expr2
  pure $! A.Rate expr1' expr2'

desugarExpr (ReadColor (expr, ty)) = do
  expr' <- desugarExpr expr
  pure $! A.ReadColor (expr', transfType ty)
desugarExpr (WriteColor (expr, ty)) = do
  expr' <- desugarExpr expr
  pure $! A.WriteColor (expr', transfType ty)

desugarLit :: Lit -> A.Lit
desugarLit (LInt i) = A.LInt i
desugarLit (LBool b) = A.LBool b
desugarLit (LFloat f)  = A.LFloat f

desugarBOP :: BinaryOp -> A.BinaryOp
desugarBOP Add = A.Add
desugarBOP Sub = A.Sub
desugarBOP Mul = A.Mul
desugarBOP Eql = A.Eql
desugarBOP AddF = A.AddF
desugarBOP SubF = A.SubF
desugarBOP MulF = A.MulF
desugarBOP DivF = A.DivF

desugarROP :: RelOp -> A.RelOp
desugarROP HGT = A.HGT
desugarROP HLT = A.HLT
desugarROP HGE = A.HGE
desugarROP HLE = A.HLE

desugarArg :: Arg -> A.Arg
desugarArg (name, ty) = (name, transfType ty)

desugarPrimOp :: PrimOp -> A.PrimOp
desugarPrimOp NewSeqInt       = A.NewSeqInt
desugarPrimOp GetSeqInt       = A.GetSeqInt
desugarPrimOp SetSeqInt       = A.SetSeqInt
desugarPrimOp NewSeqBool      = A.NewSeqBool
desugarPrimOp GetSeqBool      = A.GetSeqBool
desugarPrimOp SetSeqBool      = A.SetSeqBool
desugarPrimOp ReadIntStream   = A.ReadIntStream
desugarPrimOp WriteIntStream  = A.WriteIntStream
desugarPrimOp ReadBoolStream  = A.ReadBoolStream
desugarPrimOp WriteBoolStream = A.WriteBoolStream


transfType :: Type -> A.Type
transfType TVoid = A.TVoid
transfType TInt  = A.TInt
transfType TFloat = A.TFloat
transfType TBool  = A.TBool
transfType (TArr ty1 ty2) = A.TArr (transfType ty1) (transfType ty2)
transfType (TSeq ty)      = A.TSeq (transfType ty)
transfType (TPair ty1 ty2) = A.TPair (transfType ty1) (transfType ty2)
transfType (TSF rty ty1 ty2) =
  A.TSF (transfRty rty) (transfType ty1) (transfType ty2)

transfRty :: ResourceTy -> A.ResourceTy
transfRty Empty = A.Empty
transfRty (Singleton (RName rname)) = A.Singleton (A.RName rname)
transfRty (Union rty1 rty2) = A.Union (transfRty rty1) (transfRty rty2)


caseTransform :: [(Expr, Expr)] -- conds
              -> (A.Expr -> A.Expr) -- expression being built
              -> A.Expr -- switcher
              -> A.Expr -- else
              -> Desugar A.Expr
caseTransform [] partial _ els = pure $! partial els
caseTransform (c:conds) partial switcher els = do
  let (econd, eAction) = c
  econd' <- desugarExpr econd
  eAction' <- desugarExpr eAction
  let partial' = A.If (A.BinaryOp A.Eql switcher econd') eAction'
  caseTransform conds (partial . partial') switcher els

desugarArg1 :: Arg1 -> Desugar (Either A.Arg (A.Arg, (A.Expr -> A.Expr)))
desugarArg1 (Plain (name, ty)) = pure $! Left (name, transfType ty)
desugarArg1 p@(PairArg a1 a2) = do
  n <- fresh
  let ty = getTypeFromPair p
  a1' <- process a1 n F
  a2' <- process a2 n S
  pure $! Right ((n, ty) , (constructExpr (a1' ++ a2')))


-- called from pair so guaranteed to have atleast
-- two elements in the list
constructExpr :: [(A.Name, A.Expr)] -> (A.Expr -> A.Expr)
constructExpr [] = panic "Impossible case"
constructExpr es =
  let (n, e) = getHead es
      e' = A.Let n e
   in buildE (tail es) e'

buildE :: [(A.Name, A.Expr)] -> (A.Expr -> A.Expr) -> A.Expr -> A.Expr
buildE [] x = x
buildE ((n,e) : es)  x = let y = (x . (A.Let n e))
                       in buildE es y

type Parent = Name

process :: Arg1 -> Parent -> Direction -> Desugar [(A.Name, A.Expr)]
process (Plain (n,_)) par dir =
  pure $! [(n, (dirToFun dir) (A.Var par))]
process (PairArg arg1 arg2) par dir = do
  myName <- fresh
  a1 <- process arg1 myName F
  a2 <- process arg2 myName S
  pure $ [(myName, (dirToFun dir) (A.Var par))] ++ a1 ++ a2

data Direction = F | S deriving (Show, Ord, Eq)

dirToFun :: Direction -> (A.Expr -> A.Expr)
dirToFun F = A.Fst
dirToFun S = A.Snd

getTypeFromPair :: Arg1 -> A.Type
getTypeFromPair (Plain (_,ty)) = transfType ty
getTypeFromPair (PairArg a1 a2) =
  A.TPair (getTypeFromPair a1) (getTypeFromPair a2)

getLeft :: Either a b -> a
getLeft e = case e of
  Left a -> a
  _ -> panic $! "Left doesnt exist"

getRight :: Either a b -> b
getRight e = case e of
  Right b -> b
  _ -> panic $! "Left doesnt exist"

type Name = Text

newtype RName = RName Name
  deriving (Show, Eq, Ord)

data ResourceTy = Empty
                | Singleton RName
                | Union ResourceTy ResourceTy
                deriving (Show, Ord)

-- | See at the bottom alongside NOTE 2
-- why we separately defined resource equality
instance Eq ResourceTy where
  (==) = rEql

-- | A resource is purely a type level entity
newtype Resource =
  R ResourceTy
  deriving (Show, Eq, Ord)

data Type
  = TVoid -- void type -- see NOTE 1
  | TInt  -- Integer type
  | TFloat -- Float type
  | TBool -- Boolean type
  | TArr Type Type -- function type
  | TSeq Type -- sequence type
  | TPair Type Type -- pairs
  | TSF ResourceTy Type Type
  deriving (Show, Eq, Ord, Generic)

--literals
data Lit
  = LInt Int
  | LBool Bool
  | LFloat Float
  deriving (Show, Eq, Ord, Generic)

-- basic primops
data BinaryOp
  = Add
  | Sub
  | Mul
  | Eql
  | AddF
  | SubF
  | MulF
  | DivF
  deriving (Show, Eq, Ord, Generic)

data RelOp
  = HGT
  | HLT
  | HGE
  | HLE
  deriving (Show, Eq, Ord, Generic)

-- | Primitive Operations
-- PrimOp defines the natively supported
-- operations in the Hailstorm runtime
-- TODO: Upon adding polymorphism the Int
-- and Bool prefix will be removed which
-- shall reduce the number of primops! Yay!
data PrimOp
  = NewSeqInt
  | GetSeqInt
  | SetSeqInt
  | NewSeqBool
  | GetSeqBool
  | SetSeqBool
  -- effects
  | ReadIntStream
  | WriteIntStream
  | ReadBoolStream
  | WriteBoolStream
  deriving (Show, Eq, Ord, Generic)


type Arg   = (Name, Type)
type AnnTy = (Expr, Type)

data Expr
  = Lit Lit -- literals
  | Var Name -- variables
  | Let Name Expr Expr
  | If Expr Expr Expr
  | Case Expr [(Expr, Expr)] Expr
  | BinaryOp BinaryOp Expr Expr
  | RelOp RelOp Expr Expr
  | App Expr Expr
  | Lam [Arg1] Expr
  | PrimOp PrimOp
  | Pair Expr Expr
  | Fst  Expr
  | Snd  Expr
  | MapSignal Expr
  | Loop Expr Expr
  | Compose Expr Expr
  | UnsafeCompose Expr Expr
  | Fanout Expr Expr
  | UnsafeFanout Expr Expr
  | Combine Expr Expr
  | UnsafeCombine Expr Expr
  | Switch Expr Expr
  | Rate Expr Expr

    -- | GRiSP board specifc
  | ReadColor  AnnTy
  | WriteColor AnnTy
  deriving (Show, Eq, Ord, Generic)

-- | global definition
data Global
  = Def Name [Arg1] Type Expr
  -- ^ function definition
  -- foo (a : Int) (b : Int) : Int = a + b
  deriving (Show, Eq, Ord, Generic)

data Stmt = Global Global
          | Resource Resource
          deriving (Show, Eq, Ord)

data Program
  = Program [Stmt]
  deriving (Show, Eq, Ord, Generic)


data Arg1 = Plain (Name, Type)
          | PairArg Arg1 Arg1
          deriving (Show, Ord, Eq)


rEql :: ResourceTy -> ResourceTy -> Bool
rEql r1 r2 =
  (sort . map getRName . flattenRTy) r1 ==
  (sort . map getRName . flattenRTy) r2

flattenRTy :: ResourceTy -> [ResourceTy]
flattenRTy Empty = [Empty]
flattenRTy (Singleton r) = [Singleton r]
flattenRTy (Union rty1 rty2) = flattenRTy rty1 ++ flattenRTy rty2

getRName :: ResourceTy -> RName
-- no checks around this but we cannot allow a resource named "hailstorm _empty"
getRName Empty = RName "hailstorm_empty"
getRName (Singleton rname) = rname
getRName (Union _ _) = panic $! "Attempt to getRName for union"


-- Dealing with non empty lists
getHead es = fromMaybe headPanic (head es)
headPanic = panic "Head of a non-empty list breaks!"


-- generate freshVariable name
fresh :: Desugar Name
fresh = do
  i <- gets count
  modify $ \s -> s {count = 1 + i}
  return $ "hailstorm_desugar_" <> (show i)




-- NOTE 1 : Case
-- transforms

-- case x of
--   y ~> a;
--   z ~> b;
--   _ ~> c

-- into

-- if x == y then
--    a else
-- if x == z then
--    b else c

-- NOTE 2 : Pair pattern matching
-- Given: def foo (x:Int, y:Int) : Int = x + y
-- transforms to :

--   def foo (val : (Int, Int)) : Int =
--      let x = fst# val in
--      let y = snd# val in
--      x + y

-- desugarArg1 first travels from top to bottom
-- constructing the type in `getTypeFromPair`
-- It creates a name for the node itself and propagates
-- its name to its child along with the direction(i.e Fst or Snd)
-- from which it has descended. The function `process`
-- simply uses that to construct the expr
-- let foo = ... in
-- let bar = ... in

-- It is then finally applied at `transformPairArgs`

{-# LANGUAGE TupleSections #-}

module L1.Interpreter
  (astToL1) where

import Control.Arrow ((&&&))
import qualified L1.L1 as L1
import Control.Monad.RWS.Lazy
import Control.Monad.Trans.Maybe
import Data.DList (DList)
import qualified Data.DList as DList
import Data.Map.Strict (Map)
import qualified Data.Map.Strict as Map
import qualified Data.Set as S
import Protolude hiding (Type, odd, even)
import Protolude.Error

import AST as AST
import Typecheck as TC
import qualified L1.L1 as L1

import qualified Debug.Trace as DT

data TransformState =
  TransformState
  { varNo :: Int
  , pairTys :: S.Set L1.Type
  }
  deriving Show

data ScopedVar
  = GlobalVar L1.Type
  | LocalVar    L1.Type
  deriving (Show, Eq, Ord)

type Context = Map Name ScopedVar
-- | A transform reads the global and local context,
-- writes new global definitions,
-- and keeps a counter (state) for fresh variable names.
--
-- r = Context
-- w = DList L1.Global == [Global] -- a list of global functions
-- s = Int -- counter for variables
-- a = L1.Program
type Transform = RWS Context (DList L1.Global) TransformState


-- | Transform Typechecked Hailstorm AST to l1 AST.
--
--
-- It is illegal to pass a program that is not type-correct.
astToL1 :: TC.TypeSafeProgram -> L1.Program
astToL1 program = L1.Program
  { L1.programGlobals = DList.apply extra globals
  , L1.programMainArgNames = mainArgNames
  , L1.programMainType = mainType
  , L1.programMainFunction = mainFunction
  }
  where
    (L1.Program globals mainArgNames mainType mainFunction, extra) =
      evalRWS (transfProgram program) Map.empty initState
    initState = TransformState { varNo = 0
                               , pairTys = S.empty}



-- | Transform a "Hailstorm" type to an L1 type.
transfType :: AST.Type -> L1.Type
transfType = \case
    AST.TVoid -> L1.TVoid
    AST.TInt -> L1.TInt
    AST.TFloat -> L1.TFloat
    AST.TBool -> L1.TBool
    ty@(AST.TArr _ _) ->
      let (argtys, retty) = AST.unfoldTArr ty
      in L1.TClosure (map transfType argtys) (transfType retty)
    AST.TSeq ty -> L1.TSeq (transfType ty)
    AST.TPair ty1 ty2 -> L1.TPair (transfType ty1) (transfType ty2)
    AST.TSF _ ty1 ty2 -> L1.TClosure [(transfType ty1)] (transfType ty2)

-- | transform a "Hailstorm" expression to L1
--
-- The function is partial and fails on ill-formed expressions.
transfExpr :: AST.Expr -> Transform L1.Expr
transfExpr = \case

  AST.Lit lit@(LInt _)  -> pure $! L1.Lit L1.TInt lit
  AST.Lit lit@(LFloat _)  -> pure $! L1.Lit L1.TFloat lit
  AST.Lit lit@(LBool _) -> pure $! L1.Lit L1.TBool lit

  AST.Var name -> do
    var <- lookup name
    case var of
      LocalVar type_ -> pure $! L1.Var type_ name
      GlobalVar type_ -> pure $! L1.Global type_ name

  AST.Let name e ein -> do
    e' <- transfExpr e
    let ty = L1.exprType e'
    ein' <- with [(name, ty)] $ transfExpr ein
    let inty = L1.exprType ein'
    pure $! L1.Let inty name e' ein'

  AST.If cond then_ else_ -> do
    cond' <- convert L1.TBool =<< transfExpr cond
    (then', else') <- join $ promote <$> transfExpr then_ <*> transfExpr else_
    pure $! L1.If (L1.exprType then') cond' then' else'

  AST.BinaryOp op a b -> do
    let op' = case op of
                Eql -> L1.Equal
                Add -> L1.Add
                Mul -> L1.Mul
                Sub -> L1.Sub
                DivF -> L1.DivF
                AddF -> L1.AddF
                MulF -> L1.MulF
                SubF -> L1.SubF

    let ty =
          case op of
            Eql -> L1.TBool
            Add -> L1.TInt
            Sub -> L1.TInt
            Mul -> L1.TInt
            DivF -> L1.TFloat
            AddF -> L1.TFloat
            SubF -> L1.TFloat
            MulF -> L1.TFloat

    a' <- transfExpr a
    b' <- transfExpr b
    let aty = exprType' a'
    let bty = exprType' b'
    a'' <- if L1.isFunctionType aty && null (L1.argTypes aty)
           then call a' []
           else pure a'
    b'' <- if L1.isFunctionType bty && null (L1.argTypes bty)
           then call b' []
           else pure b'
    call (L1.PrimOp (L1.TFunction [aty, bty] ty) op') [a'', b'']

  AST.RelOp op a b -> do
    let op' = case op of
                HGT -> L1.HGT
                HLT -> L1.HLT
                HGE -> L1.HGE
                HLE -> L1.HLE

    let ty = L1.TBool
    a' <- transfExpr a
    b' <- transfExpr b
    let aty = exprType' a'
    let bty = exprType' b'
    a'' <- if L1.isFunctionType aty && null (L1.argTypes aty)
           then call a' []
           else pure a'
    b'' <- if L1.isFunctionType bty && null (L1.argTypes bty)
           then call b' []
           else pure b'
    call (L1.PrimOp (L1.TFunction [aty, bty] ty) op') [a'', b'']


  app@(AST.App _ _) ->
    let (f, args) = AST.unfoldApp app
     in join $ call <$> transfExpr f <*> traverse transfExpr args

  AST.Lam arglist body -> do
    let arglist' = [ (n, transfType t) | (n, t) <- arglist ]
    body' <- with arglist' $ transfExpr body
    let ret' =
          case L1.exprType body' of
            L1.TFunction [] ret -> ret
            L1.TFunction args ret -> L1.TClosure args ret
            x -> x
    liftClosure arglist' ret' L1.Lambda body'
  AST.PrimOp ReadIntStream -> do
    varName  <- freshname "__temp_"
    let varTy = L1.TVoid
    let body  = L1.Call L1.TInt (L1.PrimOp (L1.TClosure [L1.TVoid] L1.TInt) L1.ReadIntStream) []
    let ret   = L1.TInt
    liftClosure [(varName, varTy)] ret L1.Lambda body
  AST.PrimOp WriteIntStream -> do
    varName  <- freshname "__temp_"
    let varTy = L1.TInt
    let body  = L1.Call L1.TVoid (L1.PrimOp (L1.TClosure [L1.TInt] L1.TVoid) L1.WriteIntStream) [(L1.Var varTy varName)]
    let ret   = L1.TVoid
    liftClosure [(varName, varTy)] ret L1.Lambda body
  AST.PrimOp ReadBoolStream -> do
    varName  <- freshname "__temp_"
    let varTy = L1.TVoid
    let body  = L1.Call L1.TBool (L1.PrimOp (L1.TClosure [L1.TVoid] L1.TBool) L1.ReadBoolStream) []
    let ret   = L1.TBool
    liftClosure [(varName, varTy)] ret L1.Lambda body
  AST.PrimOp WriteBoolStream -> do
    varName  <- freshname "__temp_"
    let varTy = L1.TBool
    let body  = L1.Call L1.TVoid (L1.PrimOp (L1.TClosure [L1.TBool] L1.TVoid) L1.WriteBoolStream) [(L1.Var varTy varName)]
    let ret   = L1.TVoid
    liftClosure [(varName, varTy)] ret L1.Lambda body

  AST.PrimOp primop -> do
    let (ty, op) =
          case primop of
            NewSeqInt  -> (L1.TFunction [L1.TInt, L1.TInt] (L1.TSeq L1.TInt), L1.NewSeqInt)
            GetSeqInt  -> (L1.TFunction [(L1.TSeq L1.TInt), L1.TInt] L1.TInt, L1.GetSeqInt)
            SetSeqInt  -> (L1.TFunction [(L1.TSeq L1.TInt), L1.TInt, L1.TInt] (L1.TSeq L1.TInt), L1.SetSeqInt)
            NewSeqBool -> (L1.TFunction [L1.TInt, L1.TBool] (L1.TSeq L1.TBool), L1.NewSeqBool)
            GetSeqBool -> (L1.TFunction [(L1.TSeq L1.TBool), L1.TInt] L1.TBool, L1.GetSeqBool)
            SetSeqBool -> (L1.TFunction [(L1.TSeq L1.TBool), L1.TInt, L1.TBool] (L1.TSeq L1.TBool), L1.SetSeqBool)
            _ -> panic "Effectful primops like read and write are handled at the top"
      in pure $! L1.PrimOp ty op

  AST.Pair expr1 expr2 -> do
    exp1 <- transfExpr expr1
    exp2 <- transfExpr expr2
    let ty1 = L1.exprType exp1
    let ty2 = L1.exprType exp2
    let pairTy = L1.TPair ty1 ty2
    let name = L1.getNameFromType pairTy
    set <- gets pairTys
    -- See NOTE 1 below to understand the following logic
    if pairTy `S.member` set
    then pure $! L1.Pair pairTy exp1 exp2
    else do
      defpair name pairTy
      modify (\s -> s { pairTys = S.insert pairTy set})
      pure $! L1.Pair pairTy exp1 exp2

  AST.Fst expr -> do
    exp <- transfExpr expr
    let pairTy = L1.exprType exp
    let retTy = case pairTy of
                  (L1.TPair ty1 _) -> ty1
                  _ -> panic "Fst operation not applied to pair type"
    let callTy = L1.TFunction [pairTy] retTy
    call (L1.PrimOp callTy L1.Fst) [exp]

  AST.Snd expr -> do
    exp <- transfExpr expr
    let pairTy = L1.exprType exp
    let retTy = case pairTy of
                  (L1.TPair _ ty2) -> ty2
                  _ -> panic "Snd operation not applied to pair type"
    let callTy = L1.TFunction [pairTy] retTy
    call (L1.PrimOp callTy L1.Snd) [exp]

  AST.MapSignal expr -> transfExpr expr

  AST.Loop expr1 expr2 -> do
    exp1 <- transfExpr expr1
    exp2 <- transfExpr expr2

    varName <- freshname "__temp_"
    let e1ArgTy = (  fromMaybe (panic "Signal doesn't have argument")
                   . head
                   . L1.argTypes
                   . exprType') exp2
    let (varTy, stateTy) = case e1ArgTy of
                             L1.TPair ty1 stTy -> (ty1, stTy)
                             _ ->
                                 panic "Typechecker did not handle non-pair type"
    let ret = case (L1.returnType $ exprType' exp2) of
                L1.TPair ty2 _ -> ty2
                _ -> panic "Typechecker did not handle non-pair return type"
    stateName <- freshname "hailstorm_state_var_"
    b1 <- freshname "__temp_"
    b2 <- freshname "__temp_"
    b3 <- freshname "__temp_"
    b4 <- freshname "__temp_"
    b5 <- freshname "__temp_"
    let body = (L1.Let ret b1 (L1.PrimOp stateTy (L1.Get stateName exp1))
                  (L1.Let ret b2 (L1.Call (L1.TPair ret stateTy) exp2 [(L1.Pair (L1.TPair varTy stateTy) (L1.Var varTy varName) (L1.Var stateTy b1))])
                    (L1.Let ret b3 (L1.Call ret (L1.PrimOp (L1.TClosure [(L1.TPair ret stateTy)] ret) L1.Fst) [(L1.Var (L1.TPair ret stateTy) b2)])
                      (L1.Let ret b4 (L1.Call stateTy (L1.PrimOp (L1.TClosure [(L1.TPair ret stateTy)] stateTy) L1.Snd) [(L1.Var (L1.TPair ret stateTy) b2)])
                        (L1.Let ret b5 (L1.PrimOp stateTy (L1.Put stateName (L1.Var stateTy b4)))
                          (L1.Var ret b3))))))

    liftClosure [(varName, varTy)] ret L1.State body
  -- Semantics of the above
  -- expr1 :: c
  -- expr2 :: (a,c) -> (b,c)
  -- \a -> let s = get "foo" expr1 in
  --       let z : (b,c) = App expr2 (a,s) in
  --       let b = fst# z in
  --       let c = snd# z in
  --       let _ = put "foo" c  in
  --       b

  AST.Switch expr1 expr2 -> do
    exp1 <- transfExpr expr1
    exp2 <- transfExpr expr2

    varName <- freshname "__temp_"
    newVar1  <- freshname "__temp_"
    func     <- freshname "__temp_"
    let varTy = (  partialSFHead
                 . L1.argTypes
                 . exprType') exp1
    let (condTy, tyb, tyc) = case (L1.returnType $ exprType' exp2) of
                               ty@(L1.TClosure bType ty2) ->
                                   let ty1 = partialSFHead bType
                                    in (ty, ty1, ty2)
                               _ -> panic "Typechecker did not handle \
                                          \non-signal function return type"
    let body = L1.Let tyc newVar1 (L1.Call tyb exp1 [(L1.Var varTy varName)])
                 (L1.Let tyc func (L1.Call tyc exp2 [(L1.Var tyb newVar1)])
                    (L1.Call tyc (L1.Var condTy func) [(L1.Var tyb newVar1)]))
    let ret = L1.returnType $ exprType' body
    liftClosure [(varName, varTy)] ret L1.Lambda body
    where
     partialSFHead x = fromMaybe (panic "Signal doesn't have argument") $ head x
    -- Semantics of the above
    -- expr1 :: a -> b
    -- expr2 :: b -> (b -> c)
    -- \a -> let newVar1 = expr1 a in
    --       let func = expr2 newVar1 in
    --       func newVar1

  AST.Compose expr1 expr2 ->
    transfExpr (AST.UnsafeCompose expr1 expr2)

  -- See NOTE 2 below to understand the following logic
  e@(AST.UnsafeCompose expr1 expr2) -> do
    let flatTree = flattenCompositionTree e
    let (_:restTree) = flatTree
    exp1 <- transfExpr expr1
    varName <- freshname "__temp_"
    let varTy = (  fromMaybe (panic "Signal doesn't have argument")
                 . head
                 . L1.argTypes
                 . exprType') exp1
    newExpr <- call exp1 [(L1.Var varTy varName)]
    body <- genExp newExpr restTree
    let ret' = L1.returnType $ exprType' body
    liftClosure [(varName, varTy)] ret' L1.Lambda body
  AST.ReadColor (ledposition, _) -> do
    ledP     <- transfExpr ledposition
    varName  <- freshname "__temp_"
    let varTy = L1.TVoid
    body <- call (L1.PrimOp (L1.TClosure [L1.TInt] L1.TInt) L1.ReadColor) [ledP]
    let ret   = L1.TInt
    liftClosure [(varName, varTy)] ret L1.Lambda body
  AST.WriteColor (ledposition, _) -> do
    ledP     <- transfExpr ledposition
    varName  <- freshname "__temp_"
    let varTy = L1.TInt
    body <- call
            (L1.PrimOp (L1.TClosure [L1.TInt, L1.TInt] L1.TVoid) L1.WriteColor)
            [ledP
            , (L1.Var varTy varName)
            ]
    let ret   = L1.TVoid
    liftClosure [(varName, varTy)] ret L1.Lambda body
  AST.Fanout expr1 expr2 ->
    transfExpr (AST.UnsafeFanout expr1 expr2)
  AST.UnsafeFanout expr1 expr2 -> do
    e1 <- transfExpr expr1
    e2 <- transfExpr expr2
    varName <- freshname "__temp_"
    let varTy = (  fromMaybe (panic "Signal doesn't have argument")
                 . head
                 . L1.argTypes
                 . exprType') e1
    -- the fact that `varTy` for e1 and e2 is same is verified
    -- by the typechecker so no need to ensure e2 has the same `varTy`
    newExpr1 <- call e1 [(L1.Var varTy varName)]
    newExpr2 <- call e2 [(L1.Var varTy varName)]
    let ret1 = (L1.returnType . exprType') newExpr1
    let ret2 = (L1.returnType . exprType') newExpr2
    let ret  = L1.TPair ret1 ret2
    let body = L1.Pair ret newExpr1 newExpr2
    liftClosure [(varName, varTy)] ret L1.Lambda body
  AST.Combine expr1 expr2 ->
    transfExpr (AST.UnsafeCombine expr1 expr2)
  AST.UnsafeCombine expr1 expr2 -> do -- See NOTE 4
    e1 <- transfExpr expr1    -- a -> c
    e2 <- transfExpr expr2    -- b -> d
    varName <- freshname "__temp_"
    let varTy1 = (  fromMaybe (panic "Signal 1 doesn't have argument")
                  . head
                  . L1.argTypes
                  . exprType') e1 -- a
    let varTy2 = (  fromMaybe (panic "Signal 2 doesn't have argument")
                  . head
                  . L1.argTypes
                  . exprType') e2 -- b
    let varTy = L1.TPair varTy1 varTy2 --(a,b)
    let pair = L1.Var varTy varName
    let callTy1 = L1.TFunction [varTy] varTy1
    let callTy2 = L1.TFunction [varTy] varTy2
    let r1 = L1.Call varTy1 (L1.PrimOp callTy1 L1.Fst) [pair]
    let r2 = L1.Call varTy2 (L1.PrimOp callTy2 L1.Snd) [pair]

    newExpr1 <- call e1 [r1]
    newExpr2 <- call e2 [r2]
    let ret1 = (L1.returnType . exprType') newExpr1
    let ret2 = (L1.returnType . exprType') newExpr2
    let ret  = L1.TPair ret1 ret2
    let body = L1.Pair ret newExpr1 newExpr2
    liftClosure [(varName, varTy)] ret L1.Lambda body
  AST.Rate time expr -> do
    t <- transfExpr time
    e <- transfExpr expr
    varName <- freshname "__temp_"
    let varTy = (  fromMaybe (panic "Signal 1 doesn't have argument")
                 . head
                 . L1.argTypes
                 . exprType') e
    let ret1 = (L1.returnType . exprType') e
    expr' <- call e [(L1.Var varTy varName)]
    let body = L1.Call ret1 (L1.PrimOp ret1 (L1.Rate t)) [expr']
    let ret  = L1.returnType $ exprType' body
    liftClosure [(varName, varTy)] ret L1.Lambda body


-- This handles cases of returning the correct type when
-- calling global variables where the type is
-- (TFunction [] (TClosure ty1 ty2))
exprType' body =
  case L1.exprType body of
    L1.TFunction [] ret -> ret
    L1.TFunction args ret -> L1.TClosure args ret
    x -> x

genExp :: L1.Expr -> [AST.Expr] -> Transform L1.Expr
genExp exp [] = return exp
genExp exp (x:xs) = do
  x' <- transfExpr x
  exp' <- call x' [exp]
  genExp exp' xs

flattenCompositionTree :: Expr -> [Expr]
flattenCompositionTree expr = case expr of
  UnsafeCompose e1 e2 -> flattenCompositionTree e1 ++ flattenCompositionTree e2
  Compose e1 e2 -> flattenCompositionTree e1 ++ flattenCompositionTree e2
  e -> [e]

-- | transform a global binding in "Hailstorm" to IR
transfGlobal :: AST.Global -> Transform L1.Global
transfGlobal (AST.Def name arglist retty body) = do
  let
    arglist' = map (second transfType) arglist
    retty' = transfType retty
  body' <- with arglist' $ convert retty' =<< transfExpr body
  pure $! L1.DefFunction name arglist' retty' body'

transfProgram :: TC.TypeSafeProgram -> Transform L1.Program
transfProgram program = withGlobalContext $ do
  globals' <- traverse transfGlobal $ TC.programGlobals program
  let mainTy = transfType (TC.programMainType program)
  main' <- convert mainTy =<< transfExpr (TC.programMainFunction program)
  pure $! L1.Program globals' mainArgNames mainTy main'
  where
    globals = TC.programGlobals program
    mainArgNames = TC.programMainArgNames program
    -- mainArglist = [ (name, L1.TInt) | name <- mainArgNames ]
    -- mainType =
    --   let argtys = map (const L1.TInt) mainArgNames in
    --   L1.TFunction argtys L1.TInt
    withGlobalContext = local . const $ Map.fromList $
      -- ("main", GlobalVar mainType) :
      [ (name, GlobalVar ty)
      | AST.Def name arglist retty _body <- globals
      , let ty = L1.TFunction [ transfType t | (_, t) <- arglist ] (transfType retty)
      ]
----------------------------------------------------------------------
-- Context Handling


lookup :: Name -> Transform ScopedVar
lookup name = do
  mbVar <- asks $ Map.lookup name
  case mbVar of
    Just var -> pure var
    Nothing  -> panic $
      "[L1.Interpreter.lookup] \
      \Undefined variable: " <> show name

with :: [L1.Arg] -> Transform a -> Transform a
with vars = local . Map.union . Map.fromList $
  [ (name, LocalVar type_) | (name, type_) <- vars ]



------------------------------
-- State Handling

freshname :: Text -> Transform Text
freshname pref = do
  n <- gets varNo
  modify (\s -> s {varNo = n + 1})
  pure $! pref <> show n


deffun :: Name -> [L1.Arg] -> L1.Type -> L1.Expr -> Transform ()
deffun name args retty body =
    tell $ DList.singleton (L1.DefFunction name args retty body)

-- | add a global closure definition
defclosure
  :: Name
  -> [L1.Arg]
  -> [L1.Arg]
  -> L1.Type
  -> L1.Expr
  -> Transform ()
defclosure name env args retty body =
  tell $ DList.singleton (L1.DefClosure name env args retty body)


-- | Lift an expression that expects the given arguments
-- and produces the given result type to a closure.
-- Capture all free local variables in the expression.
liftClosure
  :: [L1.Arg]
  -> L1.Type
  -> L1.ClosureTy
  -> L1.Expr
  -> Transform L1.Expr
liftClosure arglist retty cty body = do
  body' <- convert retty body
  name <- freshname "__closure_"
  let
    env = Map.toList $ L1.freeVars body' Map.\\ Map.fromList arglist
    capture = map (uncurry $ flip L1.Var) env
  defclosure name env arglist retty body'
  pure $! L1.Closure (L1.TClosure (map snd arglist) retty) name cty capture


-- | define the pair operations
defpair
  :: Name
  -> L1.Type
  -> Transform ()
defpair name pairTy =
  tell $ DList.singleton (L1.DefPair name pairTy (name <> "_fst") (name <> "_snd"))


----------------------------------------------------------------------
-- Transformations


-- | Convert an expression to the given type.
--
-- The function is partial and fails if the conversion is illegal.
convert :: L1.Type -> L1.Expr -> Transform L1.Expr
convert retTy expr =
  let ty = L1.exprType expr in
  case retTy of

    _ | retTy == ty -> pure expr

      | not (L1.isFunctionType retTy)
      , L1.isFunctionType ty
      , retTy == L1.returnType ty
      , null (L1.argTypes ty)
        -> call expr []

    L1.TClosure args1 ret1
      | L1.isFunctionType ty
      , args2 <- L1.argTypes ty
      , ret2 <- L1.returnType ty
      , args1 == args2 && ret1 == ret2
      -> partialCall expr []

    -- See NOTE 3 to understand what follows
    x@(L1.TClosure args ret)
      | L1.isFunctionType ty -> case ty of
          L1.TFunction [] x -> do
            varNames <- replicateM (length args) (freshname "__temp_")
            let argList = zipWith (\x y -> (x,y)) varNames args
            let vars = map (\(vname,vty) -> L1.Var vty vname) argList
            body <- call expr vars
            liftClosure argList ret L1.Lambda body
          ty -> panic $
            "[L1.Interpreter.convert] \
            \can't convert from " <> show ty <> " to " <> show retTy

    -- L1.TClosure [] ret
    --   | ret == ty
    --   -> liftClosure [] ret undefined expr

    -- L1.TClosure args1 ret1
    --   | L1.isFunctionType ty
    --   , (args2, ret2) <- L1.unfoldFunctionType ty
    --   , args1 == args2 && ret1 == ret2
    --   -> do
    --     argnames <- traverse (const $ freshname "__arg_") args1
    --     let arglist = zip argnames args1
    --         passed = zipWith L1.Var args1 argnames
    --     body <- call expr passed
    --     liftClosure arglist ret1 undefined body

    _ -> panic $
      "[L1.Interpreter.convert] \
      \can't convert from " <> show ty <> " to " <> show retTy

-- | Construct a call
--
-- Must either be a variable referring to
-- a global function, a local function, or a closure;
-- or a closure expression.
--
-- The function is partial and fails if its pre-condition is violated.
call :: L1.Expr -> [L1.Expr] -> Transform L1.Expr
call f args =
  case compare numargs numexpected of
    EQ -> saturatedCall f args
    LT -> partialCall f args
    GT -> do
      let (args1, args2) = splitAt numexpected args
      f' <- saturatedCall f args1
      call f' args2
  where
    numargs = length args
    numexpected = length . L1.argTypes . L1.exprType $ f

saturatedCall :: L1.Expr -> [L1.Expr] -> Transform L1.Expr
saturatedCall f args = L1.Call retty f <$> zipWithM convert argtys args
  where
    retty = L1.returnType . L1.exprType $ f
    argtys = L1.argTypes . L1.exprType $ f


partialCall :: L1.Expr -> [L1.Expr] -> Transform L1.Expr
partialCall f given = do
  let missing = drop (length given) . L1.argTypes . L1.exprType $ f
  arglist <- forM missing $ \ t -> do
    n <- freshname "__arg_"
    pure (n, t)
  let extra = [ L1.Var t n | (n, t) <- arglist ]
  body <- saturatedCall f (given ++ extra)
  let retty = L1.returnType . L1.exprType $ f
  liftClosure arglist retty L1.PartialCall body

-- | Find a common type between two types that both types can be converted to.
--
-- E.g. a function without arguments can be converted to its result type.
--
-- The function is partial and fails if there is no common type. (Sorry)
commonType :: L1.Type -> L1.Type -> L1.Type

commonType (L1.TFunction [] a) b | a == b = a
commonType (L1.TClosure  [] a) b | a == b = a
commonType a (L1.TFunction [] b) | a == b = a
commonType a (L1.TClosure  [] b) | a == b = a

commonType (L1.TFunction [] a) (L1.TFunction [] b) | a == b = a
commonType (L1.TFunction [] a) (L1.TClosure  [] b) | a == b = a
commonType (L1.TClosure  [] a) (L1.TFunction [] b) | a == b = a
commonType (L1.TClosure  [] a) (L1.TClosure  [] b) | a == b = a

commonType (L1.TFunction args1 ret1) (L1.TClosure args2 ret2)
  | args1 == args2 && ret1 == ret2
  = L1.TClosure args1 ret1
commonType (L1.TClosure args1 ret1) (L1.TFunction args2 ret2)
  | args1 == args2 && ret1 == ret2
  = L1.TClosure args1 ret1

commonType a b | a == b = a

commonType a b
  | (args1, ret1) <- L1.unfoldFunctionType a
  , (args2, ret2) <- L1.unfoldFunctionType b
  , args1 == args2 && ret1 == ret2
  = L1.TClosure args1 ret1

commonType a b = panic $
  "[L1.Interpreter.commonType] \
  \No common type between " <> show a <> " and " <> show b


-- | Convert (if necessary) two expressions to their common type.
--
-- See 'promoteType'.
--
-- The function is partial and fails if there is no common type.
promote :: L1.Expr -> L1.Expr -> Transform (L1.Expr, L1.Expr)
promote a b = (,) <$> convert ty a <*> convert ty b
  where ty = L1.exprType a `commonType` L1.exprType b

-- NOTE 1
{-
In a program like the following :

def baz : (Int, Int) =
  let x = (5,3)
   in let y = (2,3)
       in (1,2)

we don't want to generate a `mk` function and 2 accessors
for each pair. Instead we have devised a naming scheme
which captures the structure of the pair. We name the pair
as "__pair_<...>". In the <...> we write the preorder traversal
of the pair treating the entire complex pair as a binary
tree. This way all pairs of the same types generate just one
set of `mk` and accessor functions.

Also it removes the burden of carrying the name of the pair
around. We can simply query the `getNameFromType` function and
generate the name for the given type.

-}



-- NOTE 2
{-
The logic is much more simpler now for compiling composed
functions. Imagine having something like

    mapSignal (\x => x + 1)
>>> mapSignal (\x => x + 2)
>>> mapSignal (\x => x + 3)

Irrespective of the bracketing this flattens the tree to the
form [ \x => x + 1
     , \x => x + 2
     , \x => x + 3
     ]

And represents composition using function application so the
above becomes

\temp -> (\x -> x + 3) ((\x -> x + 2) ((\x -> x + 1) temp))

-}


-- NOTE 3:
{-
This allows compiling functions like:

case 1:
def foo : (Int -> Int) = \(x:Int) => x

def bar = foo

or

case 2:
def baz : (Int -> Int -> Int) = \(x:Int) (y:Int)=> x + y

def bar = baz


Previously a function like `bar` would not compile.

The logic for note 3 transforms `bar` to:

def bar = \(temp_var:Int) -> foo temp_var

in case 1

and

def bar = \(temp_var1 : Int) (temp_var2 : Int) => baz temp_var1 temp_var2

in case 2.

It also detects this kind of function using the logic that their
types would be something like: TFunction [] (TClosure a b)
and then simply creating the lambda
-}

-- NOTE 4
{-

*** : SF a b -> SF c d -> SF (a, c) (b, d)

Compiles to
f : a -> b
g : c -> d

combine gives

\(t : (a, c)) -> (f (fst# t), g (snd# t))

-}

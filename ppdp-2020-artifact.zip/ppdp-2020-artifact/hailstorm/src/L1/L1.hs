{-# LANGUAGE DeriveGeneric #-}

module L1.L1
  ( Name
  , Type (..)
  , Lit (..)
  , Global (..)
  , Arg
  , PrimOp (..)
  , Expr (..)
  , ClosureTy (..)
  , Program (..)
  -- accessors
  , exprType
  , freeVars

  -- Helpers
  , programMainNumArgs
  , numArgs
  , argTypes
  , returnType
  , isFunctionType
  , unfoldFunctionType
--   , globalNameTy
  , getNameFromType
  )
where

import Protolude hiding (Type)
import Data.Map.Strict (Map)
import qualified Data.Map.Strict as Map
import AST ( Name
           , Lit (..))

data Type
  = TVoid
  | TInt
  | TFloat
  | TBool
  | TFunction [Type] Type
  | TClosure  [Type] Type
  | TSeq Type
  | TPair Type Type
  deriving (Show, Eq, Ord, Generic)

type Arg = (Name, Type)

data Expr
  = Lit      Type Lit
  | Var      Type Name
  | Global   Type Name
  | Let      Type Name Expr Expr
  | If       Type Expr Expr Expr
  | Call     Type Expr [Expr] -- fully applied call to function or closure
  | Closure  Type Name ClosureTy [Expr]
  --                                ^
  --                           environment

  | PrimOp   Type PrimOp
  | Pair     Type Expr Expr
  deriving (Show, Eq, Ord, Generic)

data ClosureTy = PartialCall
               | Lambda
               | State
               deriving (Show, Eq, Ord, Generic)

-- | global definition
data Global
  = DefFunction Name [Arg] Type Expr
    -- ^ function definition
  | DefClosure Name [Arg] [Arg] Type Expr
    --                ^     ^------------  argument list
    --                |------------------- environment capture
    -- ^ global closure-function definition,
    -- expects a capture and arguments
  | DefPair Name Type FstProjection SndProjection
  deriving (Show, Eq, Ord, Generic)

type FstProjection = Name
type SndProjection = Name

-- | the program
data Program = Program
  { programGlobals :: [Global]
  , programMainArgNames :: [Name]
  , programMainType :: Type
  , programMainFunction :: Expr
  }
  deriving (Show, Eq, Ord, Generic)


data PrimOp
  = NewSeqInt
  | GetSeqInt
  | SetSeqInt
  | NewSeqBool
  | GetSeqBool
  | SetSeqBool
  | Fst
  | Snd
  -- | Binary operations
  | Equal
  | Add
  | Sub
  | Mul
  | DivF
  | AddF
  | SubF
  | MulF
  -- | Relational operations
  | HGT
  | HLT
  | HGE
  | HLE
  -- | Effectful combinators
  | ReadIntStream
  | WriteIntStream
  | ReadBoolStream
  | WriteBoolStream
  | Rate Expr
  -- | GRiSP specific combinators
  | ReadColor
  | WriteColor
  -- | User invisible state primops
  | Get Name Expr
  | Put Name Expr
  deriving (Show, Eq, Ord, Generic)
-----------------------------------------
-- Accessors
-- | extract the type of an expression
exprType :: Expr -> Type
exprType = \case
  Lit ty _ -> ty
  Var ty _ -> ty
  Global ty _ -> ty
  Let ty _ _ _ -> ty
  If ty _ _ _ -> ty
  Call ty _ _ -> ty
  Closure ty _ _ _ -> ty
  PrimOp ty _ -> ty
  Pair ty _ _ -> ty

-- | all unbound variables in an expression
-- (global variables are considered bound)
freeVars :: Expr -> Map Name Type
freeVars = \case
  Lit _ _ -> Map.empty
  Var ty name -> Map.singleton name ty
  Global _ _ -> Map.empty
  Let _ name ebound ein ->
    freeVars ebound `Map.union` Map.delete name (freeVars ein)
  If _ cond th el ->
    freeVars cond `Map.union` freeVars th `Map.union` freeVars el
  Call _ fun args -> Map.unions (map freeVars (fun:args))
  Closure _ _ cty env ->
    case cty of
      Lambda -> Map.unions (map freeVars env)
      _ -> Map.empty
  PrimOp _ pop ->
    case pop of
      Get _ expr -> freeVars expr
      Put _ expr -> freeVars expr
      _ -> Map.empty
  Pair _ expr1 expr2 ->
    Map.unions $ (freeVars expr1) : (freeVars expr2) : []
----------------------------------------------------------------------
-- Helpers

programMainNumArgs :: Program -> Int
programMainNumArgs = length . programMainArgNames

-- | number of expected arguments due to a function's type
numArgs :: Type -> Int
numArgs = length . argTypes

-- | argument types due to a function's type
argTypes :: Type -> [Type]
argTypes = \case
  TVoid -> []
  TInt -> []
  TFloat -> []
  TBool -> []
  TFunction args _ -> args
  TClosure  args _ -> args
  TSeq _  -> []
  TPair {} -> []

-- | a function's return type due to its type
returnType :: Type -> Type
returnType = \case
  TVoid             -> TVoid
  TInt              -> TInt
  TFloat            -> TFloat
  TBool             -> TBool
  TFunction _ retty -> retty
  TClosure  _ retty -> retty
  TSeq ty           -> TSeq ty
  TPair ty1 ty2     -> TPair ty1 ty2

-- | distinguish functions and values
isFunctionType :: Type -> Bool
isFunctionType = \case
  TFunction _ _ -> True
  TClosure  _ _ -> True
  _ -> False

unfoldFunctionType :: Type -> ([Type], Type)
unfoldFunctionType = \case
  TFunction args ret ->
    let (args', ret') = unfoldFunctionType ret in
    (args ++ args', ret')
  TClosure args ret ->
    let (args', ret') = unfoldFunctionType ret in
    (args ++ args', ret')
  t -> ([], t)

-- globalNameTy :: Global -> (Name, Type)
-- globalNameTy (DefFunction name _ ty _)  = (name, ty)
-- globalNameTy (DefClosure name _ _ ty _) = (name, ty)
-- globalNameTy (DefPair name ty) = (name, ty)

-- | This function is always called from a Pair constructor
getNameFromType :: Type -> Text
getNameFromType ty = "__pair_" <> getNameFromType' ty

-- pre-order traversal of the tree
getNameFromType' :: Type -> Text
getNameFromType' (TPair t1 t2) = "p" <> getNameFromType' t1 <> getNameFromType' t2
getNameFromType' (TFunction _ _) = "f"
getNameFromType' TInt = "i"
getNameFromType' TBool = "b"
getNameFromType' TFloat = "f"
getNameFromType' (TClosure _ _) = "c"
getNameFromType' (TSeq _) = "s"
getNameFromType' TVoid = "v"

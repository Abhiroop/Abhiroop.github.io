module L1.Optimizer
  ( optimize
  , debugOptimizer) where

import Protolude
import L1.L1

-- Optimizations
import L1.Optimizer.Inline
import L1.Optimizer.Lambdalift
import L1.Optimizer.PartialEvaluator
-- this module  experiments with future optimizations and test the optimal order for optimizations
optimize :: Program -> Program
optimize = partialEvaluate VoidTermEval . inline . lambdalift

debugOptimizer :: Program -> IO ()
debugOptimizer p = do
  print "Original Program"
  print p
  print "Lambda Lifting"
  let o1 = lambdalift p
  print o1
  print "Inlining"
  let o2 = inline o1
  print o2
  print "Parital Evaluation of term of type Void"
  let o3 = partialEvaluate VoidTermEval o2
  print o3

{-# LANGUAGE BangPatterns #-}

module L1.Optimizer.Inline
  ( inline
  ) where

import Data.List (partition)
import L1.L1

-- this module inlines function calls, currently only programs
-- containing partial applications. inlining other programs are
-- possible as well but we have LLVM waiting to do a bunch of
-- inlining for us
import Protolude hiding (Type)

import qualified Data.Map.Strict as M
import qualified Data.Text as T
import L1.Optimizer.Internal.Infra

import qualified Debug.Trace as DT

-- XXX : Not a very smart heuristic but if there are any closures
-- (i.e partial applications) in the program. Inlining plain literals
-- is not worthwhile, we can resort to LLVM for that.
inline :: Program -> Program
inline p =
  if isNoPartialCalls p
    then p
    else inlineProg p

inlineProg :: Program -> Program
inlineProg p@(Program glbls args mainTy mainFunc) =
  let allCs = allClosures p
      init = initialState allCs --InlineState
      -- makes the whole process less compute intensive by simply
      -- inlining globals which have partial calls
      (noPCallGlbls, pCallGlbls) = partition isNoPartialCallsGlobal glbls
      (inlinedGlbls, newState) =
        runState (runInline $ mapM inlineGlobal pCallGlbls) init
      allCs' = closures newState
      inlinedGlbls' = inlineClosureEnv (inlinedGlbls ++ noPCallGlbls) allCs' []
      inlinedMain =
        evalState (runInline $ inlineExpr mainFunc) (initialState allCs')
      newMainTy = exprType inlinedMain
   in Program inlinedGlbls' args newMainTy inlinedMain

inlineGlobal :: Global -> Inline Global
inlineGlobal (DefFunction name args ty expr) = do
  gArgs <- gets globalArgs
  modify $ \s -> s {globalArgs = args}
  expr' <- inlineExpr expr
  return $ DefFunction name args ty expr'
inlineGlobal clos = return clos

type Bindings = Map Name Expr

data InlineState =
  InlineState
    { closures :: Closures
    , bindings :: Bindings
    , globalArgs :: Args
    }

initialState :: Closures -> InlineState
initialState c = InlineState { closures = c
                             , bindings = M.empty
                             , globalArgs = []
                             }

newtype Inline a =
  Inline
    { runInline :: State InlineState a
    }
  deriving (Functor, Applicative, Monad, MonadState InlineState)

inlineExpr :: Expr -> Inline Expr
inlineExpr (Lit ty lit) = return $ (Lit ty lit)
inlineExpr v@(Var ty name) = do
  b <- gets bindings
  ga <- gets globalArgs
  if ((T.take 5 name) == "__arg" || (name `elem` (map fst ga)))
                                    -------------------------
                                     --         ^
                                     -- don't inline function arguments
    then return v -- don't inline generated variables
    else do
      let exp = fromMaybe undefBinding (M.lookup name b)
      return $! exp
  where
    undefBinding = panic "[L1.Optimizer.Inline] binding not found exception"
inlineExpr (Global ty name) = return (Global ty name) -- not inlining recursive calls
inlineExpr (Let ty name ebound ein) = do
  ebound' <- inlineExpr ebound
  b <- gets bindings
  modify $ \s -> s {bindings = M.insert name ebound' b}
  inlineExpr ein
inlineExpr (If ty econd eth eelse) = do
  econd' <- inlineExpr econd
  eth' <- inlineExpr eth
  eelse' <- inlineExpr eelse
  return $ (If ty econd' eth' eelse')
inlineExpr (Call ty func args) = do
  func' <- inlineExpr func
  bndgs <- gets bindings
  cls <- gets closures
  args' <- mapM inlineExpr args
  return $ Call ty func' args'
inlineExpr c@(Closure ty name cty env) =
  case cty of
    PartialCall -> do
      env' <- prune env name
      return $ Closure ty name cty env'
    Lambda -> do
      env' <- mapM inlineExpr env
      return $ Closure ty name cty env'
    State -> return c
  where
    undefClos = panic "[L1.Optimizer.Inline] encountered undefined closure"
    -- The purpose of prune is to look at the free variables of a partial application
    -- and then travel to the closures that contain those variables  and inline them
    prune :: [Expr] -> Name -> Inline [Expr]
    prune [] _ = return []
    prune (e:es) cName =
      case e of
        v@(Var ty varName) -> do
          c <- gets closures
          let (glClsEnv, glClsArgs, glClsTy, glClsExpr) =
                fromMaybe undefClos (M.lookup cName c)
          !glClsExpr' <- inlineExpr glClsExpr
          let glClsEnv' = removeVarFromEnv v glClsEnv
          modify $! \s ->
            s
              { closures =
                  M.insert cName (glClsEnv', glClsArgs, glClsTy, glClsExpr') c
              }
          es' <- prune es cName
          return $! es'
        _ -> do
          e' <- inlineExpr e
          es' <- prune es cName
          return $! e' : es'
    removeVarFromEnv (Var vTy vName) env =
      filter (\(eName, eTy) -> not (eName == vName && eTy == vTy)) env
    removeVarFromEnv _ _ =
      panic "[L1.Optimizer.Inline] non variable found in environment"
inlineExpr (PrimOp ty op) = return $ (PrimOp ty op)
inlineExpr (Pair ty expr1 expr2) = do
  expr1' <- inlineExpr expr1
  expr2' <- inlineExpr expr2
  return $ (Pair ty expr1' expr2')


matchTy :: Type -> Expr -> Bool
matchTy ty expr =
  case expr of
    (Lit ty' _) -> ty == ty'
    (Var ty' _) -> ty == ty'
    (Global ty' _) -> ty == ty'
    (Let ty' _ _ _) -> ty == ty'
    (If ty' _ _ _) -> ty == ty'
    (Call ty' _ _) -> ty == ty'
    (Closure ty' _ _ _) -> ty == ty'
    (PrimOp ty' _) -> ty == ty'
    (Pair ty' _ _) -> ty == ty'

isNoPartialCalls :: Program -> Bool
isNoPartialCalls (Program glbls _ _ expr) =
  (all isNoPartialCallsGlobal glbls) && (isNoPartialCallsExpr expr)

isNoPartialCallsGlobal :: Global -> Bool
isNoPartialCallsGlobal (DefFunction _ _ _ expr) = isNoPartialCallsExpr expr
isNoPartialCallsGlobal (DefClosure {}) = True -- just check the functions
isNoPartialCallsGlobal _ = True

isNoPartialCallsExpr :: Expr -> Bool
isNoPartialCallsExpr expr =
  case expr of
    Lit {} -> True
    Var {} -> True
    Global {} -> True
    Let _ _ ebound ein ->
      (isNoPartialCallsExpr ebound) && (isNoPartialCallsExpr ein)
    If _ cond th els ->
      (isNoPartialCallsExpr cond) &&
      (isNoPartialCallsExpr th) && (isNoPartialCallsExpr els)
    Call _ func args ->
      (isNoPartialCallsExpr func) && (and $ map isNoPartialCallsExpr args)
    Closure _ _ cty env ->
      case cty of
        PartialCall ->
          null env -- additional heuristic which doesn't inline if there are no free variables
        Lambda -> null env
        State  -> True
    PrimOp {} -> True
    Pair _ expr1 expr2 -> (isNoPartialCallsExpr expr1) && (isNoPartialCallsExpr expr2)

-- The purpose of this function is generating the inlined value of the various parts
-- of the closures which were generated during the inlining process in the Inline monad
-- As you can see this simply updates the environment etc of the closures
inlineClosureEnv :: [Global] -> Closures -> [Global] -> [Global]
inlineClosureEnv [] _ gs = gs
inlineClosureEnv (x:xs) cls gs =
  case x of
    DefClosure n _ _ _ _ ->
      let (env, args, ty, expr) = fromMaybe undefClos (M.lookup n cls)
       in inlineClosureEnv xs cls ((DefClosure n env args ty expr) : gs)
    g@(_) -> inlineClosureEnv xs cls (g : gs)
  where
    undefClos = panic "[L1.Optimizer.Inline] encountered undefined closure"

getGlobalName :: Expr -> Name
getGlobalName (Global _ name) = name
getGlobalName e =
  panic $
  "[L1.Optimizer.Inline] attempting to get the name of a non global" <> show e

{-# LANGUAGE DeriveFoldable #-}
{-# LANGUAGE DeriveGeneric #-}
module L1.Optimizer.Internal.Infra where

-- Optimization Infrastructure

import L1.L1
import Protolude hiding (Type)
import Utils
import qualified Data.Map.Strict as M

type FreeVariables = Map Name Type

-- type AnnNode = (FreeVariables, AnnExpr)

-- data AnnExpr
--   = ALit      Type Lit
--   | AVar      Type Name
--   | AGlobal   Type Name
--   | ALet      Type Name AnnNode AnnNode
--   | AIf       Type AnnNode AnnNode AnnNode
--   | ABinaryOp Type BinaryOp AnnNode AnnNode
--   | ACall     Type AnnNode [AnnNode] -- example in closure.hst
--   | AClosure  Type Name ClosureTy [Expr] -- we intentionally do not annotate the environment as `AnnNode` explanation in closure.hst
--   deriving (Show, Eq, Ord, Generic)


-- data AnnGlobal
--   = ADefFunction Name [Arg] Type AnnExpr
--   | ADefClosure Name [Arg] [Arg] Type AnnExpr
--   deriving (Show, Eq, Ord, Generic)

-- data AnnProgram
--  = AnnProgram [AnnGlobal] [Name] AnnExpr
--  deriving (Show, Eq, Ord, Generic)


-- transform :: Program -> AnnProgram
-- transform (Program glbls mainArgs mainFunc) = AnnProgram (map transfGlobal glbls) mainArgs (transfExpr mainFunc)

-- transfGlobal :: Global -> AnnGlobal
-- transfGlobal (DefFunction name args ty expr)     = ADefFunction name args ty (transfExpr expr)
-- transfGlobal (DefClosure  name env args ty expr) = ADefClosure name env args ty (transfExpr expr)

-- transfExpr :: Expr -> AnnExpr
-- transfExpr expr = case expr of
--   (Lit ty lit)                  -> ALit ty lit
--   (Var ty name)                 -> AVar ty name
--   (Global ty name)              -> AGlobal ty name
--   (Let ty name ebound ein)      -> ALet ty name (fvAnn ebound) (fvAnn ein)
--   (If ty cond th els)           -> AIf ty (fvAnn cond) (fvAnn th) (fvAnn els)
--   (BinaryOp ty binop exp1 exp2) -> ABinaryOp ty binop (fvAnn exp1) (fvAnn exp2)
--   (Call ty func args)           -> ACall ty (fvAnn func) (map fvAnn args)
--   (Closure ty name cty env)     -> AClosure ty name cty env
--   where
--     fvAnn = (&&&) freeVars transfExpr

type Env = [Arg]
type Args = [Arg]
type Closures = Map Name (Env, Args, Type, Expr)

allClosures :: Program -> Closures
allClosures (Program glbls _ _ _) = (M.fromList . map closure . filter onlyClosures) glbls
  where
    onlyClosures glbl = case glbl of
      DefClosure _ _ _ _ _ -> True
      DefFunction _ _ _ _  -> False
      _                    -> False

    closure glbl = case glbl of
     DefClosure name env args ty expr -> (name, (env, args, ty, expr))
     DefFunction _ _ _ _ -> panic $
      "[L1.Optimizer.Internal.Infra] \
      \Encountered function instead of closure"
     _ -> panic $
      "[L1.Optimizer.Internal.Infra] \
      \Encountered pair operation instead of closure"


{-
The purpose of this function is to help the main
function decide if it should loop or not. This is
applied on the second argument of a loop function

-}

isAllVoid :: Type -> Bool
isAllVoid TVoid = True
isAllVoid TInt  = False
isAllVoid TFloat = False
isAllVoid TBool = False
isAllVoid (TSeq ty)       = isAllVoid ty
isAllVoid (TPair ty1 ty2) = isAllVoid ty1 && isAllVoid ty2
isAllVoid (TFunction _ _) = False
isAllVoid (TClosure _ _)  = False



-- A more general exprType function. Recommended to use this
-- This handles cases of returning the correct type when
-- calling global variables where the type is
-- (TFunction [] (TClosure ty1 ty2))
exprType' body =
  case exprType body of
    TFunction [] ret -> ret
    TFunction args ret -> TClosure args ret
    x -> x

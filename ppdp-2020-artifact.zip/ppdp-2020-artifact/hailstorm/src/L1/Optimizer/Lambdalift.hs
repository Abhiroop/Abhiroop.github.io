module L1.Optimizer.Lambdalift (lambdalift) where

-- this module lambda lifts all closures

import L1.L1
import Protolude hiding (Type)
import qualified Data.Map.Strict as M

import L1.Optimizer.Internal.Infra

lambdalift :: Program -> Program
lambdalift p = if isNoFreeProgram p
               then p
               else liftProg p


liftProg :: Program -> Program
liftProg p@(Program glbls args mainType mainFunc) =
  let allCs = allClosures p
      funcNos = [500,1000..] -- XXX : Hack! assumes each function would require a max of 500 numbers for naming
      glbls' = zip funcNos glbls
      glbls'' = map (\(x,y) -> liftGlobal allCs x y) glbls'
      (newglbls, liftedFuncs) = (map fst glbls'', join $ map snd glbls'')
      (newMainFunc, mainLifts) = liftExpr allCs 0 mainFunc
      allGlobals = newglbls ++ liftedFuncs ++ mainLifts
      newMainType = exprType newMainFunc
      newProg = Program allGlobals args newMainType newMainFunc
   in if checkForFV (liftedFuncs ++ mainLifts) -- XXX : Hack! This assumes no free variables
                                               -- remain in the actual expression but only in the lifted funcs
      then newProg
      else liftProg newProg
   where
     checkForFV = and . map isNoFreeGlobal


type LiftedClosures = Global

liftGlobal :: Closures -> Int -> Global -> (Global, [LiftedClosures])
liftGlobal cls n (DefFunction name args ty expr) =
  let (expr', lcs) = liftExpr cls n expr
   in ((DefFunction name args ty expr'), lcs)
liftGlobal cls n (DefClosure name env args ty expr) =
  let (expr', lcs) = liftExpr cls n expr
   in ((DefClosure name env args ty expr'), lcs)
liftGlobal _ _ g =(g, [])

-- XXX: This is an extremely computation intensive function
-- XXX: In case of memory or space leaks investigate here
liftExpr :: Closures -> Int -> Expr -> (Expr, [LiftedClosures])
liftExpr cls n expr = case expr of
  (Lit ty lit) -> (Lit ty lit, [])
  (Var ty name) -> (Var ty name, [])
  (Global ty name) -> (Global ty name, [])
  (Let ty name ebound ein) ->
    let (ebound', eboundLifts) = liftExpr cls (n + 1) ebound
        (ein', einLifts)    = liftExpr cls (n + 50) ein
     in (Let ty name ebound' ein', eboundLifts ++ einLifts)
  (If ty cond th els) ->
    let (cond', cLifts) = liftExpr cls (n + 1 ) cond
        (th'  , tLifts) = liftExpr cls (n + 50) th
        (els' , eLifts) = liftExpr cls (n + 100) els
        lifts = cLifts ++ tLifts ++ eLifts
     in (If ty cond' th' els', lifts)
  (Call ty func args) ->
    let func' = fst $ liftExpr cls (n + 1) func
        -- XXX : Line 73 - 77 solves the function numbering issue as a hack but for God's sake use a state monad already!!
        funcNos = map (n +) [5,6..]
        args' = zip funcNos args
        args'' = map (\(x, y) -> liftExpr cls x y) args'
        (args''', liftedClosures) = unzip args'' -- list of pairs to pair of lists
        lifts = snd (liftExpr cls (n + 1) func)
             ++ (join liftedClosures)
     in (Call ty func' args''', lifts)
  clos@(Closure ty clname clTy clenv) ->
    case clTy of
      Lambda ->
        let (env, args, dcty, expr) = fromMaybe undefclos (M.lookup clname cls)
            funcName  = "liftedFunc" <> (show n)
            closName  = "newClos" <> (show $ n + 1)
            argName = zipWith (<>) (repeat ("__arg_" :: Text)) (map show [n+2 ..]) -- ["__arg_4", "__arg_5",..]
            args' = map (\((_,argty), argN) -> (argN, argty)) (zip args argName)
            liftedFunc = DefFunction funcName (env ++ args) (returnType ty) expr
            newClos    = Closure ty closName PartialCall clenv
            newClosDef = DefClosure closName env args' (returnType ty)
                         (Call
                          (returnType ty)
                          (Global (constructFunctionType env args dcty) funcName)
                          (map envToVar (env ++ args'))
                         )
        in (newClos, [liftedFunc,newClosDef])
      _ -> (clos, [])
  p@(PrimOp ty primop) -> (PrimOp ty primop, [])
  Pair ty expr1 expr2 ->
    let (expr1', lifts1) = liftExpr cls (n + 1) expr1
        (expr2', lifts2) = liftExpr cls (n + 50) expr2
        liftedCs = lifts1 ++ lifts2
     in (Pair ty expr1' expr2', liftedCs)
  where
    undefclos = panic $ "[L1.Optimizer.Lambdalift] encountered undefined closure"
    envToVar (name, ty) = (Var ty name)
    constructFunctionType env' args' dcty' = (TFunction (map snd (env' ++ args')) dcty')


-- Check if there are any free variables remaining in the program
-- Returns True if there are no free variables else returns False
-- Until this function returns true always the lifting pass has to be run
isNoFreeProgram :: Program -> Bool
isNoFreeProgram (Program glbls _ _ expr)
  = (and $ map isNoFreeGlobal glbls) && (isNoFreeExpr expr)


isNoFreeGlobal :: Global -> Bool
isNoFreeGlobal (DefFunction _ _ _ expr)  = isNoFreeExpr expr
isNoFreeGlobal (DefClosure _ _ _ _ expr) = isNoFreeExpr expr
isNoFreeGlobal _ = True


isNoFreeExpr :: Expr -> Bool
isNoFreeExpr expr =
  case expr of
    Lit {} -> True
    Var {} -> True
    Global {} -> True
    Let _ _ ebound ein   -> (isNoFreeExpr ebound) && (isNoFreeExpr ein)
    If _ cond th els     -> (isNoFreeExpr cond)
                         && (isNoFreeExpr th)
                         && (isNoFreeExpr els)
    Call _ func args     -> (isNoFreeExpr func)
                         && (and $ map isNoFreeExpr args)
    Closure _ _ cty env  ->
      case cty of
        PartialCall -> True
        Lambda -> null env
        State -> True
    PrimOp {} -> True
    Pair _ expr1 expr2 -> (isNoFreeExpr expr1) && (isNoFreeExpr expr2)

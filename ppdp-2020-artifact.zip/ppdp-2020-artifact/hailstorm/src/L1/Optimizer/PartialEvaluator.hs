module L1.Optimizer.PartialEvaluator where

import L1.L1
import Protolude hiding (Type)
import L1.Optimizer.Internal.Infra

import qualified Data.Map.Strict as M

-- This module provides the infrastructure for partial evaluation

data Parameter =
    -- | generate a compile term of type void and evaluate the program
    --   to get rid of the term of type void
    VoidTermEval

partialEvaluate :: Parameter -> Program -> Program
partialEvaluate param p =
  case param of
    VoidTermEval -> evalVoid p

-- | generate a compile time term of type void
--   and partially evaluate expression with this term
evalVoid :: Program -> Program
evalVoid p@(Program glbls mainArgs mainTy mainFunc) =
  case mainTy of
    TClosure [ty] _ ->
      if isAllVoid ty
      then
        -- this covers SF () _ , SF ((), ()) _ etc
        let mainTy' = evalVoidTy mainTy
            allCs = allClosures p
            (removeC, mainFunc') = evalMainFunc allCs mainFunc
            glbls' = removeGlobal removeC glbls
            glbls'' = map evalGlobal glbls'
        in Program glbls'' mainArgs mainTy' mainFunc'
      else p
    _ -> p

evalVoidTy :: Type -> Type
evalVoidTy ty@(TClosure [x] ret) =
  if isAllVoid x
  then TClosure [] ret
  else ty
evalVoidTy ty@(TFunction [x] ret) =
  if isAllVoid x
  then TFunction [] ret
  else ty
-- Replaced the bottom cases with the ones on top - more general
-- evalVoidTy (TClosure [TVoid] ret) = TClosure [] ret
-- evalVoidTy (TFunction [TVoid] ret) = TFunction [] ret
-- | below handles partial application
evalVoidTy (TFunction [] ret) = TFunction [] (evalVoidTy ret)
evalVoidTy (TClosure [] ret) = TClosure [] (evalVoidTy ret)
evalVoidTy (TPair ty1 ty2) = TPair (evalVoidTy ty1) (evalVoidTy ty2)
-- | In all other position like say `TClosure [TInt, TVoid] TInt`
--   it is not possible to create a term of the above type. The
--   only term capable of creating void is readIntStream and
--   writeIntStream and they are both covered by the first 2 cases.
evalVoidTy ty = ty

evalMainFunc :: Closures -> Expr -> (Name, Expr)
evalMainFunc allCs expr =
  case expr of
    (Closure _ clName _ _) ->
      let (_, _, _, expr) = allCs M.! clName
       in (clName, evalExpr expr)
    _ -> panic "Main type is closure but expression is not a closure"


evalGlobal :: Global -> Global
evalGlobal (DefClosure name env args ty expr) =
  let env'  = evalArgs env
      args' = evalArgs args
   in DefClosure name env' args' (evalVoidTy ty) (evalExpr expr)
evalGlobal (DefFunction name args ty expr) =
  DefFunction name (evalArgs args) (evalVoidTy ty) (evalExpr expr)
evalGlobal g = g

evalArgs :: [Arg] -> [Arg]
evalArgs = filter (\(name, ty) -> not $ isAllVoid ty)

evalExpr :: Expr -> Expr
evalExpr exp = fromMaybe exprEvald $ evalExpr' exp
  where
    exprEvald = panic "Expression has been evaluated away. Nothing left"

evalExpr' :: Expr -> Maybe Expr
evalExpr' = \case
  -- | expressions involved with effects

  -- fst# (x,y) where x is of type void
  -- should return nothing
  Call retty (PrimOp popty Fst) args -> do
    -- when applying fst# to an expression we are ensured by the
    -- typechecker that there is just one item to which fst# is
    -- applied which is a pair and the same holds for snd#
    let arg1 = fromMaybe (panic "") $ head args
    let ety = exprType' arg1
    case ety of
      TPair TVoid _ -> Nothing
      _ -> do
        arg1' <- evalExpr' arg1
        Just $ Call (evalVoidTy retty) (PrimOp (evalVoidTy popty) Fst) [arg1']

  -- snd# (x,y) where y is of type void
  -- should return nothing
  Call retty (PrimOp popty Snd) args -> do
    -- we are sure that args is of length 1
    let arg1 = fromMaybe (panic "") $ head args
    let ety = exprType' arg1
    case ety of
      TPair _ TVoid -> Nothing
      _ -> do
        arg1' <- evalExpr' arg1
        Just $ Call (evalVoidTy retty) (PrimOp (evalVoidTy popty) Snd) [arg1']

  Call ty expr args -> do
    expr' <- evalExpr' expr
    args' <- sequenceA $ filter isJust (fmap evalExpr' args)
    Just $ Call (evalVoidTy ty) expr' args'
  Closure ty name clTy env -> do
    env' <- sequenceA $ filter isJust (fmap evalExpr' env)
    Just $ Closure (evalVoidTy ty) name clTy env'
  Global ty name ->
    Just $ Global (evalVoidTy ty) name
  Var ty name ->
    if isAllVoid ty
    then Nothing
    else Just $ Var ty name
  PrimOp ty pop ->
    case pop of
      Rate expr -> do
        expr' <- evalExpr' expr
        Just $ PrimOp (evalVoidTy ty) (Rate expr')
      _ -> Just $ PrimOp (evalVoidTy ty) pop

  -- | innocent expressions
  -- if we eval things like let, it will now cause effects
  -- but partial evaluation is the last stage of the compilation
  -- so maybe we don't mind effects
  Lit ty lit -> Just $ Lit (evalVoidTy ty) lit
  Let ty name ebound ein -> do
    ebound' <- evalExpr' ebound
    ein'    <- evalExpr' ein
    Just $ Let (evalVoidTy ty) name ebound' ein'
  If ty econd eth els -> do
    econd' <- evalExpr' econd
    eth'   <- evalExpr' eth
    els'   <- evalExpr' els
    Just $ If (evalVoidTy ty) econd' eth' els'
  -- XXX: Pair is the tricky bit here. Especially when accepting
  -- 2 signal which have input from (). This will be relevant
  -- when implementing `(***)`
  Pair ty exp1 exp2 -> do
    exp1' <- evalExpr' exp1
    exp2' <- evalExpr' exp2
    Just $ Pair (evalVoidTy ty) exp1' exp2'

removeGlobal :: Name -> [Global] -> [Global]
removeGlobal name glbls = removeGlobal' name glbls []

removeGlobal' :: Name -> [Global] -> [Global] -> [Global]
removeGlobal' name [] gs = gs
removeGlobal' name (x:xs) gs = case x of
  DefClosure n _ _ _ _ ->
    if n == name
    then removeGlobal' name xs gs
    else removeGlobal' name xs (x:gs)
  -- | Not removing DefFunction or DefPair for now
  _ -> removeGlobal' name xs (x:gs)

{-# LANGUAGE RecordWildCards #-}
module L2.Erlang.Interpreter
  ( l1Tol2
  , ppErl
  , Board (..)
  ) where

import Protolude
import Data.String
import GHC.Float (float2Double)
import L1.L1 as L1
import L1.Optimizer.Internal.Infra
import qualified Data.Char as C
import qualified Data.Text as T
import qualified Data.Map.Strict as M
import qualified Language.CoreErlang.Syntax as ES
import qualified Language.CoreErlang.Parser as EP
import qualified Language.CoreErlang.Pretty as EPR


data Board = GRiSP
           | General

ppErl :: ES.Ann ES.Module -> String
ppErl = EPR.prettyPrint

data CodegenState =
  CodegenState
    { closures :: Closures
    , callingFuncName :: Name
    , arities :: ArityMap
    , count :: Int
    }

newtype Codegen a =
  Codegen
    { runCodegen :: State CodegenState a
    }
  deriving (Functor, Applicative, Monad, MonadState CodegenState)

initState :: Closures -> Name -> ArityMap -> Int -> CodegenState
initState cls name amap num =
  CodegenState { closures = cls
               , callingFuncName = name
               , arities = amap
               , count = num
               }

-- for test purpose

l1Tol2 :: L1.Program -> Board -> ES.Ann ES.Module
l1Tol2 p@(Program { programGlobals = pgs
                  , programMainFunction = mainExpr
                  , programMainType = mainTy
                  , ..
                  }) board =
  let arityMap = genArityMap p
      allCs = allClosures p
      cgState = (initState allCs T.empty arityMap 0)
                             --      ^
                             --      |
                             -- will be initialized in each individual Global constructor
      pgs' = map (codegenGlobal cgState) (filter (not . isPair) pgs) -- ignoring global pairs
      main' = genmain mainExpr mainTy cgState
      pgs'' = pgs' ++ [ firstProjection
                      , secondProjection
                      , main'
                      ]
   in case board of
        GRiSP ->
          ES.Constr
          (ES.Module
            (ES.Atom "robot")
            [ES.Function (ES.Atom "start",2),ES.Function (ES.Atom "stop",1)]
            grispcompilergen
            (pgs'' ++ grispfuns)
          )
        General ->
          ES.Constr
          (ES.Module
           (ES.Atom "test") -- need to support module names in hailstorm
           (genExports arityMap pgs)
           compilergennonsense
           pgs''
          )

codegenGlobal :: CodegenState -> L1.Global -> ES.FunDef
codegenGlobal cs@(CodegenState { arities = amap,.. }) = \case
  DefFunction name args _ expr ->
    let arity = amap M.! name
        cgState' = cs { callingFuncName = name }
        expr' = evalState (runCodegen $ codegenExpr expr) cgState'
     in ES.FunDef
          (ES.Constr (ES.Function (ES.Atom (T.unpack name),arity)))
          (ES.Constr (ES.Lambda (map argToVar args) expr'))
  DefClosure name env args _ expr ->
    let arity = amap M.! name
        cgState' = cs { callingFuncName = name }
        expr' = evalState (runCodegen $ codegenExpr expr) cgState'
     in ES.FunDef
          (ES.Constr (ES.Function (ES.Atom (T.unpack name),arity)))
          (ES.Constr (ES.Lambda (map argToVar (env ++ args)) expr'))
  DefPair _ _ _ _ -> panic "[L2.Erlang. Interpreter] Pairs already filtered out"
  where
    argToVar = T.unpack . capitalize . fst

codegenExpr :: Expr -> Codegen ES.Exps
codegenExpr expr = case expr of
  Lit _ (LInt x) -> returnE $ ES.Lit (ES.LInt $ toInteger x)
  Lit _ (LFloat x) -> returnE $ ES.Lit (ES.LFloat $ float2Double x)
  Lit _ (LBool x) -> returnE $
    case x of
      True  -> trueAtom
      False -> falseAtom
  Var _ name -> returnE $ ES.Var $ T.unpack (capitalize name)
  Global _ name -> do
    amap <- gets arities
    let arity = amap M.! name
    returnE $ -- take special care when type is TClosure
      ES.Fun $ ES.Function ((ES.Atom $ T.unpack name), arity)
  Let _ name ebound ein -> do
    ebound' <- codegenExpr ebound
    ein'    <- codegenExpr ein
    let var = T.unpack $ capitalize name
    returnE $ ES.Let ([var], ebound') ein'
  If _ cond th els -> do
    th'   <- codegenExpr th
    els'  <- codegenExpr els
    cond' <- codegenExpr cond
    let trueGuard  = ES.Guard cond'
    let falseGuard = ES.Guard (expToExps trueAtom) -- using true atom to emulate else in erlang
    returnE $
      ES.Case
        (ES.Exps (ES.Constr []))
           [ ES.Constr (ES.Alt (ES.Pats []) trueGuard  th')
           , ES.Constr (ES.Alt (ES.Pats []) falseGuard els')
           ]
  -- Effectful combinators---
  Call _ (PrimOp _ ReadIntStream) _ ->
    returnE $ ES.ModCall
      ( expToExps (ES.Lit (ES.LAtom (ES.Atom "ioutils")))
      , expToExps (ES.Lit (ES.LAtom (ES.Atom "readintstream"))))
      []
  Call _ (PrimOp _ WriteIntStream) args -> do
    args' <- mapM codegenExpr args
    returnE $ ES.ModCall
      ( expToExps (ES.Lit (ES.LAtom (ES.Atom "ioutils")))
      , expToExps (ES.Lit (ES.LAtom (ES.Atom "writeintstream"))))
      args'
  Call _ (PrimOp _ ReadBoolStream) _ ->
    returnE $ ES.ModCall
      ( expToExps (ES.Lit (ES.LAtom (ES.Atom "ioutils")))
      , expToExps (ES.Lit (ES.LAtom (ES.Atom "readboolstream"))))
      []
  Call _ (PrimOp _ WriteBoolStream) args -> do
    args' <- mapM codegenExpr args
    returnE $ ES.ModCall
      ( expToExps (ES.Lit (ES.LAtom (ES.Atom "ioutils")))
      , expToExps (ES.Lit (ES.LAtom (ES.Atom "writeboolstream"))))
      args'

  Call _ (PrimOp _ ReadColor) args -> do
    args' <- mapM codegenExpr args
    returnE $ ES.ModCall
      ( expToExps (ES.Lit (ES.LAtom (ES.Atom "ioutils")))
      , expToExps (ES.Lit (ES.LAtom (ES.Atom "readcolor"))))
      args'
  Call _ (PrimOp _ WriteColor) args -> do
    args' <- mapM codegenExpr args
    returnE $ ES.ModCall
      ( expToExps (ES.Lit (ES.LAtom (ES.Atom "ioutils")))
      , expToExps (ES.Lit (ES.LAtom (ES.Atom "writecolor"))))
      args'

  Call _ (PrimOp _ (Rate time)) expr -> do
    t  <- codegenExpr time
    let t' = resolveTime t
    expr' <- mapM codegenExpr expr
    let e1 = expToExps $ ES.ModCall ( expToExps (ES.Lit (ES.LAtom (ES.Atom "timer")))
                                    , expToExps (ES.Lit (ES.LAtom (ES.Atom "sleep")))) [t']
    let e2 = fromMaybe (panic "Arg guaranteed to be non-empty") $ head expr'
    returnE $ ES.Seq e1 e2

  Call _ (PrimOp _ Equal) args -> do
    args' <- mapM codegenExpr args
    returnE $ ES.ModCall (genbinop Equal) args'

  Call _ (PrimOp _ Add) args -> do
    args' <- mapM codegenExpr args
    returnE $ ES.ModCall (genbinop Add) args'

  Call _ (PrimOp _ Sub) args -> do
    args' <- mapM codegenExpr args
    returnE $ ES.ModCall (genbinop Sub) args'

  Call _ (PrimOp _ Mul) args -> do
    args' <- mapM codegenExpr args
    returnE $ ES.ModCall (genbinop Mul) args'

  Call _ (PrimOp _ DivF) args -> do
    args' <- mapM codegenExpr args
    returnE $ ES.ModCall (genbinop DivF) args'

  Call _ (PrimOp _ AddF) args -> do
    args' <- mapM codegenExpr args
    returnE $ ES.ModCall (genbinop AddF) args'

  Call _ (PrimOp _ SubF) args -> do
    args' <- mapM codegenExpr args
    returnE $ ES.ModCall (genbinop SubF) args'

  Call _ (PrimOp _ MulF) args -> do
    args' <- mapM codegenExpr args
    returnE $ ES.ModCall (genbinop MulF) args'

  Call _ (PrimOp _ HGT) args -> do
    args' <- mapM codegenExpr args
    returnE $ ES.ModCall (genbinop HGT) args'

  Call _ (PrimOp _ HLT) args -> do
    args' <- mapM codegenExpr args
    returnE $ ES.ModCall (genbinop HLT) args'

  Call _ (PrimOp _ HGE) args -> do
    args' <- mapM codegenExpr args
    returnE $ ES.ModCall (genbinop HGE) args'

  Call _ (PrimOp _ HLE) args -> do
    args' <- mapM codegenExpr args
    returnE $ ES.ModCall (genbinop HLE) args'

---------------------------
  Call ty f args -> do
    f'    <- codegenExpr f
    args' <- mapM codegenExpr args
    varName <- fresh
    returnE $
      ES.Let
      ([varName], f')
      (expToExps (ES.App (expToExps (ES.Var varName)) args'))

  Closure ty name clTy env -> do
    amap     <- gets arities
    let arity = amap M.! name
    if (not (null env))
    then do
      -- See NOTE 4 to understand the logic here
      let exp = Closure ty name clTy []
      c <- gets closures
      let (_,args,_,_) = c M.! name
      let args' = argsToL1Vars args
      e <- codegenExpr (Call ty exp (env ++ args'))
      let vars = map (T.unpack . capitalize . fst) args
      returnE $ ES.Lambda vars e
    else returnE $
           (ES.Fun
             (ES.Function (ES.Atom (T.unpack name), arity)))
  Pair _ exp1 exp2 -> do
    e1 <- codegenExpr exp1
    e2 <- codegenExpr exp2
    returnE $ ES.Tuple [ e1, e2]
  PrimOp _ pop ->
    case pop of
      Fst ->
        returnE $
          (ES.Fun (ES.Function (ES.Atom "fst#",1)))
      Snd ->
        returnE $
          (ES.Fun (ES.Function (ES.Atom "snd#",1)))
      Get name initState -> do -- See NOTE 3 for `get` and `set`
        init <- codegenExpr initState
        varName <- fresh
        returnE $
          (ES.Case
           (expToExps
            (ES.ModCall (expToExps (ES.Lit (ES.LAtom (ES.Atom "erlang")))
                        ,(expToExps (ES.Lit (ES.LAtom (ES.Atom "get")))))
              [expToExps (ES.Lit (ES.LAtom (ES.Atom (T.unpack name))))]))
           [ES.Constr
            (ES.Alt
             (ES.Pats [ES.PLit (ES.LAtom (ES.Atom "undefined"))])
             (ES.Guard (expToExps trueAtom))
             init)
           ,ES.Constr
            (ES.Alt
             (ES.Pats [ES.PVar varName])
             (ES.Guard (expToExps trueAtom))
             (expToExps (ES.Var varName)))
           ])
      Put name newState -> do
        newS <- codegenExpr newState
        returnE $
          (ES.ModCall
           ( expToExps (ES.Lit (ES.LAtom (ES.Atom "erlang")))
           , expToExps (ES.Lit (ES.LAtom (ES.Atom "put"))))
           [ expToExps (ES.Lit (ES.LAtom (ES.Atom (T.unpack name))))
           , newS
           ])
      _ -> panic "Primop not implemented"
  where
    returnE = return . expToExps
    argsToL1Vars = map (\(name,ty) -> Var ty name)
    safeHead x = panic "Arg guaranteed to be non-empty" $ head x


{-
NOTE : Abandoned logic, we now do sequencing through
the *** combinator but something tells me that we
might need to revisit the logic here
Sequencing
---------
The Call constructor is handled separately because
it is the agent to bring about sequencing. When we
are dealing with void types there is absolutely no
way to represent effects in pure lambda calculus
(unless you have higher kinded types and as a result
 monads). Here Call constructor is sufficient to deal
with the void type. When we encounter expressions like

`writeIntStream :>>>: readIntStream`
which compiles to
λt.(λz . (Call ris# []) (Call (λm . Call wis# [m]) t))
where t : Int

The above cannot be partially evaluated because t : Int
so it simply returns a function. Also notice the call
(Call (λm . Call wis# [m]) t) returns a type void which is
then fed to the readIntStream#.

Attempt1:
We detect all Call constructors which return Void types
and use the Erlang `Seq` constructor to sequence them.
This approach seems to work for simple examples

-}
-- callSeq :: Expr -> Codegen ES.Exps
-- callSeq (Call ty f args) =
--   if (length args == 1 && -- && is short circuiting
--        (case headOfArgs of
--            Call TVoid _ _ -> True
--            _ -> False
--        )
--      )
--   then do
--     arr1 <- codegenExpr $ headOfArgs
--     arr2 <- codegenExpr $ Call ty f []
--     returnE $ ES.Seq arr1 arr2
--   else do
--     f'    <- codegenExpr f
--     args' <- mapM codegenExpr args
--     varName <- fresh
--     returnE $
--       ES.Let
--       ([varName], f')
--       (expToExps (ES.App (expToExps (ES.Var varName)) args'))
--     where
--       returnE = return . expToExps
--       uselessPanic = panic "Couldn't extract head of args"
--       headOfArgs = fromMaybe uselessPanic $ head args
-- callSeq _ = panic "callSeq called on non - Call constructor"

genbinop :: PrimOp -> (ES.Exps, ES.Exps)
genbinop = \case
  Add  -> ( expToExps (ES.Lit (ES.LAtom (ES.Atom "erlang")))
          , expToExps (ES.Lit (ES.LAtom (ES.Atom "+"))))
  AddF -> ( expToExps (ES.Lit (ES.LAtom (ES.Atom "erlang")))
          , expToExps (ES.Lit (ES.LAtom (ES.Atom "+"))))
  Sub  -> ( expToExps (ES.Lit (ES.LAtom (ES.Atom "erlang")))
          , expToExps (ES.Lit (ES.LAtom (ES.Atom "-"))))
  SubF -> ( expToExps (ES.Lit (ES.LAtom (ES.Atom "erlang")))
          , expToExps (ES.Lit (ES.LAtom (ES.Atom "-"))))
  Mul  -> ( expToExps (ES.Lit (ES.LAtom (ES.Atom "erlang")))
          , expToExps (ES.Lit (ES.LAtom (ES.Atom "*"))))
  MulF -> ( expToExps (ES.Lit (ES.LAtom (ES.Atom "erlang")))
          , expToExps (ES.Lit (ES.LAtom (ES.Atom "*"))))
  DivF -> ( expToExps (ES.Lit (ES.LAtom (ES.Atom "erlang")))
          , expToExps (ES.Lit (ES.LAtom (ES.Atom "/"))))
  Equal -> ( expToExps (ES.Lit (ES.LAtom (ES.Atom "erlang")))
           , expToExps (ES.Lit (ES.LAtom (ES.Atom "=:="))))
-- NOTE: Although untyped, `=:=` at least prevents unwanted casting

  HGT  -> ( expToExps (ES.Lit (ES.LAtom (ES.Atom "erlang")))
          , expToExps (ES.Lit (ES.LAtom (ES.Atom ">"))))
  HLT  -> ( expToExps (ES.Lit (ES.LAtom (ES.Atom "erlang")))
          , expToExps (ES.Lit (ES.LAtom (ES.Atom "<"))))
  HGE  -> ( expToExps (ES.Lit (ES.LAtom (ES.Atom "erlang")))
          , expToExps (ES.Lit (ES.LAtom (ES.Atom ">="))))
  HLE  -> ( expToExps (ES.Lit (ES.LAtom (ES.Atom "erlang")))
          , expToExps (ES.Lit (ES.LAtom (ES.Atom "=<"))))
  _ -> panic "Wrong call to binary op"


genmain :: L1.Expr -> L1.Type -> CodegenState -> ES.FunDef
genmain mainExpr mainTy cgState =
  let
    mainFunc =
      case mainTy of
        TClosure [] x ->
          if isAllVoid x  -- checks for SF () (), SF () ((), ()), SF ((), ()) ((), ()) etc
          then do
            mainE'  <- codegenExpr mainExpr
            recursiveVar <- fresh
            throwAwayVar <- fresh
            return $
              expToExps
                (ES.LetRec
                 [ES.FunDef
                  (ES.Constr (ES.Function (ES.Atom recursiveVar,0)))
                  (ES.Constr
                   (ES.Lambda []
                    (expToExps
                     (ES.Let
                      ([recursiveVar],
                       expToExps (ES.Fun (ES.Function (ES.Atom recursiveVar,0))))
                      (expToExps
                       (ES.Let
                        ([throwAwayVar], mainE')
                        (expToExps (ES.App (expToExps (ES.Var recursiveVar)) []))
                       )
                      )
                     )
                    )
                   )
                  )
                 ]
                 (expToExps
                  (ES.App
                   (expToExps (ES.Fun (ES.Function (ES.Atom recursiveVar,0))))
                   []
                  )
                 )
                )
          else codegenExpr mainExpr


        _ -> codegenExpr mainExpr
    main' = evalState
            (runCodegen mainFunc)
            (cgState {callingFuncName = "main"})
  in ES.FunDef
     (ES.Constr (ES.Function (ES.Atom "main", 0)))
     (ES.Constr (ES.Lambda [] main'))


expToExps :: ES.Exp -> ES.Exps
expToExps e = ES.Exp (ES.Constr e)

-- XXX: We currently take a time `t` in seconds
-- and simply do sleep(erlang:trunc(t*1000))
-- Please fix precision
resolveTime :: ES.Exps -> ES.Exps
resolveTime t =
  let msec = expToExps $
              ES.ModCall (genbinop Mul) [ t
                                        , expToExps (ES.Lit (ES.LInt 1000))]
   in expToExps $ ES.ModCall trunc [msec]
      where
        trunc = ( expToExps (ES.Lit (ES.LAtom (ES.Atom "erlang")))
                , expToExps (ES.Lit (ES.LAtom (ES.Atom "trunc"))))

-- generate freshVariable name
fresh :: Codegen String
fresh = do
  i <- gets count
  modify $ \s -> s {count = 1 + i}
  return $ "_" <> (show i)


trueAtom, falseAtom :: ES.Exp
trueAtom = ES.Lit (ES.LAtom (ES.Atom "true"))
falseAtom = ES.Lit (ES.LAtom (ES.Atom "false"))

genExports :: ArityMap -> [Global] -> [ES.Function]
genExports amap gs = genExports' amap gs []
  where
    genExports' _ [] xs =
      let mainFunc = ES.Function (ES.Atom "main", 0)
      in mainFunc : reverse xs
    genExports' am ((DefFunction name _ _ _):gs') xs
      | "liftedFunc" `T.isPrefixOf` name = genExports' am gs' xs
      | otherwise =
          let arity = amap M.! name
              f     = ES.Function (ES.Atom (T.unpack name), arity)
           in genExports' am gs' (f:xs)
    genExports' am (_:gs') xs = genExports' am gs' xs


-- first and second projections

{-

Being dynamic the first and second projection function operate
for any kind of data so it would be fine to keep them as
static function declared for all modules
-}
firstProjection =
  ES.FunDef (ES.Constr (ES.Function (ES.Atom "fst#",1))) (ES.Constr (ES.Lambda ["_0"] (ES.Exp (ES.Constr (ES.Case (ES.Exp (ES.Constr (ES.Var "_0"))) [ES.Constr (ES.Alt (ES.Pats [ES.PTuple [ES.PVar "X",ES.PVar "_2"]]) (ES.Guard (ES.Exp (ES.Constr (ES.Lit (ES.LAtom (ES.Atom "true")))))) (ES.Exp (ES.Constr (ES.Var "X")))),ES.Ann (ES.Alt (ES.Pats [ES.PVar "_1"]) (ES.Guard (ES.Exp (ES.Constr (ES.Lit (ES.LAtom (ES.Atom "true")))))) (ES.Exp (ES.Ann (ES.Op (ES.Atom "match_fail") [ES.Exp (ES.Constr (ES.Tuple [ES.Exp (ES.Constr (ES.Lit (ES.LAtom (ES.Atom "function_clause")))),ES.Exp (ES.Constr (ES.Var "_1"))]))]) [ES.CTuple [ES.CLit (ES.LAtom (ES.Atom "function_name")),ES.CTuple [ES.CLit (ES.LAtom (ES.Atom "fst#")),ES.CLit (ES.LInt 1)]]]))) [ES.CLit (ES.LAtom (ES.Atom "compiler_generated"))]])))))

secondProjection =
  ES.FunDef (ES.Constr (ES.Function (ES.Atom "snd#",1))) (ES.Constr (ES.Lambda ["_0"] (ES.Exp (ES.Constr (ES.Case (ES.Exp (ES.Constr (ES.Var "_0"))) [ES.Constr (ES.Alt (ES.Pats [ES.PTuple [ES.PVar "_2",ES.PVar "X"]]) (ES.Guard (ES.Exp (ES.Constr (ES.Lit (ES.LAtom (ES.Atom "true")))))) (ES.Exp (ES.Constr (ES.Var "X")))),ES.Ann (ES.Alt (ES.Pats [ES.PVar "_1"]) (ES.Guard (ES.Exp (ES.Constr (ES.Lit (ES.LAtom (ES.Atom "true")))))) (ES.Exp (ES.Ann (ES.Op (ES.Atom "match_fail") [ES.Exp (ES.Constr (ES.Tuple [ES.Exp (ES.Constr (ES.Lit (ES.LAtom (ES.Atom "function_clause")))),ES.Exp (ES.Constr (ES.Var "_1"))]))]) [ES.CTuple [ES.CLit (ES.LAtom (ES.Atom "function_name")),ES.CTuple [ES.CLit (ES.LAtom (ES.Atom "snd#")),ES.CLit (ES.LInt 1)]]]))) [ES.CLit (ES.LAtom (ES.Atom "compiler_generated"))]])))))


type ArityMap = M.Map Name Integer

genArityMap :: Program -> ArityMap
genArityMap Program {programGlobals = pgs, ..} =
  M.fromList $ map nameToArity $ filter (not . isPair) pgs
  where
    nameToArity (DefFunction name args _ _) =
      (name, toInteger $ length args)
    nameToArity (DefClosure name env args _ _) =
      (name, toInteger $ length (env ++ args))
    nameToArity (DefPair _ _ _ _) =
      panic "[L2.Erlang. Interpreter] Pairs already filtered out"


isPair :: Global -> Bool
isPair (DefFunction _ _ _ _)  = False
isPair (DefClosure _ _ _ _ _) = False
isPair (DefPair _ _ _ _)      = True

isFunc :: Global -> Bool
isFunc (DefFunction _ _ _ _)  = True
isFunc (DefClosure _ _ _ _ _) = False
isFunc (DefPair _ _ _ _)      = False


capitalize :: Text -> Text
capitalize t
  | T.null t = t
  | otherwise =
    T.cons c (T.tail t)
    where
      c = C.toUpper $ T.head t

compilergennonsense =
  [(ES.Atom "file",ES.CList (ES.L [ES.CTuple [ES.CList (ES.LL [ES.CLit (ES.LInt 116)] (ES.CList (ES.LL [ES.CLit (ES.LInt 101)] (ES.CList (ES.LL [ES.CLit (ES.LInt 115)] (ES.CList (ES.LL [ES.CLit (ES.LInt 116)] (ES.CList (ES.LL [ES.CLit (ES.LInt 46)] (ES.CList (ES.LL [ES.CLit (ES.LInt 101)] (ES.CList (ES.LL [ES.CLit (ES.LInt 114)] (ES.CList (ES.L [ES.CLit (ES.LInt 108)]))))))))))))))),ES.CLit (ES.LInt 1)]]))]

------------------------------------------
-- | GRiSP codegen

grispfuns =
  [
  ES.FunDef (ES.Constr (ES.Function (ES.Atom "start",2))) (ES.Constr (ES.Lambda ["_0","_1"] (ES.Exp (ES.Constr (ES.Case (ES.Exp (ES.Constr (ES.ModCall (ES.Exp (ES.Constr (ES.Lit (ES.LAtom (ES.Atom "robot_sup")))),ES.Exp (ES.Constr (ES.Lit (ES.LAtom (ES.Atom "start_link"))))) []))) [ES.Constr (ES.Alt (ES.Pats [ES.PAlias (ES.Alias "_@r0" (ES.PTuple [ES.PLit (ES.LAtom (ES.Atom "ok")),ES.PVar "Supervisor"]))]) (ES.Guard (ES.Exp (ES.Constr (ES.Lit (ES.LAtom (ES.Atom "true")))))) (ES.Exp (ES.Constr (ES.Seq (ES.Exp (ES.Constr (ES.App (ES.Exp (ES.Constr (ES.Fun (ES.Function (ES.Atom "main",0))))) []))) (ES.Exp (ES.Constr (ES.Var "_@r0"))))))),ES.Ann (ES.Alt (ES.Pats [ES.PVar "_2"]) (ES.Guard (ES.Exp (ES.Constr (ES.Lit (ES.LAtom (ES.Atom "true")))))) (ES.Exp (ES.Constr (ES.Op (ES.Atom "match_fail") [ES.Exp (ES.Constr (ES.Tuple [ES.Exp (ES.Constr (ES.Lit (ES.LAtom (ES.Atom "badmatch")))),ES.Exp (ES.Constr (ES.Var "_2"))]))])))) [ES.CLit (ES.LAtom (ES.Atom "compiler_generated"))]]))))),
  ES.FunDef (ES.Constr (ES.Function (ES.Atom "stop",1))) (ES.Constr (ES.Lambda ["_0"] (ES.Exp (ES.Constr (ES.Lit (ES.LAtom (ES.Atom "ok")))))))
  ]



grispcompilergen =
  [(ES.Atom "file",ES.CList (ES.L [ES.CTuple [ES.CList (ES.LL [ES.CLit (ES.LInt 114)] (ES.CList (ES.LL [ES.CLit (ES.LInt 111)] (ES.CList (ES.LL [ES.CLit (ES.LInt 98)] (ES.CList (ES.LL [ES.CLit (ES.LInt 111)] (ES.CList (ES.LL [ES.CLit (ES.LInt 116)] (ES.CList (ES.LL [ES.CLit (ES.LInt 46)] (ES.CList (ES.LL [ES.CLit (ES.LInt 101)] (ES.CList (ES.LL [ES.CLit (ES.LInt 114)] (ES.CList (ES.L [ES.CLit (ES.LInt 108)]))))))))))))))))),ES.CLit (ES.LInt 1)]])),(ES.Atom "behavior",ES.CList (ES.L [ES.CLit (ES.LAtom (ES.Atom "application"))]))]
-------------------------------------------

loc = "/Users/abhiroopsarkar/Haskell/hailstorm/src/L2/Erlang/examples/test.core"

foo :: IO (ES.Ann ES.Module)
foo = do
  x <- readFile loc
  let foo = EP.parseModule $ T.unpack x
  case foo of
    Right p -> return p
    Left _ -> panic "Just experimenting"

bar = do
  x <- foo
  putStrLn $ EPR.prettyPrint x


-- NOTE 1
{-
In Erlang Core for function application of the form
`App f args` it seems if `f` is a complex expression
involving lets etc it should be represented as:
let Z = f %% some complex expression
 in App Z args

However the `args` can be arbitrarily complex and no
need to let bind them. Learnt this plainly through
playing around with the core, due to which this variable
naming business exists here.
-}

-- NOTE 2
{-
When the return type of the main function is SF _ () ()
this indicates an infinite signal. So imagine normally
for an effectful function main would compile to the
following Erlang core:
'main'/0 =
    fun () -> apply 'z'/0 ()

where `z` is an effectful function. However we want to
recursively keep calling this function to emulate an
infinite signal. We transform the above to the following:

'main'/0 =
  fun () ->
   letrec 'F'/0 = %% the 'F' is called as recursiveVar
        (fun () ->
           let <F> = 'F'/0
            in let <_1> = apply 'z'/0 () %% <_1> is the
                in apply F ()            %% throwAwayVar
        )
    in  apply 'F'/0 ()

'F' is a recursive binding which is repeatedly called
to make the signal infinite.


-}

-- NOTE 3
{-

Code generation for `get`

case get(state) of
  undefined -> 0;
  C -> C
end

compiled to the erlang core
case %% Line 73
  call 'erlang':'get'
  ('state') of
       %% Line 74
       <'undefined'> when 'true' ->
              0
       %% Line 75
       <C> when 'true' ->
              C
end


Code generation for `set`

call 'erlang':'put' ('state', NewState)
-}

-- NOTE 4
{-
This situation occurs under 3 circumstances

1. def foo (x:Int) : Int -> Int = someFunc x

`someFunc x` is a partial application and already
translated to a DefClosure. We check the environment
if there is any variable to apply like `x` in this
and then bring the args from DefClosure combine them
to create a full function application. We finally
return a lambda (thats what the return type says) where
the variables are the ones pulled from DefClosure

2. def foo (x:Int) : SF _ Int Int = ...

Same as 1

3. def foo : Int =
     let x = 5 in
     \(z:Int) => x + z

Here we have a free variable so it enters the then block,
code is generated with one extra let. This case however
is never hit if the inline successfully resolves the let.

-}

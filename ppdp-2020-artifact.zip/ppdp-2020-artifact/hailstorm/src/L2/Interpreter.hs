{-# LANGUAGE OverloadedStrings #-}

module L2.Interpreter
  ( l1Tol2
  , mangle
  ) where

import Control.Exception (assert)
import Data.List (zip3)
import Data.Maybe (fromMaybe)
import qualified Debug.Trace as DT
import Protolude hiding (Type, local, one, void, zero)

import L1.L1 as L1
import L2.Codegen
import qualified LLVM.AST as LLVM
import qualified LLVM.AST.Constant as LC
import qualified LLVM.AST.IntegerPredicate as IP
import qualified LLVM.AST.Name as LN
import qualified LLVM.AST.Operand as LOP
import qualified LLVM.AST.ParameterAttribute as PA
import LLVM.AST.Type

import qualified Debug.Trace as DT

l1Tol2 :: L1.Program -> LLVM.Module
l1Tol2 prog = runLLVM initModule (codegenProg prog)
  where
    initModule = emptyModule "Hailstorm-LLVM Module"

llvmType :: L1.Type -> LLVM.Type
llvmType TVoid = VoidType
llvmType TInt = int
llvmType TBool = ibool
llvmType TFloat = FloatingPointType FloatFP
llvmType (TFunction args retty) = ptr $ fn (llvmType retty) (map llvmType args)
llvmType (TClosure args retty) = closure (llvmType retty) (map llvmType args)
llvmType (TSeq _) = VoidType
llvmType t@(TPair _ _) =
  ptr $ NamedTypeReference (mkLLVMName $ getNameFromType t)

-- | Mangle names to avoid collisions with library functions.
mangle :: (IsString a, Semigroup a) => a -> a
mangle = ("hailstorm_" <>)

codegenExpr :: Expr -> Codegen LLVM.Operand
codegenExpr expr =
  case expr of
    Lit TInt (LInt x) -> pure $! cint (fromIntegral x)
    Lit TBool (LBool x) ->
      pure $!
      if x
        then true
        else false
    Var _ x -> getvar x
    Global ty x ->
        pure $! cons $ global (llvmType ty) (LLVM.Name . toS $ mangle x)
    Let _ name ebound ein -> do
      ebound' <- codegenExpr ebound
      scope $ do
        assign name ebound'
        codegenExpr ein
    If ty cond then_ else_ -> do
      ifthen <- addBlock "if.then"
      ifelse <- addBlock "if.else"
      ifexit <- addBlock "if.exit"
    -- %entry
    ---------
      cond' <- codegenExpr cond
      cbr cond' ifthen ifelse
    -- if.then
    ----------
      setBlock ifthen
      then' <- codegenExpr then_
      br ifexit
      ifthen' <- getBlock
    -- if.else
    ----------
      setBlock ifelse
      else' <- codegenExpr else_
      br ifexit
      ifelse' <- getBlock
    -- if.exit
    ----------
      setBlock ifexit
      phi (llvmType ty) [(then', ifthen'), (else', ifelse')]
    -- BinaryOp TInt Add a b -> join $! add <$> codegenExpr a <*> codegenExpr b
    -- BinaryOp TInt Sub a b -> join $! sub <$> codegenExpr a <*> codegenExpr b
    -- BinaryOp TInt Mul a b -> join $! mul <$> codegenExpr a <*> codegenExpr b
    -- BinaryOp TBool Eql a b ->
    --   join $! icmp IP.EQ <$> codegenExpr a <*> codegenExpr b
    PrimOp ty NewSeqInt ->
      return $!
      LOP.ConstantOperand
        (LC.GlobalReference
           (FunctionType
              VoidType
              [ ptr $ NamedTypeReference "struct.sequence"
              , i64
              , i32
              , i64
              , anyPtr
              ]
              False)
           "new")
    PrimOp ty GetSeqInt ->
      return $!
      LOP.ConstantOperand
        (LC.GlobalReference
           (FunctionType
              (StructureType False [i64, anyPtr])
              [ptr $ NamedTypeReference "struct.sequence", i32]
              False)
           "get")
    PrimOp ty SetSeqInt ->
      return $!
      LOP.ConstantOperand
        (LC.GlobalReference
           (FunctionType
              VoidType
              [ ptr $ NamedTypeReference "struct.sequence"
              , i64
              , ptr $ NamedTypeReference "struct.sequence"
              , i32
              , i64
              , anyPtr
              ]
              False)
           "set")
    PrimOp ty NewSeqBool ->
      return $!
      LOP.ConstantOperand
        (LC.GlobalReference
           (FunctionType
              VoidType
              [ ptr $ NamedTypeReference "struct.sequence"
              , i64
              , i32
              , i64
              , anyPtr
              ]
              False)
           "new")
    PrimOp ty GetSeqBool ->
      return $!
      LOP.ConstantOperand
        (LC.GlobalReference
           (FunctionType
              (StructureType False [i64, anyPtr])
              [ptr $ NamedTypeReference "struct.sequence", i32]
              False)
           "get")
    PrimOp ty SetSeqBool ->
      return $!
      LOP.ConstantOperand
        (LC.GlobalReference
           (FunctionType
              VoidType
              [ ptr $ NamedTypeReference "struct.sequence"
              , i64
              , ptr $ NamedTypeReference "struct.sequence"
              , i32
              , i64
              , anyPtr
              ]
              False)
           "set")
    PrimOp primty Fst ->
      case primty of
        TFunction {} ->
          let errorMsg = (panic $! "argument list has no elements")
              pairTy = fromMaybe errorMsg (head $ argTypes primty)
              name = mkLLVMName $ (getNameFromType pairTy) <> "_fst"
              ty =
                FunctionType
                  (llvmType $ returnType primty)
                  (map llvmType $ argTypes primty)
                  False
              fFst = LOP.ConstantOperand (LC.GlobalReference ty name)
           in return fFst
        _ -> panic $! "Invalid primop type : " <> (show primty)
    PrimOp primty Snd ->
      case primty of
        TFunction {} ->
          let errorMsg = (panic $! "argument list has no elements")
              pairTy = fromMaybe errorMsg (head $ argTypes primty)
              name = mkLLVMName $ (getNameFromType pairTy) <> "_snd"
              ty =
                FunctionType
                  (llvmType $ returnType primty)
                  (map llvmType $ argTypes primty)
                  False
              fSnd = LOP.ConstantOperand (LC.GlobalReference ty name)
           in return fSnd
        _ -> panic $! "Invalid primop type : " <> (show primty)

    Call _ (PrimOp _ ReadIntStream) _ -> do
      r1 <- call i32
            (LOP.ConstantOperand
              (LC.GlobalReference
                (FunctionType i32 [] False)
                (mkLLVMName "readIntStream")))
            []
      return r1

    Call ty (PrimOp _ WriteIntStream) args ->
      case ty of
        TVoid -> do
          args' <- traverse codegenExpr args
          let f' = (LOP.ConstantOperand
                          (LC.GlobalReference
                             (FunctionType void [i32] False)
                             (mkLLVMName "writeIntStream")))
          call_ f' args'
          return $ LLVM.ConstantOperand (LC.Null void)
        _ -> panic "Calling write operation without \
                   \having a return type of void"

    Call ty f args ->  do
      let fty = exprType f
      assertM $ argTypes fty == map exprType args
      assertM $ returnType fty == ty
      let ty' = llvmType ty
      f' <- codegenExpr f
      args' <- traverse codegenExpr args
      case fty of
        TFunction _ _ ->
          case f of
            PrimOp _ NewSeqInt -> do
              let (cap:val:_) = args'
              r1 <- inttoptr anyPtr val
              r2 <- alignedAlloca (NamedTypeReference "struct.sequence") 8
              call_ f' [ptrToLocal r2, four64, cap, four64, r1]
              return r2
            PrimOp _ GetSeqInt -> do
              let (s:idx:_) = args'
              r1 <- call elemStruct f' [ptrToLocal s, idx]
              r2 <- extractValue anyPtr r1 [1]
              ptrtoint i32 r2
            PrimOp _ SetSeqInt -> do
              let (s:idx:toSet:_) = args'
              r1 <- alignedAlloca (NamedTypeReference "struct.sequence") 8
              r2 <- inttoptr anyPtr toSet
              call_ f' [ptrToLocal r1, four64, ptrToLocal s, idx, four64, r2]
              return r1
            PrimOp _ NewSeqBool -> do
              let (cap:val:_) = args'
              r1 <- inttoptr anyPtr val
              r2 <- alignedAlloca (NamedTypeReference "struct.sequence") 8
              call_ f' [ptrToLocal r2, one64, cap, one64, r1]
              return r2
            PrimOp _ GetSeqBool -> do
              let (s:idx:_) = args'
              r1 <- call elemStruct f' [ptrToLocal s, idx]
              r2 <- extractValue anyPtr r1 [1]
              ptrtoint i1 r2
            PrimOp _ SetSeqBool -> do
              let (s:idx:toSet:_) = args'
              r1 <- alignedAlloca (NamedTypeReference "struct.sequence") 8
              r2 <- inttoptr anyPtr toSet
              call_ f' [ptrToLocal r1, one64, ptrToLocal s, idx, one64, r2]
              return r1
            -- we don't need to handle the first and second pair operations separately
            -- we don't need to handle readIntStream and writeIntStream as well
            _ -> call ty' f' args'
        TClosure argtys _ -> do
          let fty' = fn ty' (anyPtr : map llvmType argtys) -- anyPtr here is the type of the environment i.e (void*)
        {-

         typedef struct {
             int (*funptr)(void *, int); -- [0] is the function pointer
             void *envptr;               -- [1] is the environment pointer
         } closure;

        -}
          fptr <- extractValue (ptr fty') f' [0]
          envptr <- extractValue anyPtr f' [1]
          -- below takes care when we encounter
          -- Call TVoid (Closure ...) [...]
          -- Used for evaluating effects
          if (ty == TVoid)
          then do
            call_ fptr (envptr : args')
            return $ LLVM.ConstantOperand (LC.Null void)
          else call ty' fptr (envptr : args') -- add the environment pointer as the first argument to denote the free variables
        _ -> panic $ "Attempt to call non-callable: " <> show fty
    Closure (TClosure argtys retty) name _ env -> do
      envptr' <-
        if null env
          then pure $! nullP anyPtr
          else do
            let envtys' = map (llvmType . exprType) env
            env' <- traverse codegenExpr env
            (anyptr, envptr) <- malloc (closureEnv envtys')
            forM_ (zip3 [0 ..] envtys' env') $ \(i, ty, v) -> do
              p <- getElementPtr (ptr ty) envptr [cint32 0, cint32 i]
              store p v
            pure $! anyptr
      let retty' = llvmType retty
          argtys' = map llvmType argtys
          closurety = closure retty' argtys'
          funty = fn retty' (anyPtr : argtys') -- once again add the (void*) in front of all the other arguments
          name' = LLVM.Name $ toS name
      buildStruct closurety [cons $ global (ptr funty) name', envptr']
    Pair (TPair ty1 ty2) expr1 expr2 -> do
      e1 <- codegenExpr expr1
      e2 <- codegenExpr expr2
      let name = getNameFromType (TPair ty1 ty2)
      let fstTy = llvmType ty1
      let sndTy = llvmType ty2
      let tupleType =
            FunctionType (llvmType (TPair ty1 ty2)) [fstTy, sndTy] False
      let mkPairFunc =
            LOP.ConstantOperand
              (LC.GlobalReference tupleType (mkLLVMName $ "mk" <> name))
      call (ptr $ NamedTypeReference (mkLLVMName name)) mkPairFunc [e1, e2]
    _ -> panic $! "Invalid expression : " <> (show expr)

-- | transform a global binding to LLVM
--
-- adds global definitons to the LLVM module
codegenGlobal :: Global -> LLVM ()
codegenGlobal (DefFunction name args retty body) = do
  let args' = map (swap . first (LLVM.Name . toS) . second llvmType) args
      retty' = llvmType retty
  internal retty' (toS $ mangle name) args' $ codegenBody args' body
codegenGlobal (DefClosure name env args retty body) = do
  let env' = map (swap . first (LLVM.Name . toS) . second llvmType) env
      args' = map (swap . first (LLVM.Name . toS) . second llvmType) args
      retty' = llvmType retty
      envname = "__env"
      envarg = (anyPtr, envname)
  internal retty' (toS name) (envarg : args') $
    -- extract closure environment
   do
    unless (null env) $ do
      envptr <- getClosureEnvPtr envname (map fst env')
      forM_ (zip [0 ..] env') $ \(i, (ty, LLVM.Name n)) -> do
        p <- getElementPtr (ptr ty) envptr [cint32 0, cint32 i]
        v <- load ty p
        assign (toS n) v
    codegenBody args' body
codegenGlobal (DefPair pairName (TPair ty1 ty2) fstName sndName) = do
  let tupleName = mkLLVMName pairName
  let (first, second) = (llvmType ty1, llvmType ty2)
  let args = [first, second]
  let argType =
        map (\(x, y) -> (x, mkLLVMName $ "__arg" <> (show y))) $ zip args [0 ..]
  let tupleType = NamedTypeReference tupleName
  let ptrToTuple = ptr tupleType
  structTypeDefn tupleName False args
  internal ptrToTuple ("mk" <> pairName) argType $ do
    r0 <- alloca1 first (ptr first)
    r1 <- alloca1 second (ptr second)
    r2 <- alloca1 ptrToTuple (ptr ptrToTuple)
    store r0 (LOP.LocalReference first (mkLLVMName "__arg0"))
    store r1 (LOP.LocalReference second (mkLLVMName "__arg1"))
    (_, r6) <- malloc tupleType
    store r2 r6
    r7 <- load first r0
    r8 <- load ptrToTuple r2
    r9 <- getElementPtrInb (ptr first) r8 [cint32 0, cint32 0]
    store r9 r7
    r10 <- load second r1
    r11 <- load ptrToTuple r2
    r12 <- getElementPtrInb (ptr second) r8 [cint32 0, cint32 1]
    store r12 r10
    r13 <- load ptrToTuple r2
    ret r13
  internal first fstName [(ptrToTuple, mkLLVMName $ "__arg")] $ do
    r2 <- alloca1 ptrToTuple (ptr ptrToTuple)
    store r2 (LOP.LocalReference ptrToTuple (mkLLVMName "__arg"))
    r3 <- load ptrToTuple r2
    r4 <- getElementPtrInb (ptr first) r3 [cint32 0, cint32 0]
    r5 <- load first r4
    ret r5
  internal second sndName [(ptrToTuple, mkLLVMName $ "__arg")] $ do
    r2 <- alloca1 ptrToTuple (ptr ptrToTuple)
    store r2 (LOP.LocalReference ptrToTuple (mkLLVMName "__arg"))
    r3 <- load ptrToTuple r2
    r4 <- getElementPtrInb (ptr second) r3 [cint32 0, cint32 1]
    r5 <- load second r4
    ret r5
codegenGlobal (DefPair _ ty _ _) = panic $! "Pair type mismatch : " <> (show ty)

-- | Transform a functions to LLVM
-- that expects the given arguments in context.
codegenBody ::
     [(LLVM.Type, LLVM.Name)] -> Expr -> Codegen (LLVM.Named LLVM.Terminator)
codegenBody args' body
  -- extract argument list
 = let expTy = exprType body
    in case expTy of
         -- takes care of operations like write()
         TVoid -> do
           forM_ args' $ \(ty, LLVM.Name name) ->
             assign (toS name) (local ty (LLVM.Name name))
           codegenExpr body
           retvoid
         -- takes care of values
         _ -> do
           forM_ args' $ \(ty, LLVM.Name name) ->
             assign (toS name) (local ty (LLVM.Name name))
           body' <- codegenExpr body
           ret body'

-- | transform a program to LLVM
codegenProg :: Program -> LLVM ()
codegenProg program
  -- runtime structs
  -- see NOTE 1 on packing below
 = do
  structTypeDefn "struct.elem_t" False [i64, anyPtr]
  structTypeDefn "struct.entry" False [i32, NamedTypeReference "struct.elem_t"]
  structTypeDefn
    "struct.log"
    False
    [i32, i32, ptr $ NamedTypeReference "struct.entry"]
  structTypeDefn
    "struct.array_data"
    False
    [ i32
    , i32
    , ptr $ NamedTypeReference "struct.elem_t"
    , ptr $ NamedTypeReference "struct.log"
    ]
  structTypeDefn
    "struct.sequence"
    False
    [i32, NamedTypeReference "struct.array_data"]
  -- external symbols
  external (ptr i8) "malloc" [(i32, "size", [])]
  external i32 "readIntStream" []
  external void "writeIntStream" [(i32, "var", [])]
  external
    void
    "new"
    [ (ptr $ NamedTypeReference "struct.sequence", "s", [])
    , (i64, "size", [])
    , (i32, "count", [])
    , (i64, "elem_size", [])
    , (anyPtr, "data", [])
    ]
  external
    elemStruct
    "get"
    [(ptr $ NamedTypeReference "struct.sequence", "s", []), (i32, "idx", [])]
  external
    void
    "set"
    [ (ptr $ NamedTypeReference "struct.sequence", "s", [])
    , (i64, "size", [])
    , (ptr $ NamedTypeReference "struct.sequence", "ss", [])
    , (i32, "idx", [])
    , (i64, "elem_size", [])
    , (anyPtr, "data", [])
    ]
  -- external
  --   void
  --   "llvm.memcpy.p0i8.p0i8.i64"
  --   [ (anyPtr, "dst", [PA.NoCapture, PA.WriteOnly])
  --   , (anyPtr, "src", [PA.NoCapture, PA.ReadOnly])
  --   , (i64, "numBytes", [])
  --   , (i1, "isVolatile", [])
  --   ]
  -- number of arguments to main
  let argc = L1.programMainNumArgs program
  constant int "__main_argc" (LC.Int 32 (fromIntegral argc))
  -- entry point
  entryPoint (fromIntegral argc)
  -- main function
  let mainArgNames = L1.programMainArgNames program
      mainArglist = [(i32, LLVM.Name (toS name)) | name <- mainArgNames]
  -- define i32 (mangle "main") mainArglist $
  --   codegenBody mainArglist (L1.programMainFunction program)

  define i32 "main" mainArglist $
    let retTy = L1.programMainType program
     in case retTy of
          -- takes care of main : SF _ () ()
          TClosure _ TVoid -> do
            codegenExpr (L1.programMainFunction program)
            ret zero
          _ ->
            codegenBody mainArglist (L1.programMainFunction program)

  -- global functions
  mapM_ codegenGlobal $ L1.programGlobals program

assertM :: Applicative m => Bool -> m ()
assertM = flip assert $ pure ()
-- NOTE 1
-- UPDATE : Below not true anymore. Not packing anymore
-- Currently packing all the elements of the arrays assuming an embedded system
-- where memory is scarce. This will affect the high performance cases with more
-- memory accesses where we shouldn't pack. In fact packing should be a compiler
-- option.
-- Read: http://www.catb.org/esr/structure-packing/
-- NOTE 2
-- Storing Boolean with one byte space instead of 1 bit

module Main where

import Data.String
import Data.Text (pack)
import Desugar
import Parse
import Pretty
import Protolude
import Typecheck

import L1.Interpreter
import L1.L1
import L1.Optimizer
import L2.Interpreter
import L2.JIT
import qualified L2.Erlang.Interpreter as EI

import System.Directory
import System.Process (callCommand)


hstDirectory = "/Users/abhiroopsarkar/Haskell/hailstorm/"

filepath   = hstDirectory <> "examples/erl.hst"

outfile    = hstDirectory <> "examples/arrays.ll"

array    = hstDirectory <> "rts/Array.ll"

io       = hstDirectory <> "rts/IO.ll"

linkedfile = hstDirectory <> "examples/hailstorm_linked.ll"

objectfile = hstDirectory <> "examples/hailstorm_linked.o"

compiler :: FilePath -> IO String
compiler infile = do
  astSugar <- parseFile' infile
  let ast = desugar astSugar
  tcd <- typeCheck' ast
  -- (writeFile outfile . toStrict . ppllvm . l1Tol2 . optimize . astToL1) tcd

  -- callCommand $ "llvm-link-8 -S " <> outfile <> " " <> array <> " " <> io <> " > " <> linkedfile
  -- callCommand $ "llc-8 -filetype=obj  " <> linkedfile
  -- callCommand $ "clang " <> objectfile -- creates a.out in hstDirectory


  let l1  = astToL1 tcd
      l1' = optimize l1
      l2  = EI.l1Tol2 l1' EI.General
  -- print astSugar
  -- print ast
  -- print tcd
  -- print l1
  -- print l1'
  -- putStrLn $ EI.ppErl l2
  -- print l2
  -- putStrLn $ ppllvm l2
  -- printLLVM l2
  -- exec [] l2
  -- debugOptimizer l1
  pure $! EI.ppErl l2

main :: IO ()
main = do
  args <- getArgs
  let fileName =
        fromMaybe (panic $! "Filename not passed") $
        head args
  cd <- getCurrentDirectory
  let finalFilePath = cd <> "/" <> fileName
  erlangCore <- compiler finalFilePath
  let finalFilePath = cd <> "/test.core"
  writeFile finalFilePath (pack erlangCore)
  callCommand $ "erlc " <> finalFilePath

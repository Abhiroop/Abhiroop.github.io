module Parse
  ( parseText
  , parseText'
  , parseFile
  , parseFile'

  , keywords
  , isKeyword
  ) where

import Protolude hiding (Type, Prefix, try, hPutStrLn, stderr)

import Control.Monad (fail)
import Control.Monad.Combinators.Expr
import Data.Set (Set)
import qualified Data.Set as Set
import Data.String (String)
import qualified Data.Text as Text
import qualified Data.Text.IO as Text
import Text.Megaparsec hiding (many, some)
import Text.Megaparsec.Char
import qualified Text.Megaparsec.Char.Lexer as Lexer
import System.IO (hPutStrLn, stderr)

import Desugar


type Parser = Parsec Void Text
type PError = ParseErrorBundle Text Void

parseText :: Text -> Either PError Program
parseText = parse pProgram "<input>"

parseText' :: Text -> IO Program
parseText' = dieOnParseError . parseText

parseFile :: FilePath -> IO (Either PError Program)
parseFile filepath =
  parse pProgram filepath <$> Text.readFile filepath

parseFile' :: FilePath -> IO Program
parseFile' = dieOnParseError <=< parseFile


dieOnParseError :: Either PError a -> IO a
dieOnParseError = either handleErr return
  where
    handleErr :: ParseErrorBundle Text Void -> IO a
    handleErr err = do
      hPutStrLn stderr "Parser Error:"
      hPutStrLn stderr $ errorBundlePretty err
      exitFailure

pProgram :: Parser Program
pProgram = label "program" $
  between pSpace eof program
  where
    program = Program <$> stmts
    stmts = many pStmt

pStmt = choice  [ Global <$> pGlobal
                , Resource <$> pResource
                ]

pGlobal :: Parser Global
pGlobal = label "global binding" $ do
  name <- pSymbol "def" *> pName
  arglist <- many pArg1
  type_ <- pTypeAnnot
  body <- pSymbol "=" *> pExpr
  pure $! Def name arglist type_ body

pArgument :: Parser Arg
pArgument = label "function argument" $
  parens $ do
    name <- pName
    type_ <- pTypeAnnot
    pure (name, type_)

pArg1 :: Parser Arg1
pArg1 = try pPairArg <|> pPlain

pPlain :: Parser Arg1
pPlain = label "plain argument" $
  parens $ do
    name <- pName
    type_ <- pTypeAnnot
    pure $! Plain (name, type_)

pPairArg :: Parser Arg1
pPairArg = label "pair argument" $ do
  fst <- pSymbol "(" *> pArg1
  snd <- pSymbol "," *> pArg1
  _ <- pSymbol ")"
  pure $! PairArg fst snd

pTypeAnnot :: Parser Type
pTypeAnnot = label "type annotation" $
  pSymbol ":" *> pType

pType :: Parser Type
pType = label "type" $
  makeExprParser term table
  where
    term = choice
      [ TInt <$ pSymbol "Int"
      , TFloat <$ pSymbol "Float"
      , TBool <$ pSymbol "Bool"
      , TVoid <$ pSymbol "()"
      , parens pType
      , TSeq <$>  seqTy pType
      , sfTy
      ]
    table = [ [InfixR (TArr <$ pSymbol "->")]
            , [InfixR (TPair <$ pSymbol ",")]
            ]


pExpr :: Parser Expr
pExpr = label "expression" $
  makeExprParser term table
  where
    term = label "term" $
      choice
        [ parens pExpr
        , pPair
        , pPrimOp
        , pFst
        , pSnd
        , pReadColor
        , pWriteColor
        , pRate
        , pMapSignal
        , pLoop
        , pSwitch
        , pVar
        , pLit
        , pLet
        , pLam
        , pIf
        , pCase
        ]
    table =
      [ [ InfixL (pure App)
        ]
      , [ InfixL (Pair <$ pSymbol ",")]
      , [ InfixR (Compose <$ pSymbol ">>>")
        , InfixR (UnsafeCompose <$ pSymbol ":>>>:")
        ]
      , [ InfixR (Fanout <$ pSymbol "&&&")
        , InfixR (UnsafeFanout <$ pSymbol ":&&&:")
        ]
      , [ InfixR (Combine <$ pSymbol "***")
        , InfixR (UnsafeCombine <$ pSymbol ":***:")
        ]
      , [ InfixL (BinaryOp DivF <$ pSymbol "/")
        , InfixL (BinaryOp MulF <$ pSymbol "*.")
        , InfixL (BinaryOp Mul <$ pSymbol "*")
        ]
      , [ InfixL (BinaryOp AddF <$ pSymbol "+.")
        , InfixL (BinaryOp Add <$ pSymbol "+")
        , InfixL (BinaryOp SubF <$ pSymbol "-.")
        , InfixL (BinaryOp Sub <$ pSymbol "-")
        ]
      , [ InfixL (BinaryOp Eql <$ pSymbol "==")
        , InfixL (RelOp HGE <$ pSymbol ">=")
        , InfixL (RelOp HLE <$ pSymbol "=<")
        , InfixL (RelOp HGT <$ pSymbol ">")
        , InfixL (RelOp HLT <$ pSymbol "<")
        ]
      ]

pVar :: Parser Expr
pVar = label "variable" $
  Var <$> pName

pLit :: Parser Expr
pLit = label "literal" $
  choice
    [ try $ Lit . LFloat <$> pFloat
    , Lit . LInt   <$> pInt
    , Lit . LBool  <$> pBool
    ]

pInt :: Parser Int
pInt = label "integer" $
  fromIntegral <$> lexeme Lexer.decimal

pFloat :: Parser Float
pFloat = label "float" $
  lexeme Lexer.float

pBool :: Parser Bool
pBool = label "boolean" $
  choice
    [ True <$ pSymbol "True"
    , False <$ pSymbol "False"
    ]

{- |
   let foo = newSeq# 5 0
                     ^ ^
                     | init
                  capacity

       bar = getSeq# foo 0
                         ^
                        idx

       baz = setSeq# foo 5 2
                         ^ ^
                         | |
                        idx|
                          val

The Int and Bool prefix shall be removed upon
addition of polymorphism to Hailstorm

-}

pPrimOp :: Parser Expr
pPrimOp = label "primitive-operation" $ do
  choice
    [ PrimOp NewSeqInt <$ pSymbol "newSeqInt#"
    , PrimOp GetSeqInt <$ pSymbol "getSeqInt#"
    , PrimOp SetSeqInt <$ pSymbol "setSeqInt#"
    , PrimOp NewSeqBool <$ pSymbol "newSeqBool#"
    , PrimOp GetSeqBool <$ pSymbol "getSeqBool#"
    , PrimOp SetSeqBool <$ pSymbol "setSeqBool#"
    , PrimOp ReadIntStream  <$ pSymbol "readIntStream#"
    , PrimOp WriteIntStream <$ pSymbol "writeIntStream#"
    , PrimOp ReadBoolStream  <$ pSymbol "readBoolStream#"
    , PrimOp WriteBoolStream <$ pSymbol "writeBoolStream#"
    ]

pResource :: Parser Resource
pResource = label "resource-type" $ do
  name <- pSymbol "resource" *> pResourceName
  pure $! R (Singleton (RName name))

pResourceType :: Parser ResourceTy
pResourceType = label "resource-types" $ do
  makeExprParser term table
  where
    term = choice
      [ Empty <$ pSymbol "Empty"
      , pSingleton
      , parens pResourceType
      ]
    table = [[InfixR (Union <$ pSymbol "U")]]


pSingleton :: Parser ResourceTy
pSingleton = label "singleton" $ do
  name <- pResourceName
  pure $! (Singleton (RName name))


pResourceName :: Parser Name
pResourceName = label "resource-identifier" $
  lexeme . try $ do
    name <- parser
    when (isKeyword name) $
      fail $ "illegal identifier `" <> toS name <> "' is a keyword"
    pure name
  where
    parser = do
      firstChar <- upperChar
      laterChars <- many $ alphaNumChar <|> oneOf [ '\'', '_' ]
      pure $! Text.pack (firstChar : laterChars)

pLet :: Parser Expr
pLet = label "let-binding" $ do
  name <- pSymbol "let" *> pName
  bound <- pSymbol "=" *> pExpr
  body <- pSymbol "in" *> pExpr
  pure $! Let name bound body

pPair :: Parser Expr
pPair = label "pair" $ do
  fst <- pSymbol "(" *> pExpr
  snd <- pSymbol "," *> pExpr
  _ <- pSymbol ")"
  pure $! Pair fst snd

pFst :: Parser Expr
pFst = label "fst" $ do
  fst_ <- pSymbol "fst#" *> pExpr
  pure $! Fst fst_

pSnd :: Parser Expr
pSnd = label "snd" $ do
  snd_ <- pSymbol "snd#" *> pExpr
  pure $! Snd snd_

pLam :: Parser Expr
pLam = label "lambda-expression" $ do
  arglist <- pSymbol "\\" *> some pArg1
  body <- pSymbol "=>" *> pExpr
  pure $! Lam arglist body

pIf :: Parser Expr
pIf = label "if-expression" $ do
  cond <- pSymbol "if" *> pExpr
  then_ <- pSymbol "then" *> pExpr
  else_ <- pSymbol "else" *> pExpr
  pure $! If cond then_ else_


pCase :: Parser Expr
pCase = label "case-expression" $ do
  s     <- pSymbol "case" *> pExpr
  conds <- pSymbol "of" *> some pCaseConds
  e     <- pSymbol "_ ~>" *> pExpr
  pure $! Case s conds e

pCaseConds :: Parser (Expr, Expr)
pCaseConds = label "case-conds" $ do
  e1 <- pExpr
  e2 <- pSymbol "~>" *> pExpr
  pSymbol ";"
  pure (e1, e2)


pName :: Parser Name
pName = label "identifier" $
  lexeme . try $ do
    name <- parser
    when (isKeyword name) $
      fail $ "illegal identifier `" <> toS name <> "' is a keyword"
    pure name
  where
    parser = do
      firstChar <- lowerChar
      laterChars <- many $ alphaNumChar <|> oneOf [ '\'', '_' ]
      pure $! Text.pack (firstChar : laterChars)


keywords :: Set Text
keywords = Set.fromList
  [ "def"
  , "let", "in"
  , "if", "then", "else"
  , "True", "False"
  , "resource"
  , "case", "of"
  ]

isKeyword :: Name -> Bool
isKeyword = (`Set.member` keywords)

pSymbol :: Text -> Parser Text
pSymbol = Lexer.symbol pSpace

pSpace :: Parser ()
pSpace = Lexer.space (void spaceChar) lineComment blockComment
  where
    lineComment = Lexer.skipLineComment "--"
    blockComment = Lexer.skipBlockComment "{-" "-}"

lexeme :: Parser a -> Parser a
lexeme = Lexer.lexeme pSpace

parens :: Parser a -> Parser a
parens = label "parentheses" .
  between (pSymbol "(") (pSymbol ")")

seqTy :: Parser a -> Parser a
seqTy = label "sequence" .
  between (pSymbol "[") (pSymbol "]")

-- Resource type here
sfTy :: Parser Type
sfTy = label "sfTy" $ do
  resource  <- pSymbol "SF" *> pResourceType
  input  <- pType
  output <- pType
  pure $! TSF resource input output


pMapSignal :: Parser Expr
pMapSignal = label "mapsignal" $ do
  func <- pSymbol "mapSignal#" *> pExpr
  pure $! MapSignal func

-- NOTE : Enforcing full application in a partially
-- applied language here.
pLoop :: Parser Expr
pLoop = label "loop" $ do
  exprs <- pSymbol "loop#" *> pExpr
  case exprs of
    App expr1 expr2 ->
      -- Function application is left associative thats why we
      -- simply check expr1 below if there are more than 2
      -- arguments supplied the first case of the following check
      -- will be hit and throw a parse error.
      case expr1 of
        App _ _ -> fail "More than 2 arguments supplied to loop#"
        _ -> pure $! Loop expr1 expr2
    _ -> fail "Less than 2 arguments supplied to loop#"

pSwitch :: Parser Expr
pSwitch = label "switch" $ do
  exprs <- pSymbol "switch#" *> pExpr
  case exprs of
    App expr1 expr2 ->
      -- Function application is left associative thats why we
      -- simply check expr1 below if there are more than 2
      -- arguments supplied the first case of the following check
      -- will be hit and throw a parse error.
      case expr1 of
        App _ _ -> fail "More than 2 arguments supplied to switch#"
        _ -> pure $! Switch expr1 expr2
    _ -> fail "Less than 2 arguments supplied to switch#"

pRate :: Parser Expr
pRate = label "rate" $ do
  exprs <- pSymbol "rate#" *> pExpr
  case exprs of
    App expr1 expr2 ->
      -- Function application is left associative thats why we
      -- simply check expr1 below if there are more than 2
      -- arguments supplied the first case of the following check
      -- will be hit and throw a parse error.
      case expr1 of
        App _ _ -> fail "More than 2 arguments supplied to rate#"
        _ -> pure $! Rate expr1 expr2
    _ -> fail "Less than 2 arguments supplied to rate#"

-- | GRiSP specific
pReadColor :: Parser Expr
pReadColor = label "readcolor" $ do
  ledPosition <- pSymbol "readColor#" *> pExpr
  type_ <- pTypeAnnot
  pure $! ReadColor (ledPosition, type_)

pWriteColor :: Parser Expr
pWriteColor = label "writecolor" $ do
  ledPosition <- pSymbol "writeColor#" *> pExpr
  type_ <- pTypeAnnot
  pure $! WriteColor (ledPosition, type_)

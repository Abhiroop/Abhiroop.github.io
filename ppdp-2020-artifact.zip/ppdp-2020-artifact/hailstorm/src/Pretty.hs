module Pretty
  (
    -- * Convenient Interface
    prettyPrint
  , prettyText
  , prettyPlainText
  , prettyPlainTextFast

    -- * Pretty Printing
  , ppProgram
  , ppName
  , ppType
  , ppExpr
  , ppResourceType

    -- * Syntax Highlighting
  , Highlight (..)
  , highlightTerminal
  ) where

import Protolude hiding (Type, group)

import Data.Text.Prettyprint.Doc
import qualified Data.Text.Prettyprint.Doc.Render.Text as Render.Text
import Data.Text.Prettyprint.Doc.Render.Terminal (Color(..), color, colorDull, bold)
import qualified Data.Text.Prettyprint.Doc.Render.Terminal as Render.Terminal

import AST


----------------------------------------------------------------------
-- Convenient Interface

prettyPrint :: Program -> IO ()
prettyPrint =
  Render.Terminal.putDoc
  . reAnnotate highlightTerminal
  . ppProgram

prettyText :: Program -> Text
prettyText =
  Render.Terminal.renderStrict
  . layoutSmart defaultLayoutOptions
  . reAnnotate highlightTerminal
  . ppProgram

prettyPlainText :: Program -> Text
prettyPlainText = Render.Text.renderStrict . layoutSmart defaultLayoutOptions . ppProgram

prettyPlainTextFast :: Program -> Text
prettyPlainTextFast = Render.Text.renderStrict . layoutCompact . ppProgram


----------------------------------------------------------------------
-- Pretty Printing

ppProgram :: Program -> Doc Highlight
ppProgram (Program stmts) =
  concatWith
    (surround $ hardline <> hardline)
    (map ppStmt stmts)

ppStmt :: Stmt -> Doc Highlight
ppStmt (Global g) = ppGlobal g
ppStmt (Resource (R rty)) = ppResourceType rty

ppGlobal :: Global -> Doc Highlight
ppGlobal (Def name arglist retty body) =
  let
    def' = ppKeyword "def"
    name' = ppName name
    arg'list = map ppArg arglist
    annot' = ppTypeAnnot retty
    equals' = ppEquals
    body' = ppExpr body

    defNameArgs'
      | [] <- arg'list
      = group $
          vsep [ def' <+> name', indent 2 annot' ]
          `flatAlt`
          hsep [ def', name', annot' ]
      | otherwise
      = group $
          vsep [ def' <+> name', indent 2 (vsep arg'list), indent 2 annot' ]
          `flatAlt`
          hsep [ def', name', hsep arg'list, annot' ]
    equalsBody' =
      group $
        vsep [ equals', indent 2 body' ]
        `flatAlt`
        hsep [ equals', body' ]
  in
  group $
    vsep [ defNameArgs', equalsBody' ]
    `flatAlt`
    hsep [ defNameArgs', equalsBody' ]

ppName :: Name -> Doc Highlight
ppName = annotate HlName . pretty

ppArg :: Arg -> Doc Highlight
ppArg (name, type_) = parens . group . align $
  fillBreak 1 (ppName name) <+> ppTypeAnnot type_

ppMapSignal :: (Expr, Type) -> Doc Highlight
ppMapSignal (expr, type_) = parens . group . align $
  fillBreak 1 (ppExpr expr) <+> ppTypeAnnot type_

ppTypeAnnot :: Type -> Doc Highlight
ppTypeAnnot type_ = align $ ppColon <+> ppType type_


ppResourceType :: ResourceTy -> Doc Highlight
ppResourceType Empty = ppTypeName "Empty"
ppResourceType (Singleton (RName rname))
  = ppTypeName rname
ppResourceType (Union rty1 rty2)
  = (ppResourceType rty1) <> " U " <>
    (ppResourceType rty2)

ppType :: Type -> Doc Highlight
ppType = ppTypePrec 0

ppTypePrec :: Int -> Type -> Doc Highlight
ppTypePrec _ TVoid = ppTypeName "()"
ppTypePrec _ TInt = ppTypeName "Int"
ppTypePrec _ TFloat = ppTypeName "Float"
ppTypePrec _ TBool = ppTypeName "Bool"
ppTypePrec p (TArr ty tys) = parensIf (p > 0) $
  let
    ty' = ppTypePrec (succ p) ty
    tys' = ppTypePrec (succ p) <$> flatTArr tys
  in
  sep $ ty' : map (ppArrow <+>) tys'
ppTypePrec p (TSeq ty) =
  "[" <>
  ( let
      ty' = ppTypePrec (succ p) ty
    in sep [ty'] ) <>
  "]"
ppTypePrec p (TPair ty1 ty2) =
  parens $ (ppTypePrec (succ p) ty1) <> "," <> (ppTypePrec (succ p) ty2)
ppTypePrec p (TSF r ty1 ty2) =
  ppTypeName "SF " <>
  (ppResourceType r) <> " " <>
  (ppType ty1) <> " " <>
  (ppType ty2)


ppTypeName :: Text -> Doc Highlight
ppTypeName = annotate HlType . pretty

ppArrow :: Doc Highlight
ppArrow = annotate HlSymbol "->"

ppExpr :: Expr -> Doc Highlight
ppExpr = ppExprPrec 0

ppExprPrec :: Int -> Expr -> Doc Highlight
ppExprPrec p = \case

  Var name -> ppName name

  Lit (LInt n) -> annotate HlLiteral (pretty n)
  Lit (LFloat n) -> annotate HlLiteral (pretty n)
  Lit (LBool b) -> annotate HlLiteral (pretty b)

  Let name bound body -> parensIf (p > 0) $
    let
      let' = ppKeyword "let"
      name' = ppName name
      equals' = ppEquals
      bound' = ppExpr bound
      in' = ppKeyword "in"
      body' = ppExpr body

      nameBound =
        group $
          vsep [ name' <+> equals', indent 2 bound' ]
          `flatAlt`
          hsep [ name' <+> equals', bound' ]
      letIn =
        group $
          vsep [ let', indent 2 nameBound, in' ]
          `flatAlt`
          hsep [ let', nameBound, in' ]
    in
    group $
      vsep [ letIn, body' ]

  If cond true_ false_ -> parensIf (p > 0) $
    let
      if' = ppKeyword "if"
      cond' = ppExpr cond
      then' = ppKeyword "then"
      true' = ppExpr true_
      else' = ppKeyword "else"
      false' = ppExpr false_

      ifCondThen =
        group $
          vsep [ if', indent 2 cond', then' ]
          `flatAlt`
          hsep [ if', cond', then' ]
    in
    group $
      vsep [ ifCondThen, indent 2 true', else', indent 2 false' ]
      `flatAlt`
      hsep [ ifCondThen, true', else', false' ]

  BinaryOp op a b ->
    let
      op' = annotate HlBinaryOp $
        case op of
          DivF -> "/"
          MulF -> "*."
          Mul  -> "*"
          AddF -> "+."
          Add  -> "+"
          SubF -> "-."
          Sub  -> "-"
          Eql  -> "=="
      p' = opPrecedence op
      a' = ppExprPrec p' a
      b' = ppExprPrec (succ p') b
    in
    parensIf (p > p') $
      fillSep [ a', op' <+> b' ]

  RelOp op a b ->
    -- we use `HlBinaryOp` for relops as well
    -- to give them the same colour
    let
      op' = annotate HlBinaryOp $
        case op of
          HGT -> ">"
          HLT -> "<"
          HGE -> ">="
          HLE -> "=<"
      p' = relopPrecedence op
      a' = ppExprPrec p' a
      b' = ppExprPrec (succ p') b
    in
    parensIf (p > p') $
      fillSep [ a', op' <+> b' ]

  app@App {} ->
    let
      (f, args) = unfoldApp app
      p' = appPrecedence
      f' = ppExprPrec p' f
      args' = ppExprPrec (succ p') <$> args
    in
    parensIf (p > p') $
      group . nest 2 . vsep $
        [ f', fillSep args' ]

  Lam arglist body -> parensIf (p > 0) $
    let
      lam' = ppLambda
      arglist' = ppArg <$> arglist
      arrow' = ppDoubleArrow
      body' = ppExpr body

      lamArrow' =
        group $
          vsep [ lam' <+> align (fillSep arglist'), arrow' ]
          `flatAlt`
          hsep [ lam', hsep arglist', arrow' ]
    in
    group $
      vsep [ lamArrow', indent 2 body' ]
      `flatAlt`
      hsep [ lamArrow', body' ]
  PrimOp primop ->
    let
      op' = annotate HlPrimOp $
        case primop of
          NewSeqInt -> "newSeqInt#"
          GetSeqInt -> "getSeqInt#"
          SetSeqInt -> "setSeqInt#"
          NewSeqBool -> "newSeqBool#"
          GetSeqBool -> "getSeqBool#"
          SetSeqBool -> "setSeqBool#"
          ReadIntStream  -> "readIntStream#"
          WriteIntStream -> "writeIntStream#"
          ReadBoolStream  -> "readBoolStream#"
          WriteBoolStream -> "writeBoolStream#"

      p' = primOpPrecedence primop
     in
    parensIf (p > p') $
      fillSep [ op']

  Pair expr1 expr2 -> parens $ (ppExpr expr1) <> "," <> (ppExpr expr2)
  Fst expr -> "fst# " <> ppExpr expr
  Snd expr -> "snd# " <> ppExpr expr
  MapSignal expr -> "mapSignal# " <> ppExpr expr
  Loop expr1 expr2 -> "loop# " <+> ppExpr expr1 <+> ppExpr expr2
  Compose expr1 expr2 -> (ppExpr expr1) <> " >>> " <> (ppExpr expr2)
  UnsafeCompose expr1 expr2 ->
    (ppExpr expr1) <> " :>>>: " <> (ppExpr expr2)
  Fanout expr1 expr2 -> (ppExpr expr1) <> " &&& " <> (ppExpr expr2)
  UnsafeFanout expr1 expr2 ->
    (ppExpr expr1) <> " :&&&: " <> (ppExpr expr2)
  Combine expr1 expr2 -> (ppExpr expr1) <> " *** " <> (ppExpr expr2)
  UnsafeCombine expr1 expr2 ->
    (ppExpr expr1) <> " :***: " <> (ppExpr expr2)
  Switch expr1 expr2 -> "switch# " <+> ppExpr expr1 <+> ppExpr expr2
  Rate   expr1 expr2 -> "rate# " <+> ppExpr expr1 <+> ppExpr expr2
  ReadColor (ledpos, type_) ->
    "readColor# " <+> ppExpr ledpos <+> ppTypeAnnot type_
  WriteColor (ledpos, type_) ->
    "writeColor# " <+> ppExpr ledpos <+> ppTypeAnnot type_


ppKeyword :: Text -> Doc Highlight
ppKeyword = annotate HlKeyword . pretty

ppLambda :: Doc Highlight
ppLambda = annotate HlSymbol backslash

ppDoubleArrow :: Doc Highlight
ppDoubleArrow = annotate HlSymbol "=>"

ppColon :: Doc Highlight
ppColon = annotate HlSymbol colon

ppEquals :: Doc Highlight
ppEquals = annotate HlSymbol equals

parensIf :: Bool -> Doc Highlight -> Doc Highlight
parensIf True = parens . align
parensIf False = identity

----------------------------------------------------------------------
-- Syntax Highlighting

data Highlight
  = HlName
  | HlKeyword
  | HlType
  | HlBinaryOp
  | HlSymbol
  | HlLiteral
  | HlError
  | HlPrimOp
  deriving (Eq, Show)

highlightTerminal :: Highlight -> Render.Terminal.AnsiStyle
highlightTerminal = \case
  HlName -> mempty
  HlKeyword -> colorDull Blue
  HlType -> color Red
  HlBinaryOp -> colorDull Blue
  HlSymbol -> bold <> colorDull Blue
  HlLiteral -> color Red
  HlError -> bold <> color Red
  HlPrimOp -> colorDull Yellow

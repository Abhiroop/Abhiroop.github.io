{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE RecordWildCards #-}

module Typecheck
    -- * Convenient Interface
  ( typeCheck
  , typeCheck'
    -- * Type Checked Program
  , TypeSafeProgram
  , programMainNumArgs
  , programMainArgNames
  , programMainFunction
  , programMainType
  , programGlobals
    -- * Error Handling
  , TypeCheckError(..)
  , ExprError(..)
  , GlobalError(..)
  , ProgramError(..)
  ) where

import Protolude hiding (Type, group)

import Data.Map.Strict (Map)
import qualified Data.List as DL
import qualified Data.Map.Strict as Map
import qualified Data.Text as Text
import Data.Text.Prettyprint.Doc
import qualified Data.Text.Prettyprint.Doc.Render.Terminal as Render.Terminal

import AST
import Parse (isKeyword)
import Pretty hiding (prettyPrint)
----------------------------------------------------------------------
-- Convenient Interface
typeCheck :: Program -> Either (Doc Highlight) TypeSafeProgram
typeCheck = first ppProgramError . checkProgram

-- | type-check the program, print and abort if an error occurs
typeCheck' :: Program -> IO TypeSafeProgram
typeCheck' = either printErrorAndDie pure . checkProgram
  where
    printErrorAndDie err = do
      Render.Terminal.renderIO stderr $
        layoutSmart defaultLayoutOptions $
        reAnnotate highlightTerminal $ ppProgramError err
      exitFailure

----------------------------------------------------------------------
-- Type Checked Program
data TypeSafeProgram =
  TypeSafeProgram
    { programGlobals :: [Global]
    , programMainArgNames :: [Name]
    , programMainType :: Type
    , programMainFunction :: Expr
    }
  deriving (Show, Eq, Ord, Generic)

programMainNumArgs :: TypeSafeProgram -> Int
programMainNumArgs = length . programMainArgNames

----------------------------------------------------------------------
-- Type Checker
type Context = Map Name Type

data Env =
  Env
    { context :: Context
    , resources :: [Resource]
    }

ioresourcety = Singleton (RName "IO")
ioresource = R ioresourcety

with :: Env -> [Arg] -> Env
with (Env {context = ctx, ..}) arglist = Env {context = ctx', ..}
  where
    ctx' = Map.fromList arglist `Map.union` ctx

checkProgram :: Program -> Either ProgramError TypeSafeProgram
checkProgram p =
  let (globals, rs) = splitProgram p
      rs' = ioresource : rs
   in go (globals, rs')
  where
    go (globals, rs)
           -- check for recurring global names
     = do
      let nameMultiples = enlistMultiples (map globalName globals)
      let resMultiples = enlistMultiples (map resourceName rs)
      unless (null nameMultiples) $
        throwProgramError $! RecurringGlobalNames nameMultiples
      unless (null resMultiples) $
        throwProgramError $! RecurringResourceNames resMultiples
           -- check global definitions
      rethrowProgramGlobalError $ forM_ globals $ checkGlobal env
      let globals' = Map.fromList [(globalName g, g) | g <- globals]
           -- check main function
      main <-
        maybe (throwProgramError NoMainFunction) pure $
        Map.lookup "main" globals'
      let Def _ mainArglist mainRetty mainBody = main
          mainArgTypes = argTypes mainArglist
          mainArgNames = argNames mainArglist
      -- unless (all (== TInt) mainArgTypes && mainRetty == TInt) $
      --   throwProgramError $!
      --   IllegalMainFunction (foldTArr mainArgTypes mainRetty)
           -- Construct type checked program
      pure $!
        TypeSafeProgram
          { programGlobals = Map.elems $ Map.delete "main" globals'
          , programMainArgNames = mainArgNames
          , programMainType = mainRetty
          , programMainFunction = mainBody
          }
      where
        ctx = Map.fromList $ map nameAndType globals
        env = Env {context = ctx, resources = rs}
        nameAndType global = (globalName global, globalType global)

checkGlobal :: Env -> Global -> Either GlobalError ()
checkGlobal env (Def name arglist retty body) = do
  bodyty <- rethrowGlobalBodyError name $ checkExpr (env `with` arglist) body
  unless (bodyty == retty) $
    throwError $! GlobalError name (ReturnTypeMismatch retty bodyty)

{-
Def "baz" [] TInt
  (Let "foo" (App (App (PrimOp NewSeq) (Lit (LInt 5))) (Lit (LInt 0))) (App (App (PrimOp GetSeq) (Lit (LInt 5))) (Lit (LInt 1))))
-}
checkExpr :: Env -> Expr -> Either ExprError Type
checkExpr env@(Env {context = ctx, resources = res}) expr =
  exprErrorTrace expr $
  case expr of
    Lit (LInt _) -> pure TInt
    Lit (LFloat _) -> pure TFloat
    Lit (LBool _) -> pure TBool
    Var name -> do
      first exprError_ $ checkName name
      case Map.lookup name ctx of
        Nothing -> throwExprError_ $! VariableNotInScope name
        Just ty -> pure ty
    Let name bound body -> do
      boundty <- checkExpr env bound
      let ctx' = (Map.insert name boundty ctx)
      checkExpr (Env {context = ctx', resources = res}) body
    If cond then_ else_ -> do
      condty <- checkExpr env cond
      unless (condty == TBool) $
        throwExprError cond $! ExpectedButGot TBool condty
      thenty <- checkExpr env then_
      elsety <- checkExpr env else_
      unless (thenty == elsety) $ throwExprError_ (NotTheSame thenty elsety)
      pure thenty
    BinaryOp Eql a b -> do
      aty <- checkExpr env a
      bty <- checkExpr env b
      unless (aty == bty) $ throwExprError_ (NotTheSame aty bty)
      -- at this point we have verified both the types are same
      -- now express the checks on one type
      -- NOTE : Equality for sequences can be defined as pointwise
      -- equality of each element but none of the backends can support
      -- this right now so the test is disabled
      case aty of
        TInt  -> pure TBool
        TBool -> pure TBool
        TFloat -> pure TBool
        TPair _ _ -> pure TBool
        _ -> throwExprError_ (EqualityUndefined aty)
    BinaryOp Add a b -> binopHelperInt env a b >> pure TInt
    BinaryOp Sub a b -> binopHelperInt env a b >> pure TInt
    BinaryOp Mul a b -> binopHelperInt env a b >> pure TInt
    BinaryOp AddF a b -> binopHelperFloat env a b >> pure TFloat
    BinaryOp SubF a b -> binopHelperFloat env a b >> pure TFloat
    BinaryOp MulF a b -> binopHelperFloat env a b >> pure TFloat
    BinaryOp DivF a b -> binopHelperFloat env a b >> pure TFloat
    RelOp _ a b -> do
      aty <- checkExpr env a
      bty <- checkExpr env b
      unless (aty == bty) $ throwExprError_ (NotTheSame aty bty)
      -- at this point we have verified both the types are same
      -- now express the checks on one type
      case aty of
        TInt  -> pure TBool
        TFloat -> pure TBool
        _ -> throwExprError_ (RelOpUndefined aty)


    App f x -> do
      fty <- checkExpr env f
      xty <- checkExpr env x
      case fty of
        TArr argty retty -> do
          unless (xty == argty) $ throwExprError_ (ExpectedButGot argty xty)
          pure retty
        _ -> throwExprError f (NotAFunction fty)
    Lam arglist body -> do
      let argMultiples = enlistMultiples (argNames arglist)
      unless (null argMultiples) $
        throwExprError_ (RecurringArgumentNames argMultiples)
      retty <- checkExpr (env `with` arglist) body
      pure $! foldTArr (argTypes arglist) retty
    PrimOp primop ->
      case primop of
        NewSeqInt -> pure $! (TArr TInt (TArr TInt (TSeq TInt)))
        GetSeqInt -> pure $! (TArr (TSeq TInt) (TArr TInt TInt))
        SetSeqInt ->
          pure $! (TArr (TSeq TInt) (TArr TInt (TArr TInt (TSeq TInt))))
        NewSeqBool -> pure $! (TArr TInt (TArr TBool (TSeq TBool)))
        GetSeqBool -> pure $! (TArr (TSeq TBool) (TArr TInt TBool))
        SetSeqBool ->
          pure $! (TArr (TSeq TBool) (TArr TInt (TArr TBool (TSeq TBool))))
        ReadIntStream  -> pure $! (TSF ioresourcety TVoid TInt)
        WriteIntStream -> pure $! (TSF ioresourcety TInt TVoid)
        ReadBoolStream  -> pure $! (TSF ioresourcety TVoid TBool)
        WriteBoolStream -> pure $! (TSF ioresourcety TBool TVoid)

    Pair exp1 exp2 -> do
      exp1ty <- checkExpr env exp1
      exp2ty <- checkExpr env exp2
      pure $! TPair exp1ty exp2ty
    Fst expr -> do
      ty <- checkExpr env expr
      case ty of
        TPair ty1 _ -> pure ty1
        _ -> throwExprError expr (NotAPair ty)
    Snd expr -> do
      ty <- checkExpr env expr
      case ty of
        TPair _ ty2 -> pure ty2
        _ -> throwExprError expr (NotAPair ty)
    MapSignal expr -> do
      ty <- checkExpr env expr
      case ty of
        TArr ty1 ty2 -> pure $ TSF Empty ty1 ty2
        _ -> throwExprError expr (NotMappable ty)
    {-
    Checks for loop#
    Given loop# e1 e2
    1. e2 is a function type
    2. e2 is a function type from pair to pair : (a,c) -> (b,c')
    3. the type of c == c' this is important because this is plain feedback
       types cannot change
    4. the type of e1 is the same as c (and hence c') e1 is just initial value
    -}
    Loop expr1 expr2 -> do
      e1Ty <- checkExpr env expr1
      e2Ty <- checkExpr env expr2
      case e2Ty of
        (TSF Empty ty1 ty2) ->
          case ty1 of
            TPair a c ->
              case ty2 of
                TPair b c' -> do
                  unless (c == c') $
                    throwExprError expr2 (ExpectedButGot c c')
                  unless (e1Ty == c) $
                    throwExprError expr1 (ExpectedButGot c e1Ty)
                  pure $ TSF Empty a b
                t -> throwExprError expr2 (NotAPair t)
            t -> throwExprError expr2 (NotAPair t)
        t -> throwExprError expr2 (NotASignalFunc t)
    Compose expr1 expr2 -> do
      ty1 <- checkExpr env expr1
      ty2 <- checkExpr env expr2
      -- Check 1
      case ty1 of
        (TSF resty1 ty1I ty1O) ->
          case ty2 of
            (TSF resty2 ty2I ty2O) -> do
              if isAllVoid ty1O && isAllVoid ty2I -- && ty1O == ty2I is checked below
              then throwExprError expr SequencingError
              else do
                -- Check 2
                unless (resty1 `allResourcesPresent` (resources env) || resty1 == Empty) $
                  throwExprError expr1 (UndefinedResourceType resty1)
                unless (resty2 `allResourcesPresent` (resources env) || resty2 == Empty) $
                  throwExprError expr2 (UndefinedResourceType resty2)
                -- Check 3
                unless (ty1O == ty2I) $
                  throwExprError expr (CompositionMismatch (ty1, ty2))
                -- Check 4
                let newResTy = disjointUnion expr resty1 resty2
                fmap (\rty -> TSF rty ty1I ty2O) newResTy
            _ -> throwExprError expr (NotASignalFunc ty2)
        _ -> throwExprError expr (NotASignalFunc ty1)

  {-

  Check 1
  In Compose type of expr1 and expr2 has to be a signal function
  Check 2
  Also check if all the resources of the  resource type is defined
  eg (S1 U S2) U (S2 U S3) == S1, S2, S3 must be defined in the env
  Check 3
  When composing SF _ a b -> SF _ b c
  b has to be the same type
  Check 4
  then do the union part
  and throw error if non disjoint
  -}

    UnsafeCompose expr1 expr2 -> do
      ty1 <- checkExpr env expr1
      ty2 <- checkExpr env expr2
      case ty1 of
        (TSF resty1 ty1I ty1O) ->
          case ty2 of
            (TSF resty2 ty2I ty2O) -> do
              if isAllVoid ty1O && isAllVoid ty2I -- && ty1O == ty2I is checked below
              then throwExprError expr SequencingError
              else do
                unless (resty1 `allResourcesPresent` (resources env) || resty1 == Empty) $
                  throwExprError expr1 (UndefinedResourceType resty1)
                unless (resty2 `allResourcesPresent` (resources env) || resty2 == Empty) $
                  throwExprError expr2 (UndefinedResourceType resty2)
                unless (ty1O == ty2I) $
                  throwExprError expr (CompositionMismatch (ty1, ty2))
                let newResTy = naturalUnion resty1 resty2
                pure $! TSF newResTy ty1I ty2O
            _ -> throwExprError expr (NotASignalFunc ty2)
        _ -> throwExprError expr (NotASignalFunc ty1)

    Fanout expr1 expr2 -> do
      ty1 <- checkExpr env expr1
      ty2 <- checkExpr env expr2
      case ty1 of
        (TSF resty1 ty1I ty1O) ->
          case ty2 of
            (TSF resty2 ty2I ty2O) -> do
              unless (resty1 `allResourcesPresent` (resources env) || resty1 == Empty) $
                throwExprError expr1 (UndefinedResourceType resty1)
              unless (resty2 `allResourcesPresent` (resources env) || resty2 == Empty) $
                throwExprError expr2 (UndefinedResourceType resty2)
              unless (ty1I == ty2I) $
                throwExprError expr (FanoutMismatch (ty1, ty2))
              let newResTy = disjointUnion expr resty1 resty2
              fmap (\rty -> TSF rty ty1I (TPair ty1O ty2O)) newResTy
            _ -> throwExprError expr (NotASignalFunc ty2)
        _ -> throwExprError expr (NotASignalFunc ty1)

    -- SF a b -> SF a c -> SF a (b,c)
    UnsafeFanout expr1 expr2 -> do
      ty1 <- checkExpr env expr1
      ty2 <- checkExpr env expr2
      case ty1 of
        (TSF resty1 ty1I ty1O) ->
          case ty2 of
            (TSF resty2 ty2I ty2O) -> do
              unless (resty1 `allResourcesPresent` (resources env) || resty1 == Empty) $
                throwExprError expr1 (UndefinedResourceType resty1)
              unless (resty2 `allResourcesPresent` (resources env) || resty2 == Empty) $
                throwExprError expr2 (UndefinedResourceType resty2)
              unless (ty1I == ty2I) $
                throwExprError expr (FanoutMismatch (ty1, ty2))
              let newResTy = naturalUnion resty1 resty2
              pure $! TSF newResTy ty1I (TPair ty1O ty2O)
            _ -> throwExprError expr (NotASignalFunc ty2)
        _ -> throwExprError expr (NotASignalFunc ty1)

    Combine expr1 expr2 -> do
      ty1 <- checkExpr env expr1
      ty2 <- checkExpr env expr2
      case ty1 of
        (TSF resty1 ty1I ty1O) ->
          case ty2 of
            (TSF resty2 ty2I ty2O) -> do
              unless (resty1 `allResourcesPresent` (resources env) || resty1 == Empty) $
                throwExprError expr1 (UndefinedResourceType resty1)
              unless (resty2 `allResourcesPresent` (resources env) || resty2 == Empty) $
                throwExprError expr2 (UndefinedResourceType resty2)
              let newResTy = disjointUnion expr resty1 resty2
              fmap (\rty -> TSF rty (TPair ty1I ty2I) (TPair ty1O ty2O)) newResTy
            _ -> throwExprError expr (NotASignalFunc ty2)
        _ -> throwExprError expr (NotASignalFunc ty1)
    -- SF a c -> SF b d -> SF (a, b) (c, d)
    UnsafeCombine expr1 expr2 -> do
      ty1 <- checkExpr env expr1
      ty2 <- checkExpr env expr2
      case ty1 of
        (TSF resty1 ty1I ty1O) ->
          case ty2 of
            (TSF resty2 ty2I ty2O) -> do
              unless (resty1 `allResourcesPresent` (resources env) || resty1 == Empty) $
                throwExprError expr1 (UndefinedResourceType resty1)
              unless (resty2 `allResourcesPresent` (resources env) || resty2 == Empty) $
                throwExprError expr2 (UndefinedResourceType resty2)
              let newResTy = naturalUnion resty1 resty2
              pure $! TSF newResTy (TPair ty1I ty2I) (TPair ty1O ty2O)
            _ -> throwExprError expr (NotASignalFunc ty2)
        _ -> throwExprError expr (NotASignalFunc ty1)
    Switch expr1 expr2 -> do
      e1Ty <- checkExpr env expr1
      e2Ty <- checkExpr env expr2
      case e1Ty of
        (TSF r1 ty1 ty2) ->
          case e2Ty of
            TArr tyo (TSF r2 tyo' ty3) -> do
              unless (r1 `allResourcesPresent` (resources env) || r1 == Empty) $
                throwExprError expr1 (UndefinedResourceType r1)
              unless (r2 `allResourcesPresent` (resources env) || r2 == Empty) $
                throwExprError expr2 (UndefinedResourceType r2)
              unless (ty2 == tyo) $
                throwExprError expr2 (CompositionMismatch (ty2, tyo))
              unless (tyo == tyo') $
                throwExprError expr2 (ExpectedButGot tyo tyo')
              let newResTy = disjointUnion expr r1 r2
              fmap (\rty -> TSF rty ty1 ty3) newResTy
            t -> throwExprError expr2 (ExpectedFunctionType t)
        t -> throwExprError expr1 (NotASignalFunc t)
    Rate expr1 expr2 -> do
      e1Ty <- checkExpr env expr1
      e2Ty <- checkExpr env expr2
      case e2Ty of
        (TSF r ty1 ty2) -> do
          unless (e1Ty == TFloat) $
            throwExprError expr (ExpectedButGot TFloat e1Ty)
          unless (r `allResourcesPresent` (resources env) || r == Empty) $
            throwExprError expr2 (UndefinedResourceType r)
          pure $! TSF r ty1 ty2
        t -> throwExprError expr1 (NotASignalFunc t)


    -- | GRiSP board specific type checks
    ReadColor (ledpos, tyAnn) -> do
      ledty <- checkExpr env ledpos
      case tyAnn of
        TSF rty ty1 ty2 -> do
          unless (rty `allResourcesPresent` (resources env)) $
            throwExprError expr (UndefinedResourceType rty)
          unless (ty1 == TVoid) $
            throwExprError expr (WrongAnnotation TVoid ty1)
          unless (ty2 == TInt) $
            throwExprError expr (WrongAnnotation TInt ty2)
          unless (ledty == TInt) $
            throwExprError ledpos (ExpectedButGot TInt ledty)
          pure $! TSF rty ty1 ty2
        _ -> throwExprError expr (NotASignalFunc tyAnn)
    WriteColor (ledpos, tyAnn) -> do
      ledty <- checkExpr env ledpos
      case tyAnn of
        TSF rty ty1 ty2 -> do
          unless (rty `allResourcesPresent` (resources env)) $
            throwExprError expr (UndefinedResourceType rty)
          unless (ty1 == TInt) $
            throwExprError expr (WrongAnnotation TInt ty1)
          unless (ty2 == TVoid) $
            throwExprError expr (WrongAnnotation TVoid ty2)
          unless (ledty == TInt) $
            throwExprError ledpos (ExpectedButGot TInt ledty)
          pure $! TSF rty ty1 ty2
        _ -> throwExprError expr (NotASignalFunc tyAnn)

binopHelperInt env a b = do
  aty <- checkExpr env a
  unless (aty == TInt) $ throwExprError a (ExpectedButGot TInt aty)
  bty <- checkExpr env b
  unless (bty == TInt) $ throwExprError b (ExpectedButGot TInt bty)
  pure (aty,bty)

binopHelperFloat env a b = do
  aty <- checkExpr env a
  unless (aty == TFloat) $ throwExprError a (ExpectedButGot TFloat aty)
  bty <- checkExpr env b
  unless (bty == TFloat) $ throwExprError b (ExpectedButGot TFloat bty)
  pure (aty,bty)

allResourcesPresent :: ResourceTy -> [Resource] -> Bool
allResourcesPresent rty renvs =
  (map R . sort . DL.nub . flattenRTy) rty `DL.isInfixOf` (sort renvs)


disjointUnion :: Expr
              -> ResourceTy
              -> ResourceTy
              -> Either ExprError ResourceTy
disjointUnion _ Empty rty = pure rty
disjointUnion _ rty Empty = pure rty
disjointUnion expr rty1 rty2 = do
  when (rty1 `containsMemberOf` rty2) $
    throwExprError expr (SameResource rty1 rty2)
  pure $! Union rty1 rty2

-- | containsMemberOf is left biased test which
-- traverses the tree and short circuits to True
-- if any member of left is present in right
containsMemberOf :: ResourceTy -> ResourceTy -> Bool
containsMemberOf Empty rty = False
containsMemberOf rty Empty = False
containsMemberOf (Singleton r1) (Singleton r2) = r1 == r2
containsMemberOf s@(Singleton _) (Union rl rr) =
  s `containsMemberOf` rl || s `containsMemberOf` rr
containsMemberOf (Union rl rr) s@(Singleton _) =
  s `containsMemberOf` rl || s `containsMemberOf` rr
containsMemberOf (Union rl rr) u2@(Union _ _) =
  rl `containsMemberOf` u2 || rr `containsMemberOf` u2

naturalUnion :: ResourceTy
             -> ResourceTy
             -> ResourceTy
naturalUnion Empty rty = rty
naturalUnion rty Empty = rty
naturalUnion s1@(Singleton r1) s2@(Singleton r2)
  | r1 == r2 = s1
  | otherwise = Union s1 s2
naturalUnion s@(Singleton _) u@(Union _ _) =
  if s `containsMemberOf` u
  then u
  else Union s u
naturalUnion u@(Union _ _) s@(Singleton _) =
  if s `containsMemberOf` u
  then u
  else Union u s
naturalUnion u1@(Union _ _) u2@(Union _ _) =
  reconstruct $ DL.nub $ (flattenRTy u1) ++ (flattenRTy u2)

reconstruct :: [ResourceTy] -> ResourceTy
reconstruct [] = Empty
reconstruct (r1 : rs) = foldr Union r1 rs -- IMP below
-- foldl' or foldr doesn't matter because when comparing
-- resources for equality they are flattened anyways

checkName :: Name -> Either TypeCheckError ()
checkName name
  | Text.null name = throwError NameIsEmpty
  | isKeyword name = throwError $! NameIsKeyword name
  | otherwise = pure ()

countOccurrences :: Ord a => [a] -> Map a Int
countOccurrences = foldl' (flip insert) Map.empty
  where
    insert item = Map.insertWith (+) item 1

enlistMultiples :: Ord a => [a] -> [a]
enlistMultiples = Map.keys . Map.filter (> 1) . countOccurrences

{-
This exists here to prevent composing things like
a : SF ((), ()) ((), ())
b : SF ((), ()) ((), ())

a :>>>: b

We should reject the above and ask to use ***
-}
isAllVoid :: Type -> Bool
isAllVoid TVoid = True
isAllVoid TInt  = False
isAllVoid TFloat = False
isAllVoid TBool = False
isAllVoid (TSeq ty)       = isAllVoid ty
isAllVoid (TPair ty1 ty2) = isAllVoid ty1 && isAllVoid ty2
isAllVoid (TArr _ _) = False
isAllVoid (TSF _ _ _)  = False

----------------------------------------------------------------------
-- Error Handling
-- | A type error with the program
data ProgramError
  = ProgramError TypeCheckError
    -- ^ an error directly in the program definition
    -- (not a global binding)
  | ProgramGlobalError GlobalError
    -- ^ an error with a global binding
  deriving (Show, Eq, Ord, Generic, Typeable)

-- | A type error within a global binding
data GlobalError
  = GlobalError Name TypeCheckError
    -- ^ an error directly in the global binding (not in its body)
  | GlobalBodyError Name ExprError
    -- ^ it carries the name of the global binding
    -- and the error that occurred in the body of the binding
  deriving (Show, Eq, Ord, Generic, Typeable)

-- | A type error within an expression
data ExprError =
  ExprError TypeCheckError [Expr]
    -- ^ it carries an error code
    -- and a trace of expressions
    -- in which the error occurred (outside in)
  deriving (Show, Eq, Ord, Generic, Typeable)

-- | Specific errors that occur during type-checking
data TypeCheckError
  = NameIsEmpty
    -- ^ The empty string is not a valid name
  | NameIsKeyword Name
    -- ^ A keyword is not a valid name
  | VariableNotInScope Name
    -- ^ Reference to unknown variable
  | ExpectedButGot Type Type
    -- ^ Value of unexpected type encountered
  | EqualityUndefined Type
    -- ^ Equality for the type is not defined
  | RelOpUndefined Type
    -- ^ Relational Ops for the type is not defined
  | NotTheSame Type Type
    -- ^ Two values should have the same type but don't
  | NotAFunction Type
    -- ^ Expected a function
  | NotAPair Type
    -- ^ Expected a pair
  | RecurringArgumentNames [Name]
    -- ^ An argument name is used multiple times in one argument list
  | ReturnTypeMismatch Type Type
    -- ^ The return type does not match the body type
  | RecurringGlobalNames [Name]
    -- ^ Multiple global definitions share a name
  | NoMainFunction
    -- ^ A program has to have a main function
  | WrongAnnotation Type Type
    -- ^ An expression (like a BIF) is incorrectly annotated
  | ExpectedFunctionType Type
    -- ^ Expected function type but got something else

  -- | Resource types and arrow combinator
  --   related errors follow
  | NotMappable Type
    -- ^ Expected type (a -> b) in mapSignal
  | NotASignalFunc Type
    -- ^ Expected a signal function
  | RecurringResourceNames [Name]
    -- ^ Multiple resource types share a name
  | NonEmptyResourceType Type
    -- ^ Resource type is non empty
  | UndefinedResourceType ResourceTy
    -- ^ Undefined resource type
  | CompositionMismatch (Type, Type)
    -- ^ Output type of signal 1 doesn't match input of signal 2
    -- while composing 2 signals
  | FanoutMismatch (Type, Type)
    -- ^ Signal 1 and Signal 2 do not have the same source
    -- while fanning out two signals
  | SameResource ResourceTy ResourceTy
    -- ^ Composing resources of the same type
  | SequencingError
    -- ^ Attempt to compose f : a -> () and  g : () -> b using f >>> g
  deriving (Show, Eq, Ord, Generic, Typeable)

throwProgramError :: TypeCheckError -> Either ProgramError a
throwProgramError = first ProgramError . throwError

-- | Forward a global error
-- in a global binding of the program
-- as a program error
rethrowProgramGlobalError :: Either GlobalError a -> Either ProgramError a
rethrowProgramGlobalError = first ProgramGlobalError

-- | Forward an expression error
-- in the body of a global binding
-- as a global error
rethrowGlobalBodyError :: Name -> Either ExprError a -> Either GlobalError a
rethrowGlobalBodyError name = first (GlobalBodyError name)

exprError :: Expr -> TypeCheckError -> ExprError
exprError expr e = ExprError e [expr]

exprError_ :: TypeCheckError -> ExprError
exprError_ e = ExprError e []

-- | Extend the trace in an error by the given expression.
-- Identity on success.
exprErrorTrace :: Expr -> Either ExprError a -> Either ExprError a
exprErrorTrace expr =
  \case
    Left (ExprError code exprs) -> Left (ExprError code (expr : exprs))
    Right a -> Right a

-- | Packs an error code into an expression error with a singleton trace.
throwExprError :: Expr -> TypeCheckError -> Either ExprError a
throwExprError expr = first (exprError expr) . throwError

-- | Packs an error code into an expression error with an empty trace.
throwExprError_ :: TypeCheckError -> Either ExprError a
throwExprError_ = first exprError_ . throwError

ppProgramError :: ProgramError -> Doc Highlight
ppProgramError (ProgramError err) =
  ppErrMsg "Type-Checking Error" $ ppTypeCheckError err
ppProgramError (ProgramGlobalError err) =
  ppErrMsg "Type-Checking Error" $ ppGlobalError err

ppGlobalError :: GlobalError -> Doc Highlight
ppGlobalError (GlobalError name err) =
  ppErrMsg ("Error with" <+> dquote <> ppName name <> dquote) $
  ppTypeCheckError err
ppGlobalError (GlobalBodyError name err) =
  ppErrMsg ("Error in" <+> dquote <> ppName name <> dquote) $ ppExprError err

ppExprError :: ExprError -> Doc Highlight
ppExprError (ExprError err []) = ppTypeCheckError err
ppExprError (ExprError err ctx) =
  let ppCtxErr ctxErr' = vsep ["Encountered in", indent 2 ctxErr']
      ctx' = vsep $ map (ppCtxErr . ppExpr) $ take 3 $ reverse ctx
   in vsep [ppTypeCheckError err, ctx']

ppTypeCheckError :: TypeCheckError -> Doc Highlight
ppTypeCheckError =
  \case
    NameIsEmpty ->
      ppErrMsg "Invalid name" "The empty string is not a valid name."
    NameIsKeyword name ->
      ppErrMsg "Invalid name" dquote <> pretty name <> dquote <+>
      "is a keyword."
    VariableNotInScope name ->
      ppErrMsg "Variable not in scope" $
      dquote <> pretty name <> dquote <+> "is not defined."
    ExpectedButGot expected got ->
      ppErrMsg "Unexpected type" $
      let expected' = nest 2 $ vsep ["Expected", ppType expected]
          got' = nest 2 $ vsep ["but got", ppType got]
       in group $ vsep [expected', got']
    EqualityUndefined ty ->
      ppErrMsg "Equality is not defined for" $ ppType ty
    RelOpUndefined ty ->
      ppErrMsg "Relational Ops are not defined for" $ ppType ty
    NotTheSame a b ->
      ppErrMsg "Type mismatch" $
      ppType a <+> "and" <+> ppType b <+> "are not the same type."
    NotAFunction ty ->
      ppErrMsg "Too many arguments" $ ppType ty <+> "is not a function type."
    NotAPair ty ->
      ppErrMsg "Expected a pair type but got " $ ppType ty
    RecurringArgumentNames names ->
      ppErrMsg "Recurring argument names" $
      "The following names are used multiple times" <+> pretty names
    ReturnTypeMismatch expected got ->
      ppErrMsg "Mismatch in return type" $
      let expected' = nest 2 $ vsep ["Expected", ppType expected]
          got' = nest 2 $ vsep ["but got", ppType got]
       in group $ vsep [expected', got']
    RecurringGlobalNames names ->
      ppErrMsg "Recurring global names" $
      "The following names are used multiple times" <+> pretty names
    RecurringResourceNames names ->
      ppErrMsg "Recurring resource types" $
      "The following resources are defined multiple times" <+> pretty names
    NoMainFunction ->
      ppErrMsg "No main function" "A program has to have a main function."
    WrongAnnotation expected annotated ->
      ppErrMsg "Wrong annotation. Expected " $
      ppType expected <+> "but annotated" <+> ppType annotated
    ExpectedFunctionType ty ->
      ppErrMsg "Expected a function type but got " $ ppType ty
    NotMappable ty ->
      ppErrMsg "Cannot map value to signal. Got " $
      ppType ty <+> ". Expected mapping value of type a -> b"
    NotASignalFunc ty ->
      ppErrMsg "Expected a signal function but got " $ ppType ty <+> "type."
    NonEmptyResourceType ty ->
      ppErrMsg "MapSignal operates on non empty resource type in" $
      ppType ty
    UndefinedResourceType resty ->
      ppErrMsg "Resource type " $
      ppResourceType resty <+> "not defined. Please initialize."
    CompositionMismatch (ty1, ty2) ->
      ppErrMsg "Type mismatch while composing signal function types " $
      ppType ty1 <> " and " <> ppType ty2
    FanoutMismatch (ty1, ty2) ->
      ppErrMsg "Signals being fanned out do not have the same source type: " $
      ppType ty1 <> " and " <> ppType ty2
    SameResource resty1 resty2 ->
      ppErrMsg "Cannot compose resources " $
      ppResourceType resty1 <> " " <> ppResourceType resty2 <>
      " containing same resource"
    SequencingError ->
      ppErrMsg "Sequencing 2 or more effects" $
      viaShow "use the *** combinator rather than the >>> combinator"

ppErrMsg :: Doc Highlight -> Doc Highlight -> Doc Highlight
ppErrMsg heading err =
  let heading' = annotate HlError heading <> colon
   in group $ vsep [heading', indent 2 err] `flatAlt` hsep [heading', err]

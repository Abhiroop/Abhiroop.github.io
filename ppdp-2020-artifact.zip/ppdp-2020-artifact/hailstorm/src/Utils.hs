module Utils where

-- This module includes some missing utilities in Protolude
-- I have heard enough arguments against Util modules and
-- I believe its simply bikeshedding by people who have no better job.

mapToFst :: (a -> b) -> a -> (b, a)
mapToFst f x = (f x, x)

mapToSnd :: (a -> b) -> a -> (a, b)
mapToSnd f x = (x, f x)

mapBoth :: (a -> b) -> (a, a) -> (b, b)
mapBoth f (x,y) = (f x, f y)

(&&&) :: (a -> b) -> (a -> c) -> a -> (b, c)
(&&&) f g a = (f a, g a)

liftFst :: (a -> b) -> (a, c) -> (b, c)
liftFst f (a, c) = (f a, c)

liftSnd :: (a -> b) -> (c, a) -> (c, b)
liftSnd f (c, a) = (c, f a)

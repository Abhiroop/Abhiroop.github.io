-- Tests are currently broken because they point to my local directory and utilize my LLVM backend
import Test.HUnit

import Data.Text hiding (length)

import Parse
import Pretty
import Protolude
import Typecheck

import L1.Interpreter
import L1.L1
import L1.Optimizer
import L2.Interpreter
import L2.JIT

import System.Process (callCommand)

hstDirectory = "/Users/abhiroopsarkar/Haskell/hailstorm/"

filepath   = hstDirectory <> "examples/closure.hst"

outfile    = hstDirectory <> "examples/arrays.ll"

runtime    = hstDirectory <> "rts/Array.ll"

linkedfile = hstDirectory <> "examples/hailstorm_linked.ll"

objectfile = hstDirectory <> "examples/hailstorm_linked.o"

emitResult prog = do
  let (Right p) = parseText prog
  tcd <- typeCheck' p
  let l1  = astToL1 tcd
      l1' = optimize l1
      l2  = l1Tol2 l1'
  exec [] l2

emitLLVM prog = do
  let (Right p) = parseText prog -- assuming no parse errors
  tcd <- typeCheck' p
  let l1  = astToL1 tcd
      l1' = optimize l1
      l2  = l1Tol2 l1'
  return $ ppllvm l2

-- type checking tests
typecheck :: Prog
          -> ProgName
          -> Test
typecheck prog progName = TestCase $ do
  let (Right p) = parseText prog
  let tcd = typeCheck p
  assertBool progName (isRight tcd)

countSubStrs str sub = length $ breakOnAll sub str

type Prog = Text
type ProgName = [Char]
type Result = Int32 -- will change in future
type MallocUsage = Int

testCase :: Prog
         -> ProgName
         -> Result
         -> MallocUsage
         -> Test
testCase program progName result n = TestCase $ do
  res <- emitResult program
  assertEqual progName result res
  code <- emitLLVM program
  let z = countSubStrs (pack $ show code) "malloc"
  assertEqual (progName ++ "_llvm") z n

testCase2 :: Prog
          -> ProgName
          -> Result
          -> Test
testCase2 program progName result = TestCase $ do
  res <- emitResult program
  assertEqual progName result res



prog1 = "def main : Int = foo \
        \def foo : Int = \
          \ let x = 5 in \
          \ let bar = \\(z:Int) => x + z in \
          \ bar 5"

prog2 = "def main : Int = foo \
        \def foo : Int = \
          \ (let x = 5 in \
          \ \\(y:Int) => x + y) 5"

prog3 = "def main : Int = sum \
        \def sum : Int = \
          \ let s = 5 in \
          \ let foo = \\(x:Int) => s + x in \
          \ foo 10"

prog4 = "def main : Int = test \
        \def foo (x:Int) (y:Int) (z:Int) : Int \
        \ = x + y + z \
        \def test : Int = \
        \ let x = let r = foo 5 in \
                 \let k = r 5 in \
                 \let z = k 6 in \
                 \z in \
        \ let r = foo 1 x in \
        \ r 5"

prog5 = "def main : Int = test \
        \def foo (x:Int) (y:Int) (z:Int) : Int \
        \ = x + y + z \
        \def test : Int = \
        \ let x = let k = foo 5 5 6 in \
        \         k in \
        \ foo 1 x 5"

prog6 = "def main : Int = koo \
        \def foo (x:Int) (y:Int) (z:Int) : Int \
        \ = x + y + z \
        \def koo : Int = \
        \  let bar  = foo in \
        \  let x    = 1 in \
        \  let bar1 = bar x in \
        \  let bar2 = bar1 2 in \
        \  let bar3 = bar2 3 in \
        \  bar3"

prog7 = "def main : Int = bar3 \
        \def foo (x:Int) (y:Int) (z:Int) : Int \
        \ = x + y + z \
        \def bar3 : Int = foo 1 2 3"

prog8 = "def main : Int = bar 5 \
        \def bar : (Int -> Int) = \
        \ let x = 5 in \
        \ \\(z:Int) => x + z"

prog9 = "def main : Int = foo \
        \def foo : Int = \
        \  let x = 5 in \
        \  if (((\\(y:Int) => x + y) 7) == 7 ) then \
        \     ((\\(y:Int) => x + y) 0) \
        \  else \
        \     ((\\(y:Int) => x + y) 1)"

prog10 = "def main : Int = joo \
         \def joo : Int = \
         \  let x = let m = 9 in \\(y:Int) => m + y in\
         \  x 5"

prog11 = "def main : Int = joo \
         \def jool (m : Int) (y : Int) : Int \
         \ = m + y \
         \def joo : Int = \
         \  let x = let m = 9 in (jool m) in\
         \  x 5"

prog12 = "def main : Int = foo \
         \def foo : Int = (\\ (x : Int) (y : Int) => x + y) 5 5"

prog13 = "def main : Int = foo \
         \def foo : Int \
         \ = let x = (\\(y: Int) (m:Int) => m + y) 4 in \
         \   x 5"

prog14 = "def main : Int = foo 3\
         \def foo : (Int -> Int) \
         \  = let adder = \\(x:Int) (y:Int) => x + y  in\
         \    adder 5"

prog15 = "def main : Int = foo \
         \def foo : Int \
         \  = let x = 5 in \
         \    let z = let foo = \\(y: Int) => y + x in\
         \            foo 5 in \
         \    let bar = \\(m : Int) => m + x in \
         \    bar z"

prog16 = "def main : Int = foo 5\
         \def foo : (Int -> Int) \
         \  = let func = (\\(x : Int) (y : Int) => x + y) in \
         \    let x = (func 5 4) + (func 3 3) in \
         \    func x"

prog17 = "def main : Int = foo \
         \def foo : Int \
         \  = let func = (\\(x : Int) (y : Int) (z : Int)=> x + y + z) in \
         \    ((func (1 + 2)) (1 + 2)) (1 + 2)"

prog18 = "def main : Int = test \
         \def foo_clos (x:Int) (y:Int) : Int \
         \  = y + x                          \
         \def test : Int = \
         \   (if 1 == 1 \
         \    then foo_clos 4 \
         \    else foo_clos 5) 5"

prog19 = "def main : Int = zoo2 \
         \def zoo2 : Int = \
         \  let x = 5 in \
         \  let foo = ((\\(z:Int) => x + z) 7) + ((\\(z:Int) => x + z) 10) in \
         \  foo"

prog20 = "def main : Int = foo \
         \def foo : Int \
         \  = let adder = \\ (x:Int) (y:Int) => x + y in \
         \    let adderfive = adder 5 in \
         \    adderfive 6"

prog21 = "def main : Int = foo \
         \def foo : Int = \
         \  let x = 5 in \
         \  (\\(f : (Int -> Int)) => f x) (\\(z:Int) => x + z)"

prog22 = "def main : Int = foo \
         \def f1 (x : Int) (g : Int -> Int) : Int = g x \
         \def z1 (n : Int) (z : Int) : Int = n + z \
         \def foo : Int = \
         \  let t = 5 in \
         \  (f1 t) (z1 t)"

prog23 = "def main : Int = foo \
         \def fool (x : Int) (y : Int) : Int = x + y \
         \def foo : Int = \
         \  (let x = 5 in\
         \  fool x) 5"

prog24 = "def main : Int = foo \
         \def foo : Int \
         \  = let adder = \\(x : Int) (y : Int) => x + y in\
         \    let adderfive = adder 5 in \
         \    let ten = adderfive 5 in \
         \    ten"

prog25 = "def main : Int = zoo1 \
         \def zoo1 : Int = \
         \  let x = 9 in \
         \  let foo = let j = \\(z:Int) => x - z in \
         \            j in\
         \  foo 5"

prog26 = "def main : Int = zoo1 \
         \def zool (x : Int) (z : Int) : Int = x - z \
         \def zoo1 : Int = \
         \  let x = 10 in \
         \  let foo = let j = zool x in \
         \            j in \
         \  foo 9"

prog27 = "def main : Int = foo 3 \
         \def foo : (Int -> Int) = \
         \  let adder = \\ (x : Int) (y : Int) => x + y in \
         \  let adderfive = adder 5 in \
         \  adderfive"

prog28 = "def main : Int = test 3 \
         \def test : (Int -> Int) \
         \  = let x = 6 in \
         \    let foo = \\(y:Int) => x + y in \
         \    let m = 7 in \
         \    let bar = \\(n:Int) => m + n in \
         \    let b = (foo 10) + (bar 10) in \
         \    let baz = \\(j:Int) => b + j in \
         \    baz"

prog29 = "def main : Int = test2 2 3 \
         \def test : (Int -> Int) \
         \  = let x = 6 in \
         \    let foo = \\(y:Int) => x + y in \
         \    let m = 7 in \
         \    let bar = \\(n:Int) => m + n in \
         \    let b = (foo 10) + (bar 10) in \
         \    let baz = \\(j:Int) => b + j in \
         \    baz \
         \def test2 : (Int -> Int -> Int) \
         \  = let a = test 3 in \
         \    \\(x:Int) (y:Int) => x + y + a"

prog30 = "def main : Int = baz \
         \def bar : (Int -> Int -> Int) \
         \  = \\(x:Int) (y:Int) => x + y \
         \def foo : (Int -> Int) \
         \  = let a = 5 in \
         \    let func = \\(y:Int) => bar y a in \
         \    func \
         \def baz : Int = foo 7"

prog31 = "def main : Int = baz \
         \def foo : (Int -> Int -> Int) \
         \  = \\(x:Int) (y:Int) => x + y \
         \def bar : (Int -> Int) \
         \  = foo 20 \
         \def baz : Int \
         \  = bar 3"

-- pair based tests
prog32 = "def main : Int = 0 \
         \def bar0 : Int = (fst# (fst# ((5,3),3)))"

prog33 = "def main : Int = 0 \
         \def bar : Int = \
         \  (fst# \
         \    (fst# \
         \      (snd# \
         \        (snd# (2,(4,((5,3),3)))))))"

prog34 = "def main : Int = 0 \
         \def bar : Int = \
         \  (snd# \
         \    (snd# \
         \      (snd# \
         \        (fst# \
         \          (fst# \
         \            (((1,(2,(3,4))),5),6))))))"

-- testing aliases
prog35 = "def main : Int = bar 5 6 \
         \def bar : (Int -> Int -> Int) = foo \
         \def foo : (Int -> Int -> Int) = \
         \  \\(x : Int) (y : Int) => x + y"

prog36 = "def main : Int = bar 5 \
         \def bar : (Int -> Int) = foo \
         \def foo : (Int -> Int) = \
         \  \\(x : Int) => x"

prog37 = "def main : Int = bar 1 2 3 \
         \def bar : (Int -> Int -> Int -> Int) = foo \
         \def foo : (Int -> Int -> Int -> Int) = \
         \  \\(x : Int) (y : Int) (z: Int) => x + y + z"

prog38 = "def main : Int = foo 5 \
         \def foo : (Int -> Int) \
         \  = let bar = 5 in \
         \    let func = \\(x:Int) => x + bar + 1 in \
         \    \\(z:Int) => func z"

test1  = testCase prog1  "prog1"  10 1
test2  = testCase prog2  "prog2"  10 1
test3  = testCase prog3  "prog3"  15 1
test4  = testCase prog4  "prog4"  22 1
test5  = testCase prog5  "prog5"  22 1
test6  = testCase prog6  "prog6"   6 1
test7  = testCase prog7  "prog7"   6 1
test8  = testCase prog8  "prog8"  10 1
test9  = testCase prog9  "prog9"   6 1
test10 = testCase prog10 "prog10" 14 1
test11 = testCase prog11 "prog11" 14 1
test12 = testCase prog12 "prog12" 10 1
test13 = testCase prog13 "prog13"  9 1
test14 = testCase prog14 "prog14"  8 1
test15 = testCase prog15 "prog15" 15 1
test16 = testCase prog16 "prog16" 20 1
test17 = testCase prog17 "prog17"  9 1
test18 = testCase prog18 "prog18"  9 1
test19 = testCase prog19 "prog19" 27 1
test20 = testCase prog20 "prog20" 11 1
test21 = testCase prog21 "prog21" 10 1
test22 = testCase prog22 "prog22" 10 1
test23 = testCase prog23 "prog23" 10 1
test24 = testCase prog24 "prog24" 10 1
test25 = testCase prog25 "prog25"  4 1
test26 = testCase prog26 "prog26"  1 1
test27 = testCase prog27 "prog27"  8 1
test28 = testCase prog28 "prog28" 36 1
test29 = testCase prog29 "prog29" 41 1
test30 = testCase prog30 "prog30" 12 1
test31 = testCase prog31 "prog31" 23 1

test32 = typecheck prog32 "prog32"
test33 = typecheck prog33 "prog33"
test34 = typecheck prog34 "prog34"

test35 = testCase2 prog35 "prog35" 11
test36 = testCase2 prog36 "prog36" 5
test37 = testCase2 prog37 "prog37" 6

test38 = testCase prog38 "prog38" 11 1

tests = TestList
        [ TestLabel "test1"  test1
        , TestLabel "test2"  test2
        , TestLabel "test3"  test3
        , TestLabel "test4"  test4
        , TestLabel "test5"  test5
        , TestLabel "test6"  test6
        , TestLabel "test7"  test7
        , TestLabel "test8"  test8
        , TestLabel "test9"  test9
        , TestLabel "test10" test10
        , TestLabel "test11" test11
        , TestLabel "test12" test12
        , TestLabel "test13" test13
        , TestLabel "test14" test14
        , TestLabel "test15" test15
        , TestLabel "test16" test16
        , TestLabel "test17" test17
        , TestLabel "test18" test18
        , TestLabel "test19" test19
        , TestLabel "test20" test20
        , TestLabel "test21" test21
        , TestLabel "test22" test22
        , TestLabel "test23" test23
        , TestLabel "test24" test24
        , TestLabel "test25" test25
        , TestLabel "test26" test26
        , TestLabel "test27" test27
        , TestLabel "test28" test28
        , TestLabel "test29" test29
        , TestLabel "test30" test30
        , TestLabel "test31" test31
        , TestLabel "test32" test32
        , TestLabel "test33" test33
        , TestLabel "test34" test34
        , TestLabel "test35" test35
        , TestLabel "test36" test36
        , TestLabel "test37" test37
        , TestLabel "test38" test38]


main :: IO ()
main =
  runTestTT tests >>= print

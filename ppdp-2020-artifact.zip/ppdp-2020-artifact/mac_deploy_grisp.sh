#!/bin/bash

# Execute this from the root of the robot directory
rm -rf _build
rm -rf /Volumes/GRISP/*
rebar3 compile
cd src/
erlc robot.core
cd ..
cp src/robot.beam _build/default/lib/robot/ebin/
rebar3 grisp deploy -n robot -v 0.1.0
cp src/robot.beam _build/grisp/lib/robot/ebin/
rm -rf /Volumes/GRISP/*
rebar3 grisp deploy -n robot -v 0.1.0
